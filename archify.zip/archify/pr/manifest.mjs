import fs from 'node:fs';
import path from 'node:path';
import { FULL_SHA_RE, hasRepositoryEvidence, runGit } from '../renderers/shared/repository-evidence.mjs';
import { validateSchema } from '../renderers/shared/validator.mjs';

export const PACK_PLATFORMS = ['github', 'gitlab', 'generic'];
export const DEFAULT_CHANGE_TABLE_LIMIT = 20;

export class PrPackError extends Error {
  constructor(message, { code, stage, diagnostics = [] } = {}) {
    super(message);
    this.code = code;
    this.stage = stage;
    this.diagnostics = diagnostics.length ? diagnostics : [packDiagnostic({ code, message })];
  }
}

export function packDiagnostic({ code, message, subject = {}, evidence = {}, supportedFixes = [], severity = 'error' }) {
  return { code, severity, message, subject: { surface: 'pr-pack', ...subject }, evidence, supportedFixes };
}

function fail(code, stage, message, options = {}) {
  throw new PrPackError(message, { code, stage, diagnostics: [packDiagnostic({ code, message, ...options })] });
}

function readJson(file, { stage, subject }) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    fail('input/not-found', stage, `Could not read ${file}: ${error.message}`, { subject, supportedFixes: ['pass an existing JSON file path'] });
  }
  try {
    return JSON.parse(text);
  } catch (error) {
    fail('input/invalid-json', stage, `${file} is not valid JSON: ${error.message}`, { subject, supportedFixes: ['fix the JSON syntax and retry'] });
  }
  return undefined;
}

function schemaFailure(error, stage, subject) {
  const diagnostics = (error.archifyDiagnostics || [{ code: 'schema/invalid', message: error.message }])
    .map((entry) => ({ ...entry, subject: { ...subject, ...(entry.subject || {}) } }));
  return new PrPackError(error.message, { code: diagnostics[0].code, stage, diagnostics });
}

// Loads the manifest, validates it against the precompiled pr-pack schema,
// and validates every referenced diagram against its own diagram schema.
export function loadPrPack(manifestInput) {
  const manifestPath = path.resolve(manifestInput);
  const manifestDir = path.dirname(manifestPath);
  const manifest = readJson(manifestPath, { stage: 'manifest', subject: { manifest: manifestPath } });
  try {
    validateSchema('prPack', manifest);
  } catch (error) {
    throw schemaFailure(error, 'manifest', { manifest: manifestPath });
  }
  const seen = new Set();
  const views = manifest.views.map((view, index) => {
    if (seen.has(view.id)) {
      fail('pr-pack/duplicate-view-id', 'manifest', `View id "${view.id}" is declared more than once.`, {
        subject: { manifest: manifestPath, path: `/views/${index}/id` },
        supportedFixes: ['give every view a unique id'],
      });
    }
    seen.add(view.id);
    const inputPath = path.resolve(manifestDir, view.input);
    const diagram = readJson(inputPath, { stage: 'views', subject: { view: view.id, input: inputPath } });
    try {
      validateSchema(view.type, diagram);
    } catch (error) {
      throw schemaFailure(error, 'views', { view: view.id, input: inputPath });
    }
    return {
      ...view,
      inputPath,
      diagram,
      collapsed: Boolean(view.collapsed),
      theme: view.theme || manifest.theme || 'both',
      preset: view.preset || manifest.preset || 'classic',
      evidence: hasRepositoryEvidence(view.type, diagram),
    };
  });
  for (const [index, row] of (manifest.changes || []).entries()) {
    if (row.view !== undefined && !seen.has(row.view)) {
      fail('pr-pack/unknown-change-view', 'manifest', `Change row ${index} references unknown view "${row.view}".`, {
        subject: { manifest: manifestPath, path: `/changes/${index}/view` },
        supportedFixes: ['reference a declared view id or drop the view column'],
      });
    }
  }
  return {
    manifestPath,
    manifestDir,
    manifest,
    views,
    platform: manifest.platform || 'github',
    changeTableLimit: manifest.changeTableLimit || DEFAULT_CHANGE_TABLE_LIMIT,
  };
}

function gitCommit(repoRoot, ref, label) {
  const result = runGit(repoRoot, ['rev-parse', '--verify', '--quiet', `${ref}^{commit}`]);
  const sha = result.stdout.trim();
  if (result.status !== 0 || !FULL_SHA_RE.test(sha)) {
    fail('pr-pack/ref-unavailable', 'revisions', `${label} "${ref}" does not resolve to a commit in ${repoRoot}.`, {
      subject: { repoRoot, ref: ref },
      supportedFixes: ['fetch the ref or declare one that exists in the local checkout'],
    });
  }
  return sha;
}

// Three-dot semantics: the PR base is merge-base(baseRef, headRef), never a
// two-dot diff against the branch tip. Returns the verified revisions.
export function verifyPackRevisions(pack, repoRoot) {
  const { manifest } = pack;
  const root = path.resolve(repoRoot);
  if (!fs.existsSync(root)) {
    fail('repository-evidence/root-unreadable', 'revisions', `Repository root ${root} does not exist.`, {
      subject: { repoRoot: root }, supportedFixes: ['pass --repo-root with the matching local Git checkout'],
    });
  }
  let headSha = manifest.headSha;
  let baseSha = manifest.baseSha;
  let mergeBase = null;
  if (manifest.baseRef && manifest.headRef) {
    const headRefSha = gitCommit(root, manifest.headRef, 'headRef');
    gitCommit(root, manifest.baseRef, 'baseRef');
    const result = runGit(root, ['merge-base', manifest.baseRef, manifest.headRef]);
    mergeBase = result.stdout.trim();
    if (result.status !== 0 || !FULL_SHA_RE.test(mergeBase)) {
      fail('pr-pack/merge-base-unavailable', 'revisions', `No merge-base between "${manifest.baseRef}" and "${manifest.headRef}".`, {
        subject: { repoRoot: root, baseRef: manifest.baseRef, headRef: manifest.headRef },
        supportedFixes: ['fetch both refs so they share history'],
      });
    }
    if (headSha && headSha !== headRefSha) {
      fail('pr-pack/head-sha-mismatch', 'revisions', `headSha ${headSha} does not match headRef "${manifest.headRef}" (${headRefSha}).`, {
        subject: { repoRoot: root, headRef: manifest.headRef }, evidence: { declared: headSha, resolved: headRefSha },
        supportedFixes: [`set headSha to ${headRefSha} or point headRef at the declared commit`],
      });
    }
    if (baseSha && baseSha !== mergeBase) {
      fail('pr-pack/base-sha-not-merge-base', 'revisions', `baseSha ${baseSha} is not merge-base(${manifest.baseRef}, ${manifest.headRef}) = ${mergeBase}; PR diagrams must describe the three-dot diff.`, {
        subject: { repoRoot: root, baseRef: manifest.baseRef, headRef: manifest.headRef }, evidence: { declared: baseSha, mergeBase },
        supportedFixes: [`set baseSha to ${mergeBase}`, 'run git merge-base <baseRef> <headRef> and author the diagrams against that commit'],
      });
    }
    headSha = headRefSha;
    baseSha = mergeBase;
  } else if (manifest.baseRef || manifest.headRef) {
    fail('pr-pack/refs-incomplete', 'revisions', 'baseRef and headRef must be declared together.', {
      supportedFixes: ['declare both refs, or declare baseSha and headSha only'],
    });
  } else {
    if (!headSha || !baseSha) {
      fail('pr-pack/revisions-required', 'revisions', '--repo-root verification needs baseRef/headRef or baseSha/headSha in the manifest.', {
        supportedFixes: ['declare baseRef and headRef (preferred) or both full SHAs'],
      });
    }
    gitCommit(root, headSha, 'headSha');
    gitCommit(root, baseSha, 'baseSha');
    const result = runGit(root, ['merge-base', baseSha, headSha]);
    mergeBase = result.stdout.trim();
    if (mergeBase !== baseSha) {
      fail('pr-pack/base-sha-not-merge-base', 'revisions', `baseSha ${baseSha} is not the merge-base of itself and headSha ${headSha} (${mergeBase || 'none'}).`, {
        subject: { repoRoot: root }, evidence: { declared: baseSha, mergeBase: mergeBase || null },
        supportedFixes: [mergeBase ? `set baseSha to ${mergeBase}` : 'declare a baseSha that shares history with headSha'],
      });
    }
  }
  return { repoRoot: root, baseSha, headSha, mergeBase, verified: true };
}

// Pins each diagram's evidence to the pack revisions: head for added/modified
// citations, base_revision for removed ghosts. Returns a snapshot diagram.
export function alignDiagramRevisions(view, { baseSha, headSha }) {
  const diagram = view.diagram;
  if (!view.evidence) return diagram;
  const repository = diagram.meta?.repository;
  if (!repository) {
    fail('repository-evidence/repository-required', 'views', `View "${view.id}" cites sources but has no /meta/repository.`, {
      subject: { view: view.id, path: '/meta/repository' },
      supportedFixes: ['add the pinned repository metadata or remove the sources'],
    });
  }
  if (headSha && repository.revision && repository.revision.toLowerCase() !== headSha) {
    fail('pr-pack/view-revision-mismatch', 'views', `View "${view.id}" pins /meta/repository/revision ${repository.revision} but the pack head is ${headSha}.`, {
      subject: { view: view.id, path: '/meta/repository/revision' }, evidence: { declared: repository.revision, headSha },
      supportedFixes: [`set revision to ${headSha}`],
    });
  }
  if (baseSha && repository.base_revision && repository.base_revision.toLowerCase() !== baseSha) {
    fail('pr-pack/view-base-revision-mismatch', 'views', `View "${view.id}" pins /meta/repository/base_revision ${repository.base_revision} but the pack merge-base is ${baseSha}.`, {
      subject: { view: view.id, path: '/meta/repository/base_revision' }, evidence: { declared: repository.base_revision, baseSha },
      supportedFixes: [`set base_revision to ${baseSha} or remove it`],
    });
  }
  return {
    ...diagram,
    meta: {
      ...diagram.meta,
      repository: {
        ...repository,
        ...(headSha && !repository.revision ? { revision: headSha } : {}),
        ...(baseSha && !repository.base_revision ? { base_revision: baseSha } : {}),
      },
    },
  };
}
