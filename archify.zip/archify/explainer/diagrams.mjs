import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { validateSchema } from '../renderers/shared/validator.mjs';
import { textUnits, SEMANTIC_SIGIL_FOOTPRINT } from '../renderers/shared/utils.mjs';
import { segmentIntersectsRect } from '../renderers/shared/geometry.mjs';
import { layoutReportFromSvg } from '../renderers/shared/layout-report.mjs';
import { formatNumber } from './whatif-engine.mjs';
import { escapeHtml } from './inline.mjs';
import { minimumNodeTextWidth } from '../renderers/shared/text-fit.mjs';
import { throwDiagnosticError, withIsolatedDiagnosticRecording } from '../renderers/shared/diagnostics.mjs';
import { createOwnedTempDirectory } from '../renderers/shared/owned-temp-directory.mjs';

const runFile = promisify(execFile);
const skillRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// Only shorthand-generated specs may try automatic alternatives. Explicit JSON
// and serialized specs keep their authored geometry. Entries expire with the spec.
const automaticLayouts = new WeakMap();
const TYPES = new Set(['architecture', 'workflow', 'sequence', 'dataflow', 'lifecycle', 'erd', 'class', 'tree', 'timeline', 'waterfall']);
const MAX_SPEC_BYTES = 4 * 1024 * 1024;
const MAX_DIAGRAM_BYTES = 32 * 1024 * 1024;
const ID = /^[a-zA-Z][a-zA-Z0-9_-]*$/;
const ROLES = new Set(['frontend', 'backend', 'database', 'cloud', 'security', 'messagebus', 'external']);
const GROUP_LENS = {
  en: { 'viewer.lens.title': 'Compare groups', 'viewer.lens.instruction': 'Choose a group to highlight.' },
  'zh-CN': { 'viewer.lens.title': '比较分组', 'viewer.lens.instruction': '选择一个分组以高亮对应元素。' },
  'zh-TW': { 'viewer.lens.title': '比較分組', 'viewer.lens.instruction': '選擇一個分組以反白對應元素。' },
  es: { 'viewer.lens.title': 'Comparar grupos', 'viewer.lens.instruction': 'Elige un grupo para resaltarlo.' },
  ko: { 'viewer.lens.title': '그룹 비교', 'viewer.lens.instruction': '강조할 그룹을 선택하세요.' },
  ar: { 'viewer.lens.title': 'مقارنة المجموعات', 'viewer.lens.instruction': 'اختر مجموعةً لتمييز عناصرها.' },
};
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const freezeBytes = bytes => ({ sha256: hash(bytes), bytes: bytes.length, contentBase64: bytes.toString('base64') });

function subject(context, pointer, extra = {}) {
  const map = context.sourceMap;
  let lookup = pointer, location;
  while (lookup && !location) {
    location = map instanceof Map ? map.get(lookup) : map?.[lookup];
    lookup = lookup.slice(0, lookup.lastIndexOf('/'));
  }
  location ||= {};
  return { component: 'diagram', line: location.line || context.line || 1, path: pointer,
    ...(location.column ? { column: location.column } : {}), ...(context.sourcePath ? { input: context.sourcePath } : {}),
    ...(context.panelId ? { panelId: context.panelId } : {}), ...extra };
}

function fail(context, reason, message, example, fixes = [], cause) {
  throwDiagnosticError(message, [{ code: `explainer/${reason}`, severity: 'error', message,
    subject: subject(context, context.pointer || '/', context.subject),
    evidence: { reason, example: example || 'Use a native diagram spec with matching diagram_type.', ...(cause ? { native: cause } : {}) },
    supportedFixes: fixes.length ? fixes : [`Use this form: ${example || 'native JSON'}`] }]);
}

function safeId(value, context) {
  if (!ID.test(value || '')) fail(context, 'diagram-id', 'Diagram identities must use the native identifier syntax.', 'api | API | backend');
  return value;
}

function inferredId(label) {
  const slug = label.normalize('NFKC').toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
  return ID.test(slug) ? slug : `actor-${hash(label).slice(0, 12)}`;
}

function rowParts(text) {
  let value = text.trim();
  if (value.startsWith('|') && value.endsWith('|')) value = value.slice(1, -1);
  return value.split('|').map(part => part.trim());
}

function duplicateCheck(items, context, kind) {
  const seen = new Set();
  for (const item of items) {
    if (seen.has(item.id)) fail(context, 'diagram-id-duplicate', `Duplicate ${kind} identity ${item.id}.`, 'Use a unique id for every declaration.');
    seen.add(item.id);
  }
}

// Estimated native workflow canvas width for a column assignment: the widest node per column plus the
// column gaps, which widen for edge labels. Measured within about 10% of real canvases. The native gate
// projects 8px edge labels onto a 930px reader, so 1240px is the hard limit; this keeps a margin.
const READABLE_WORKFLOW_WIDTH = 1100;
function workflowWidth(nodes, edges) {
  const columns = Math.max(...nodes.map(node => node.col)) + 1;
  const widest = Array(columns).fill(92), gaps = Array(Math.max(0, columns - 1)).fill(34);
  const colOf = new Map(nodes.map(node => [node.id, node.col]));
  for (const node of nodes) widest[node.col] = Math.max(widest[node.col], node.width || 0);
  for (const edge of edges) {
    const col = colOf.get(edge.from);
    if (colOf.get(edge.to) === col + 1) gaps[col] = Math.max(gaps[col], (edge.label ? textUnits(edge.label) * 5.4 : 0) + 16);
  }
  return widest.reduce((sum, width) => sum + width, 0) + gaps.reduce((sum, gap) => sum + gap, 0) + 80;
}

// Placement supplies native grid/lane hints only. Native renderers own sizing,
// ports, routes, labels, and all quality validation.
function rankedPlacements(nodes, edges, maxColumns = Infinity) {
  const ids = new Set(nodes.map(node => node.id));
  const outgoing = new Map(nodes.map(node => [node.id, []]));
  for (const edge of edges) if (ids.has(edge.from) && ids.has(edge.to) && edge.from !== edge.to) outgoing.get(edge.from).push(edge);
  // Only the placement graph omits DFS back edges. The native spec keeps every
  // authored relationship, including returns, parallel edges and self loops.
  const forward = new Map(nodes.map(node => [node.id, []]));
  const state = new Map();
  let feedback = false;
  for (const node of nodes) {
    if (state.has(node.id)) continue;
    const stack = [{ id: node.id, next: 0 }];
    state.set(node.id, 1);
    while (stack.length) {
      const frame = stack.at(-1), edge = outgoing.get(frame.id)[frame.next++];
      if (!edge) { state.set(frame.id, 2); stack.pop(); continue; }
      if (state.get(edge.to) === 1) { feedback = true; continue; }
      forward.get(frame.id).push(edge);
      if (!state.has(edge.to)) { state.set(edge.to, 1); stack.push({ id: edge.to, next: 0 }); }
    }
  }
  let proposed;
  // Keep the original assignment as the stable source model and fallback.
  for (const links of [forward, outgoing]) {
    const incoming = new Map(nodes.map(node => [node.id, 0]));
    for (const edges of links.values()) for (const edge of edges) incoming.set(edge.to, incoming.get(edge.to) + 1);
    const rank = new Map();
    const queue = nodes.filter(node => incoming.get(node.id) === 0).map(node => node.id);
    const visit = id => {
      if (!rank.has(id)) rank.set(id, 0);
      for (const edge of links.get(id)) {
        incoming.set(edge.to, incoming.get(edge.to) - 1);
        rank.set(edge.to, Math.max(rank.get(edge.to) || 0, rank.get(id) + 1));
        if (incoming.get(edge.to) === 0) queue.push(edge.to);
      }
    };
    for (let cursor = 0; cursor < queue.length; cursor++) visit(queue[cursor]);
    const columns = nodes.map(node => incoming.get(node.id) === 0 ? rank.get(node.id) : 0);
    if (links === forward && columns.some(col => col >= maxColumns)) continue;
    const nextRow = new Map();
    const placed = nodes.map((node, index) => {
      const col = columns[index];
      const row = nextRow.get(col) || 0;
      nextRow.set(col, row + 1);
      return { ...node, row, col };
    });
    if (links === forward && feedback) { proposed = placed; continue; }
    return { legacy: placed, proposed };
  }
}

/** Compile a small author shorthand into an existing native Archify model. */
export function compileExplainerDiagram(diagramType, rows, { title, id, line = 1, quality = 'showcase', locale = 'zh-CN' } = {}) {
  const context = { line, pointer: '/', id, diagramType, rowMap: {}, subject: { diagram: id, diagramType } };
  if (!TYPES.has(diagramType)) fail(context, 'diagram-type', 'Unknown native diagram type.', 'sequence');
  if (!Array.isArray(rows) || !rows.length) fail(context, 'diagram-rows', 'A shorthand diagram needs at least one row.', 'Client | API | 请求记录');
  const entries = rows.map((row, index) => {
    const ctx = { ...context, line: Number.isInteger(row?.line) ? row.line : line + index };
    const cells = Array.isArray(row) ? row : row?.cells;
    if (cells !== undefined) {
      if (!Array.isArray(cells) || !cells.length || cells.some(cell => typeof cell !== 'string')) fail(ctx, 'diagram-row', 'Each diagram row needs text cells.', 'Client | API | 请求记录');
      return { parts: cells.map(cell => cell.trim()), context: ctx };
    }
    const text = typeof row === 'string' ? row : row?.text;
    if (typeof text !== 'string' || !text.trim()) fail(ctx, 'diagram-row', 'Each diagram row needs text.', 'Client | API | 请求记录');
    return { parts: rowParts(text), context: ctx };
  });
  const spec = { schema_version: diagramType === 'workflow' ? 2 : 1, diagram_type: diagramType,
    meta: { title: title || id || diagramType, output: `${id && ID.test(id) ? id : 'diagram'}.html`, quality_profile: quality } };
  const expect = (entry, min, max, example) => {
    if (entry.parts.length < min || entry.parts.length > max || entry.parts.slice(0, min).some(part => !part)) {
      fail(entry.context, 'diagram-row', `Expected ${min === max ? min : `${min}–${max}`} pipe-separated fields.`, example);
    }
  };
  const edgeCounts = new Map();
  const edgeId = (from, to) => {
    const base = `${from}-to-${to}`;
    const count = (edgeCounts.get(base) || 0) + 1;
    edgeCounts.set(base, count);
    return `${base}-${count}`;
  };
  const collectRoles = (list, hasLegend) => {
    const roles = new Map(), body = [];
    for (const entry of list) {
      if (!entry.parts[0].startsWith('role ') || entry.parts[0].includes('>')) { body.push(entry); continue; }
      expect(entry, 2, 2, 'role frontend | Draft state');
      const role = safeId(entry.parts[0].slice(5).trim(), entry.context), label = entry.parts[1];
      if (!ROLES.has(role)) fail(entry.context, 'diagram-role', `Unknown node role "${role}".`, 'role frontend | Draft state');
      if (label.length > 80) fail(entry.context, 'diagram-role', 'Role label must be 80 characters or fewer.', 'role frontend | Draft state');
      if (/[{}]/.test(label)) fail(entry.context, 'diagram-role', 'Role label cannot contain "{" or "}" interpolation braces.', 'role frontend | State (id)');
      if (roles.has(role)) fail(entry.context, 'diagram-role-duplicate', `Duplicate role "${role}".`, 'role frontend | Draft state');
      roles.set(role, label);
      (spec.meta.translations ||= {})[`viewer.kind.${role}`] = label;
      if (hasLegend) ((spec.meta.legend ||= {}).entries ||= {})[role] = { label };
    }
    return { roles, body };
  };
  if (diagramType === 'sequence') {
    const { body } = collectRoles(entries, false);
    spec.participants = [];
    spec.messages = [];
    const aliases = new Map();
    const byId = new Map();
    for (const entry of body.filter(entry => entry.parts[0].startsWith('actor '))) {
      expect(entry, 2, 3, 'actor api | API | backend');
      const actor = { id: safeId(entry.parts[0].slice(6).trim(), entry.context), label: entry.parts[1], type: entry.parts[2] || 'backend' };
      context.rowMap[`/participants/${spec.participants.length}`] = entry.context.line;
      spec.participants.push(actor); byId.set(actor.id, actor); aliases.set(actor.label, actor.id); aliases.set(actor.id, actor.id);
    }
    const actorId = (label, ctx) => {
      if (aliases.has(label)) return aliases.get(label);
      const actor = { id: inferredId(label), label, type: 'external' };
      if (byId.has(actor.id)) fail(ctx, 'diagram-actor-collision', 'Actor labels resolve to the same id; declare explicit actor identities.', 'actor client | Client | frontend');
      spec.participants.push(actor); byId.set(actor.id, actor); aliases.set(label, actor.id);
      return actor.id;
    };
    // "phase | label" rows open a labelled band over the messages that follow, up to the next phase.
    const phases = [];
    for (const entry of body.filter(entry => !entry.parts[0].startsWith('actor '))) {
      if (entry.parts[0] === 'phase') { expect(entry, 2, 2, 'phase | TCP handshake'); phases.push({ label: entry.parts[1], first: spec.messages.length, context: entry.context }); continue; }
      expect(entry, 3, 4, 'Client | API | 请求记录 | return');
      const [fromLabel, toLabel, label, variant] = entry.parts;
      const from = actorId(fromLabel, entry.context), to = actorId(toLabel, entry.context);
      context.rowMap[`/messages/${spec.messages.length}`] = entry.context.line;
      spec.messages.push({ id: edgeId(from, to), from, to, label, y: 160 + spec.messages.length * 48, ...(variant ? { variant } : {}) });
    }
    phases.forEach((phase, index) => {
      const last = (phases[index + 1]?.first ?? spec.messages.length) - 1;
      if (last < phase.first) fail(phase.context, 'diagram-row', 'A phase needs at least one message after it.', 'phase | TCP handshake\n| browser | server | SYN |');
      (spec.segments ||= []).push({ from: spec.messages[phase.first].y - 22, to: spec.messages[last].y + 16, label: phase.label });
    });
    duplicateCheck(spec.participants, context, 'actor');
    if (!spec.messages.length) fail(context, 'diagram-rows', 'Sequence shorthand needs a message.', 'client | api | 请求记录');
  } else if (diagramType === 'architecture' || diagramType === 'workflow') {
    const { roles, body } = collectRoles(entries, true);
    const nodes = [], edges = [], lanes = new Map(), nodeLanes = new Map();
    for (const entry of body) {
      const route = entry.parts[0].match(/^([a-zA-Z][a-zA-Z0-9_-]*)\s*>\s*([a-zA-Z][a-zA-Z0-9_-]*)$/);
      if (diagramType === 'workflow' && entry.parts[0].startsWith('lane ')) {
        expect(entry, 2, 2, 'lane locate | Locate the cause');
        const laneId = safeId(entry.parts[0].slice(5).trim(), entry.context);
        if (lanes.has(laneId)) fail(entry.context, 'diagram-id-duplicate', 'Workflow lane ids must be unique.', 'lane locate | Locate the cause');
        lanes.set(laneId, { id: laneId, label: entry.parts[1] });
      } else if (route) {
        if (entry.parts.length > 3) fail(entry.context, 'diagram-row', 'An edge supports a label and optional native variant.', 'api > redis | 查询 | dashed');
        context.rowMap[`/${diagramType === 'architecture' ? 'connections' : 'edges'}/${edges.length}`] = entry.context.line;
        edges.push({ id: edgeId(route[1], route[2]), from: route[1], to: route[2], ...(entry.parts[1] ? { label: entry.parts[1] } : {}), ...(entry.parts[2] ? { variant: entry.parts[2] } : {}) });
      } else {
        if (diagramType === 'workflow') expect(entry, 2, 4, 'trace | Compare slow traces | backend | locate');
        else expect(entry, 2, 3, 'api | API | backend');
        context.rowMap[`/${diagramType === 'architecture' ? 'components' : 'nodes'}/${nodes.length}`] = entry.context.line;
        const node = { id: safeId(entry.parts[0], entry.context), label: entry.parts[1], type: entry.parts[2] || 'backend' };
        // Wide enough that the label stays centred between the corner icon and the opposite edge;
        // a narrower node drops the label below the icon, out of line with its neighbours.
        const labelWidth = Math.ceil(Math.max(textUnits(node.label) * 6.8 + 12, minimumNodeTextWidth(node.label, 11) + 2 * (SEMANTIC_SIGIL_FOOTPRINT + 2)));
        if (diagramType === 'workflow' && labelWidth > 92) node.width = labelWidth;
        // A question is a decision point: the native decision mark tells it apart from a step.
        if (diagramType === 'workflow' && /[?？]$/u.test(node.label)) node.icon = 'decision';
        else if (roles.has(node.type)) node.icon = 'none';
        if (entry.parts[3]) nodeLanes.set(node.id, { lane: safeId(entry.parts[3], entry.context), context: entry.context });
        nodes.push(node);
      }
    }
    duplicateCheck(nodes, context, 'node');
    if (!nodes.length) fail(context, 'diagram-rows', 'Shorthand diagram needs at least one node.', 'api | API | backend');
    const fitWidth = node => Math.ceil(textUnits(node.label) * 6.6 + 16);
    const architectureLayout = diagramType === 'architecture'
      ? { mode: 'grid', cols: 12, cellW: Math.max(176, ...nodes.map(fitWidth)), cellH: 76, gapX: 100, gapY: 110 } : null;
    const incoming = new Map(nodes.map(node => [node.id, []]));
    for (const edge of edges) incoming.get(edge.to)?.push(edge.from);
    const architectureModel = placed => {
      const cols = Math.max(1, ...placed.map(node => node.col + 1));
      if (cols > 12) fail(context, 'diagram-shorthand-limit', 'This architecture needs more than twelve native grid columns.', 'Use native JSON with explicit component positions.');
      // Order each column by where its upstream nodes sit, then centre it against the tallest column,
      // so a hub sits between the nodes it connects instead of on the first row.
      const height = Math.max(...Array.from({ length: cols }, (_, col) => placed.filter(node => node.col === col).length));
      const rowOf = new Map();
      for (let col = 0; col < cols; col++) {
        const column = placed.filter(node => node.col === col);
        const upstream = new Map(column.map(node => {
          const rows = incoming.get(node.id).filter(id => rowOf.has(id)).map(id => rowOf.get(id));
          return [node.id, rows.length ? rows.reduce((sum, row) => sum + row, 0) / rows.length : node.row];
        }));
        column.sort((a, b) => upstream.get(a.id) - upstream.get(b.id) || a.row - b.row)
          .forEach((node, i) => rowOf.set(node.id, Math.floor((height - column.length) / 2) + i));
      }
      return { layout: { ...architectureLayout, cols },
        components: placed.map(node => ({ ...node, row: rowOf.get(node.id), ...(fitWidth(node) > 120 ? { size: [fitWidth(node), 60] } : {}) })), connections: edges };
    };
    const workflowModel = placed => {
      const model = {};
      if (lanes.size) {
        for (const [id, { lane, context: ctx }] of nodeLanes) if (!lanes.has(lane)) fail(ctx, 'diagram-lane', `Node ${id} names an undeclared lane.`, 'lane locate | Locate the cause');
        const first = lanes.keys().next().value;
        const order = [...lanes.keys()];
        const ranked = [...placed].sort((a, b) => a.col - b.col || a.row - b.row).map(({ row, col, ...node }) => ({ ...node, lane: nodeLanes.get(node.id)?.lane || first }));
        // Prefer, in order: one row with phase labels above it; phase rows that step down so each hand-off
        // edge drops straight; phase rows that each restart at the left. Take the first that stays within
        // the readable width, since a wider canvas shrinks its edge labels below the native text floor.
        const row = [...ranked].sort((a, b) => order.indexOf(a.lane) - order.indexOf(b.lane));
        const used = [...lanes.values()].filter(lane => ranked.some(node => node.lane === lane.id));
        const sizes = used.map(lane => ranked.filter(node => node.lane === lane.id).length);
        const wrapped = stair => {
          const starts = sizes.map((_, i) => stair ? sizes.slice(0, i).reduce((sum, size) => sum + size - 1, 0) : 0);
          const nextCol = new Map(used.map((lane, i) => [lane.id, starts[i]]));
          return ranked.map(node => { const col = nextCol.get(node.lane); nextCol.set(node.lane, col + 1); return { ...node, col }; });
        };
        const single = row.map(({ lane, ...node }, col) => ({ ...node, lane: 'flow', col }));
        // Grouping by phase keeps the flow order only when each phase is one stretch of the flow.
        const inOrder = ranked.every((node, i) => i === 0 || order.indexOf(node.lane) >= order.indexOf(ranked[i - 1].lane));
        const candidates = [
          ...(inOrder && ranked.length <= 6 && placed.every(node => node.row === 0) ? [{ nodes: single, single: true }] : []),
          ...(inOrder && sizes.reduce((sum, size) => sum + size, 0) - (sizes.length - 1) <= 6 ? [{ nodes: wrapped(true) }] : []),
          { nodes: wrapped(false) },
        ];
        const chosen = candidates.find(candidate => workflowWidth(candidate.nodes, edges) <= READABLE_WORKFLOW_WIDTH) || candidates.at(-1);
        model.nodes = chosen.nodes;
        if (chosen.single) {
          model.lanes = [{ id: 'flow', label: spec.meta.title }];
          model.phases = order.map(id => ({ id, label: lanes.get(id).label, cols: row.flatMap((node, col) => node.lane === id ? [col] : []) })).filter(phase => phase.cols.length).map(({ cols, ...phase }) => ({ ...phase, fromCol: cols[0], toCol: cols.at(-1) }));
        } else model.lanes = used;
        if (model.nodes.some(node => node.col > 5)) fail(context, 'diagram-shorthand-limit', 'A workflow lane holds at most six nodes.', 'Split the process into another lane.');
        model.edges = edges;
      } else {
        // A process too wide for one readable row wraps by columns into stacked bands, keeping each
        // band's branch rows, and steps each band down under the end of the previous one where six
        // columns allow, the same way declared phases do.
        const fits = laid => laid.every(node => node.col <= 5) && workflowWidth(laid, edges) <= READABLE_WORKFLOW_WIDTH;
        let wrapped;
        if (!fits(placed)) {
          const branchRows = Math.max(...placed.map(node => node.row)) + 1;
          for (let size = 5; size >= 2 && !wrapped; size--) {
            for (const stair of [true, false]) {
              const laid = placed.map(node => { const band = Math.floor(node.col / size); return { ...node, row: band * branchRows + node.row, col: (stair ? band * (size - 1) : 0) + node.col - band * size }; });
              const used = [...new Set(laid.map(node => node.row))].sort((a, b) => a - b);
              const compact = laid.map(node => ({ ...node, row: used.indexOf(node.row) }));
              if (fits(compact)) { wrapped = compact; break; }
            }
          }
        }
        const rows = wrapped || placed;
        if (rows.some(node => node.col > 5)) fail(context, 'diagram-shorthand-limit', 'Native workflow columns are limited to 0–5.', 'Declare phase lanes with "lane <id> | label" rows and assign nodes to them.');
        model.lanes = Array.from({ length: Math.max(1, ...rows.map(node => node.row + 1)) }, (_, row) => ({ id: `lane-${row}`, label: wrapped ? `${spec.meta.title} · ${row + 1}` : row ? `${locale.startsWith('zh') ? '分支' : 'Branch'} ${row}` : spec.meta.title }));
        model.nodes = rows.map(({ row, ...node }) => ({ ...node, lane: `lane-${row}` }));
        model.edges = edges;
      }
      return model;
    };
    const placements = rankedPlacements(nodes, edges, diagramType === 'architecture' ? 12 : Infinity);
    const model = architectureLayout ? architectureModel : workflowModel;
    Object.assign(spec, model(placements.legacy));
    if (placements.proposed) {
      try {
        const alternative = withIsolatedDiagnosticRecording(() => ({ ...spec, ...model(placements.proposed) }));
        automaticLayouts.set(spec, { source: JSON.stringify(spec), spec: alternative });
      } catch (error) {
        if (!error.archifyDiagnostics?.length || !error.archifyDiagnostics.every(entry => entry.code === 'explainer/diagram-shorthand-limit')) throw error;
      }
    }
  } else if (diagramType === 'tree') {
    spec.nodes = entries.map((entry, index) => {
      expect(entry, 2, 3, 'api | API 服务 | root');
      context.rowMap[`/nodes/${index}`] = entry.context.line;
      const [nodeId, label, parent] = entry.parts;
      return { id: safeId(nodeId, entry.context), label, ...(parent && parent !== '-' ? { parent: safeId(parent, entry.context) } : {}) };
    });
    duplicateCheck(spec.nodes, context, 'node');
  } else if (diagramType === 'timeline') {
    spec.meta.evidence = 'illustrative';
    const lanes = new Map(); spec.events = [];
    for (const entry of entries) {
      if (entry.parts[0].startsWith('lane ')) {
        expect(entry, 2, 2, 'lane release | 发布');
        const laneId = safeId(entry.parts[0].slice(5).trim(), entry.context);
        if (lanes.has(laneId)) fail(entry.context, 'diagram-id-duplicate', 'Timeline lane ids must be unique.', 'lane release | 发布');
        lanes.set(laneId, { id: laneId, label: entry.parts[1] });
      }
    }
    for (const entry of entries.filter(entry => !entry.parts[0].startsWith('lane '))) {
      expect(entry, 3, 5, 'deploy | 2026-10-01T10:00:00+08:00 | 发布 v2 | release | change');
      const [eventId, at, eventTitle, authoredLane, kind] = entry.parts;
      const lane = authoredLane || 'events'; safeId(lane, entry.context);
      if (!lanes.has(lane)) lanes.set(lane, { id: lane, label: lane });
      context.rowMap[`/events/${spec.events.length}`] = entry.context.line;
      spec.events.push({ id: safeId(eventId, entry.context), at, title: eventTitle, lane, ...(kind ? { kind } : {}) });
    }
    spec.lanes = [...lanes.values()]; duplicateCheck(spec.events, context, 'event');
  } else if (diagramType === 'erd') {
    const entities = new Map(); spec.relationships = [];
    for (const entry of entries.filter(entry => entry.parts[0].startsWith('entity '))) {
      expect(entry, 2, 2, 'entity user | 用户');
      const entityId = safeId(entry.parts[0].slice(7).trim(), entry.context);
      if (entities.has(entityId)) fail(entry.context, 'diagram-id-duplicate', 'Entity ids must be unique.', 'entity user | 用户');
      entities.set(entityId, { id: entityId, label: entry.parts[1], row: 0, col: entities.size, attributes: [] });
    }
    for (const entry of entries.filter(entry => !entry.parts[0].startsWith('entity '))) {
      const route = entry.parts[0].match(/^([a-zA-Z][a-zA-Z0-9_-]*)\s*>\s*([a-zA-Z][a-zA-Z0-9_-]*)$/);
      if (route) {
        expect(entry, 2, 3, 'order > user | many:one | 下单者');
        const cardinality = entry.parts[1].match(/^(one|many):(one|many)$/);
        if (!cardinality) fail(entry.context, 'diagram-cardinality', 'Relationship cardinality must be explicit.', 'order > user | many:one | 下单者');
        spec.relationships.push({ id: edgeId(route[1], route[2]), from: route[1], to: route[2], fromCardinality: cardinality[1], toCardinality: cardinality[2], ...(entry.parts[2] ? { label: entry.parts[2] } : {}) });
      } else {
        expect(entry, 2, 4, 'order.user_id | bigint | fk | user.id');
        const field = entry.parts[0].match(/^([a-zA-Z][a-zA-Z0-9_-]*)\.([a-zA-Z][a-zA-Z0-9_]*)$/);
        if (!field || !entities.has(field[1])) fail(entry.context, 'diagram-field', 'A field must name an explicitly declared entity.', 'entity user | 用户\nuser.id | bigint | pk');
        const roles = entry.parts[2]?.split(',').map(value => value.trim()).filter(Boolean);
        entities.get(field[1]).attributes.push({ name: field[2], type: entry.parts[1], ...(roles?.length ? { key: roles.length === 1 ? roles[0] : roles } : {}), ...(entry.parts[3] ? { references: entry.parts[3] } : {}) });
      }
    }
    spec.layout = { mode: 'grid', gapX: 96, gapY: 64 }; spec.entities = [...entities.values()];
  } else {
    fail(context, 'diagram-shorthand-unsupported', `The ${diagramType} type uses native JSON instead of shorthand rows.`, `Use spec with diagram_type: ${diagramType}, or source: diagram.${diagramType}.json.`);
  }
  try { validateSchema(diagramType, spec); } catch (error) { rethrowNative(error, context, 'diagram-schema'); }
  return spec;
}

function rethrowNative(error, context, reason) {
  let details = error.archifyDiagnostics || error.diagnostics || [];
  if (!details.length && Array.isArray(error.checks)) {
    details = error.checks.filter(check => !check.ok).flatMap(check => (check.details?.length ? check.details : [`Native check ${check.name} failed.`])
      .map(message => ({ code: `check/${check.name}`, severity: 'error', message, evidence: check })));
    if (!details.length) details = (error.composition?.issues || []).filter(issue => issue.severity === 'error')
      .map(issue => ({ ...issue, message: issue.code === 'composition/desktop-readability' && issue.projectedFontPx
        ? `Text "${issue.text}" on ${issue.owner?.kind || 'element'} ${issue.owner?.id || ''} would show at ${issue.projectedFontPx.toFixed(1)}px, below ${issue.minimumProjectedFontPx}px: the diagram is ${Math.round(issue.viewBoxWidth)}px wide and shrinks to ${Math.round(issue.scale * 100)}% on the page. Make it narrower: at most four or five nodes per row, shorter node labels, or phases.`
        : issue.detail || `Native quality check ${issue.code} failed.` }));
  }
  if (details.length) throwDiagnosticError('Native diagram validation failed.', details.map(entry => ({
    code: `explainer/${reason}`, severity: entry.severity || 'error', message: entry.message,
    subject: subject({ ...context, line: context.rowMap?.[entry.subject?.path?.match(/^\/[^/]+\/\d+/)?.[0]] || context.line },
      (context.pointer && entry.subject?.path && !context.rowMap) ? `${context.pointer}/spec${entry.subject.path}` : context.pointer || '/',
      { diagramType: context.diagramType, diagram: context.id }),
    evidence: { reason, example: `Use a valid native ${context.diagramType || 'diagram'} JSON specification.`, native: entry },
    supportedFixes: entry.supportedFixes?.length ? entry.supportedFixes : ['Repair the native diagnostic and render again.'],
  })));
  fail(context, reason, 'The native diagram toolchain could not complete this diagram.', `Use a valid native ${context.diagramType || 'diagram'} JSON specification.`, [], { message: String(error.message || error).slice(0, 1000) });
}

function readSpec(baseDir, relative, context) {
  if (!baseDir || typeof relative !== 'string' || !relative || path.isAbsolute(relative) || /[\\:\u0000-\u001f?#]/.test(relative)
      || relative.split('/').some(part => !part || part === '.' || part === '..' || part.toLowerCase() === '.git') || !/\.json$/i.test(relative)) {
    fail(context, 'diagram-source-path', 'Diagram source must be a relative JSON file inside the input directory.', 'diagrams/request.sequence.json');
  }
  let fd;
  try {
    const root = fs.realpathSync(baseDir), ancestors = [[root, fs.lstatSync(root)]];
    let candidate = root;
    for (const part of relative.split('/')) {
      candidate = path.join(candidate, part); const stat = fs.lstatSync(candidate);
      if (stat.isSymbolicLink()) fail(context, 'diagram-source-symlink', 'Diagram sources may not traverse symbolic links.', 'request.sequence.json');
      ancestors.push([candidate, stat]);
    }
    const expected = ancestors.at(-1)[1];
    if (!expected.isFile() || expected.size > MAX_SPEC_BYTES) fail(context, 'diagram-source-size', 'Diagram source must be a regular JSON file smaller than 4 MiB.', 'request.sequence.json');
    fd = fs.openSync(candidate, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    const before = fs.fstatSync(fd);
    const same = (a, b) => a.dev === b.dev && a.ino === b.ino && a.size === b.size && a.mtimeMs === b.mtimeMs;
    if (!same(before, expected)) fail(context, 'diagram-source-changed', 'Diagram source changed while being frozen.', 'Finish edits before rendering.');
    const bytes = Buffer.alloc(before.size);
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, offset);
      if (!count) break;
      offset += count;
    }
    if (offset !== bytes.length || !same(before, fs.fstatSync(fd)) || !ancestors.every(([name, stat]) => { const current = fs.lstatSync(name); return !current.isSymbolicLink() && same(current, stat); })) {
      fail(context, 'diagram-source-changed', 'Diagram source changed while being frozen.', 'Finish edits before rendering.');
    }
    return bytes;
  } catch (error) {
    if (error.archifyDiagnostics) throw error;
    fail(context, 'diagram-source-read', 'Diagram source cannot be read safely inside the input directory.', 'request.sequence.json');
  } finally { if (fd !== undefined) fs.closeSync(fd); }
}

function decode(value) {
  return value.replace(/&(?:quot|apos|lt|gt|amp|#\d+|#x[\da-f]+);/gi, entity => {
    const named = { '&quot;': '"', '&apos;': "'", '&lt;': '<', '&gt;': '>', '&amp;': '&' };
    if (Object.hasOwn(named, entity)) return named[entity];
    const code = entity.startsWith('&#x') ? parseInt(entity.slice(3, -1), 16) : parseInt(entity.slice(2, -1), 10);
    return Number.isFinite(code) && code <= 0x10ffff ? String.fromCodePoint(code) : entity;
  });
}

function attrs(tag) {
  return Object.fromEntries([...tag.matchAll(/([\w:-]+)="([^"]*)"/g)].map(match => [match[1], decode(match[2])]));
}

function semanticOf(svg) {
  const nodes = new Map(), edges = new Map();
  for (const match of svg.matchAll(/<[a-zA-Z][^>]*>/g)) {
    const values = attrs(match[0]);
    if (values['data-node-id']) nodes.set(values['data-node-id'], { id: values['data-node-id'], label: values['data-node-label'] || values['data-node-id'], svgId: values.id });
    if (values['data-edge-from'] && values['data-edge-to']) {
      const id = values['data-edge-id'] || values['data-edge-key'] || `${values['data-edge-from']}~${values['data-edge-to']}`;
      edges.set(id, { id, from: values['data-edge-from'], to: values['data-edge-to'], label: values['data-edge-label'] || '',
        ...(values['data-edge-key'] ? { key: values['data-edge-key'] } : {}) });
    }
  }
  return { nodes: [...nodes.values()], edges: [...edges.values()] };
}

function changesPreview(svg, changes, semantic, context) {
  if (changes !== undefined && !Array.isArray(changes)) fail(context, 'diagram-change', 'Structural changes must be an array of explicit target marks.', '[{target:"api",change:"modified"}]');
  const nodes = new Set(semantic.nodes.map(node => node.id)), edges = new Set(semantic.edges.map(edge => edge.id));
  const byTarget = new Map();
  for (const change of changes || []) {
    if (!change || !['added', 'removed', 'modified'].includes(change.change) || typeof change.target !== 'string') fail(context, 'diagram-change', 'A structural change needs an explicit target and change type.', '{target:"api",change:"modified"}');
    if (!nodes.has(change.target) && !edges.has(change.target)) fail(context, 'diagram-change-target', 'The change target is absent from the authored native topology.', '{target:"api",change:"modified"}');
    if (byTarget.has(change.target)) fail(context, 'diagram-change-duplicate', 'A target may have only one structural change mark.', '{target:"api",change:"modified"}');
    byTarget.set(change.target, change.change);
  }
  return svg.replace(/<[a-zA-Z][^>]*>/g, tag => {
    const values = attrs(tag);
    const edgeId = values['data-edge-from'] && values['data-edge-to']
      ? values['data-edge-id'] || values['data-edge-key'] || `${values['data-edge-from']}~${values['data-edge-to']}`
      : undefined;
    const change = byTarget.get(values['data-node-id']) || (edgeId !== undefined ? byTarget.get(edgeId) : undefined);
    return change ? tag.replace(/(\/?>)$/, ` data-explainer-change="${change}"$1`) : tag;
  });
}

async function nativeProcess(script, args, options) {
  try {
    const result = await runFile(process.execPath, [script, ...args], { cwd: options.cwd || skillRoot, maxBuffer: MAX_DIAGRAM_BYTES,
      timeout: 120000, env: { ...process.env, ARCHIFY_DIAGNOSTIC_FORMAT: 'json', ARCHIFY_QUALITY_PROFILE: options.quality,
        ...(options.repoRoot ? { ARCHIFY_REPO_ROOT: path.resolve(options.repoRoot) } : {}) } });
    return result;
  } catch (error) {
    let native;
    for (const output of [error.stdout, error.stderr]) { try { native = JSON.parse(output); if (native.diagnostics) break; } catch {} }
    // Publish only the selected failure, after automatic alternatives are exhausted.
    error.nativeResult = native;
    throw error;
  }
}

function layoutCost(spec) {
  const columns = new Map((spec.components || spec.nodes || []).map(node => [node.id, node.col]));
  return (spec.connections || spec.edges || []).filter(edge => edge.from !== edge.to && columns.get(edge.from) === columns.get(edge.to)).length;
}

function retryableLayoutFailure(result) {
  const diagnostics = (result.diagnostics || result.archifyDiagnostics || []).filter(entry => entry.severity !== 'warning');
  if (diagnostics.length) return diagnostics.every(entry => /^(?:layout|composition|clean-flow|workflow)\//u.test(entry.code));
  return result.composition?.status === 'fail' && result.checks?.every(check => check.ok
    || !['file_readable', 'single_svg', 'finite_svg', 'svg_path_data'].includes(check.name));
}

/** Freeze native diagrams, validate, render, and check without a per-child browser gate. */
export async function prepareExplainerDiagrams(document, { repoRoot, baseDir, quality = 'showcase', sourceMap, sourcePath } = {}) {
  const diagrams = Object.create(null), dependencies = [], blocks = [];
  for (const [panelIndex, panel] of (document.panels || []).entries()) {
    for (const [blockIndex, block] of (panel.blocks || []).entries()) if (block.type === 'diagram') blocks.push({ block, pointer: `/panels/${panelIndex}/blocks/${blockIndex}`, panelId: panel.id });
  }
  // Legacy flat draft shapes are accepted only as adapter inputs; canonical
  // explainer validation remains the parent pipeline's responsibility.
  for (const [blockIndex, block] of (document.blocks || []).entries()) if (block.type === 'diagram') blocks.push({ block, pointer: `/blocks/${blockIndex}` });
  for (const entry of blocks) {
    const { block, pointer, panelId } = entry, context = { pointer, panelId, sourceMap, sourcePath, id: block.id, diagramType: block.diagramType };
    if (typeof block.id !== 'string' || !block.id || Object.hasOwn(diagrams, block.id)) fail(context, 'diagram-id', 'Diagram blocks need unique stable identities.', '{id:"request",type:"diagram",diagramType:"sequence",spec:{...}}');
    if (!TYPES.has(block.diagramType)) fail(context, 'diagram-type', 'Unknown native diagram type.', 'sequence');
    if ((block.spec !== undefined) === (block.source !== undefined)) fail(context, 'diagram-input', 'Provide exactly one inline spec or relative source.', 'source: request.sequence.json');
    let originalBytes;
    if (block.source !== undefined) originalBytes = readSpec(baseDir, block.source, { ...context, pointer: `${pointer}/source` });
    else {
      try { originalBytes = Buffer.from(JSON.stringify(block.spec)); } catch { fail(context, 'diagram-spec', 'Inline native JSON must be serializable.', 'spec: {schema_version:1,diagram_type:"tree",meta:{title:"Tree"},nodes:[...]}'); }
      if (originalBytes.length > MAX_SPEC_BYTES) fail(context, 'diagram-source-size', 'Inline diagram JSON exceeds 4 MiB.', 'Use a smaller native JSON specification.');
    }
    let original;
    try { original = JSON.parse(originalBytes.toString('utf8')); } catch { fail(context, 'diagram-json', 'Diagram source is not valid JSON.', '{"schema_version":1,"diagram_type":"sequence","meta":{"title":"Request"},"participants":[],"messages":[]}'); }
    if (!original || typeof original !== 'object' || Array.isArray(original) || original.diagram_type !== block.diagramType) fail(context, 'diagram-type-mismatch', 'Native specification diagram_type must match its explainer block.', `diagram_type: ${block.diagramType}`);
    dependencies.push({ kind: 'diagram-spec', id: block.id, ...(block.source ? { path: path.resolve(baseDir, block.source), relativePath: block.source } : { inline: true }), ...freezeBytes(originalBytes) });
    const automatic = automaticLayouts.get(block.spec);
    const candidates = automatic?.source === originalBytes.toString('utf8')
      ? [original, automatic.spec].sort((left, right) => layoutCost(left) - layoutCost(right)) : [original];
    const temporary = createOwnedTempDirectory('archify-explainer-diagram-');
    try {
      const failures = [];
      for (const [index, candidate] of candidates.entries()) {
        const directory = index ? path.join(temporary.path, String(index)) : temporary.path;
        if (index) fs.mkdirSync(directory);
        const output = path.join(directory, 'diagram.html'), input = path.join(directory, 'diagram.json');
        // Inline diagrams belong to the explainer's reading context. Keep the
        // original author bytes frozen; apply inheritance only to native render
        // input. Referenced standalone specs retain their own locale defaults.
        const translations = candidate.meta?.translations || {};
        const hasTranslations = Object.keys(translations).length > 0;
        const customKinds = Object.keys(translations).some(key => key.startsWith('viewer.kind.'));
        const pageDefaultLocale = document.diagram_type === 'explainer' ? 'zh-CN' : 'en';
        const effectiveLocale = candidate.meta?.locale ?? document.meta?.locale ?? (block.spec !== undefined && hasTranslations ? pageDefaultLocale : undefined);
        const inheritedLocale = block.spec !== undefined && candidate.meta?.locale === undefined && effectiveLocale !== undefined
          ? { locale: effectiveLocale } : {};
        const lensKey = effectiveLocale ? Object.keys(GROUP_LENS).find(key => key.toLowerCase() === effectiveLocale.toLowerCase()) : undefined;
        const lensDefaults = block.spec !== undefined && customKinds
          ? GROUP_LENS[lensKey] || (effectiveLocale?.toLowerCase().startsWith('zh') ? GROUP_LENS['zh-CN'] : GROUP_LENS.en)
          : null;
        const mergedTranslations = lensDefaults ? { ...lensDefaults, ...translations } : candidate.meta?.translations;
        const spec = { ...candidate, meta: { ...candidate.meta, ...inheritedLocale, ...(mergedTranslations ? { translations: mergedTranslations } : {}), output: 'diagram.html', quality_profile: quality } };
        try { validateSchema(block.diagramType, spec); } catch (error) { rethrowNative(error, context, 'diagram-schema'); }
        fs.writeFileSync(input, JSON.stringify(spec), { flag: 'wx' });
        let stage = 'diagram-render';
        try {
          await nativeProcess(path.join(skillRoot, 'renderers', block.diagramType, `render-${block.diagramType}.mjs`), [input, output], { repoRoot, quality, cwd: directory });
          stage = 'diagram-check';
          const checked = await nativeProcess(path.join(skillRoot, 'scripts/check-render-output.mjs'), [output], { repoRoot, quality, cwd: directory });
          let check;
          try { check = JSON.parse(checked.stdout); } catch { fail(context, 'diagram-check-receipt', 'Native checker returned no structured receipt.', 'Rerun the native diagram check.'); }
          if (check.ok === false) throw Object.assign(new Error('Native diagram check failed.'), { nativeResult: check });
          const bytes = fs.readFileSync(output);
          if (bytes.length > MAX_DIAGRAM_BYTES) fail(context, 'diagram-artifact-size', 'The native diagram artifact exceeds 32 MiB.', 'Use a smaller native diagram.');
          const html = bytes.toString('utf8');
          const preview=nativeExplainerPreview(html,block.changes,context);
          // Preview styles are derived from html at render time; storing them again would double the page.
          diagrams[block.id] = { diagramType: block.diagramType, spec: original, html, ...preview, sha256: hash(bytes), bytes: bytes.length,
            specification: freezeBytes(originalBytes), checks: { validate: { ok: true }, render: { ok: true }, check },
            ...(block.changes ? { changes: block.changes.map(change => ({ ...change })) } : {}) };
          break;
        } catch (error) {
          if (!Object.hasOwn(error, 'nativeResult')) throw error;
          const result = error.nativeResult || error;
          if (!retryableLayoutFailure(result)) rethrowNative(result, context, stage);
          failures.push({ candidate, result, stage });
        }
      }
      if (!diagrams[block.id]) {
        const failure = failures.find(entry => entry.candidate === original) || failures.at(-1);
        rethrowNative(failure.result, context, failure.stage);
      }
    } finally { await temporary.cleanup(); }
  }
  return { diagrams, dependencies };
}

/** Resolve a reference against the actual native SVG graph, including real routes. */
export function validateExplainerDiagramTarget(diagrams, target, { sourceMap, sourcePath, pointer = '/', line = 1 } = {}) {
  const context = { sourceMap, sourcePath, pointer, line };
  const diagram = diagrams?.[target?.diagram];
  if (!diagram) fail(context, 'diagram-reference', 'The reference names an unknown diagram block.', '{diagram:"request",node:"api"}');
  const nodes = new Set(diagram.semantic.nodes.map(node => node.id)), edges = diagram.semantic.edges;
  if (target.node !== undefined && !nodes.has(target.node)) fail(context, 'diagram-node-reference', 'The reference names a node absent from the native diagram.', `{diagram:"${target.diagram}",node:"${diagram.semantic.nodes[0]?.id || 'api'}"}`);
  if (target.edges !== undefined && (!Array.isArray(target.edges) || !target.edges.length || target.edges.some(id => !edges.some(edge => edge.id === id)))) fail(context, 'diagram-edge-reference', 'The reference names an edge absent from the native diagram.', `{diagram:"${target.diagram}",edges:["${edges[0]?.id || 'api-to-db-1'}"]}`);
  if (target.route !== undefined) {
    if (!Array.isArray(target.route) || target.route.length !== 2 || !target.route.every(id => nodes.has(id))) fail(context, 'diagram-route-reference', 'A route needs two real native node identities.', `{diagram:"${target.diagram}",route:["api","db"]}`);
    const [from, to] = target.route, visited = new Set([from]), queue = [from];
    for (let index = 0; index < queue.length; index++) for (const edge of edges.filter(edge => edge.from === queue[index])) if (!visited.has(edge.to)) { visited.add(edge.to); queue.push(edge.to); }
    if (!visited.has(to)) fail(context, 'diagram-route-reference', 'No directed route connects these nodes in the native diagram.', `{diagram:"${target.diagram}",route:["${edges[0]?.from || 'api'}","${edges[0]?.to || 'db'}"]}`);
  }
  return true;
}

// Older workflow SVGs expose lane frames and titles, but omit authored IDs.
function previewLanesFromSvg(svg) {
  return Array.from(svg.matchAll(/(<rect\b[^>]*\bdata-composition-frame-kind="lane"[^>]*>)\s*<text\b[^>]*>([^<]*)<\/text>/gu),
    ([,frame,title])=>({id:attrs(frame)['data-lane-id'] ?? null, label:decode(title).replace(/^[^/]+ \/ /u,'')}));
}

export function nativePreviewLanes(html) {
  return previewLanesFromSvg(primarySvg(html) || '');
}

const primarySvg = html => html?.match(/<svg\b[^>]*\bdata-quality-profile="[^"]*"[^>]*>[\s\S]*?<\/svg>/)?.[0];

// Rebuild the preview and semantic graph from the frozen native output when checking a page.
export function nativeExplainerPreview(html, changes, context = {}) {
  const svg = primarySvg(html);
  if (!svg) fail(context, 'diagram-svg', 'The native output is missing its primary semantic SVG.', 'Re-render the native diagram.');
  const semantic = semanticOf(svg);
  const previewLanes = previewLanesFromSvg(svg);
  return { svg: changesPreview(svg, changes, semantic, context), semantic, ...(previewLanes.length ? {previewLanes} : {}) };
}

export function scenarioDiagramTargets(block, diagram, context) {
  if (!diagram?.semantic) fail(context, 'scenario-target', 'The bound native diagram is missing.', 'Prepare the bound native diagram.');
  const nodes = new Map(diagram.semantic.nodes.map(node => [node.id, node]));
  const edges = diagram.semantic.edges;
  const problem = (pointer,message) => fail({...context,pointer:context.pointer+pointer},'scenario-target',message,'Use an unambiguous node or directed edge from the native output.');
  function node(id, pointer) {
    if (!nodes.has(id)) problem(pointer,`Node ${id} is absent from the native diagram.`);
    return nodes.get(id);
  }
  function edge(selector, pointer) {
    const matches = edges.filter(edge => selector.id !== undefined ? edge.id === selector.id : edge.from === selector.from && edge.to === selector.to);
    const name = selector.id ?? `${selector.from}~${selector.to}`;
    if (!matches.length) problem(pointer,`Edge ${name} is absent from the native diagram.`);
    if (matches.length > 1) problem(pointer,`Directed hop ${name} is ambiguous. Select one of ${matches.map(edge=>edge.id).join(', ')} by ID.`);
    return matches[0];
  }
  const active = block.active.map((row,i) => {
    const path = `/active/${i}`;
    const chosen = row.edges.map((item,j) => edge(item,`${path}/edges/${j}`));
    const selected = row.nodes.map((id,j)=>node(id,`${path}/nodes/${j}`).id).concat(chosen.flatMap(edge=>[edge.from,edge.to]));
    return { key:row.case,nodes:[...new Set(selected)],edges:[...new Set(chosen.map(edge=>edge.id))] };
  });
  const badges = (block.badges || []).map((badge,i) => {
    const path = `/badges/${i}`;
    if (badge.node !== undefined) return { kind:'node', target:node(badge.node,path+'/node'), metric:badge.metric };
    return { kind:'edge', target:edge(badge.edge,path+'/edge'), metric:badge.metric };
  });
  return { active, badges };
}

function midpoint(points) {
  const distances = points.slice(1).map(([x,y],i)=>Math.hypot(x-points[i][0],y-points[i][1]));
  let remaining = distances.reduce((sum,value)=>sum+value,0)/2;
  for (const [i,distance] of distances.entries()) {
    if (distance > 0 && remaining <= distance) {
      const [x,y]=points[i], [endX,endY]=points[i+1], part=remaining/distance;
      return [x+(endX-x)*part,y+(endY-y)*part];
    }
    remaining-=distance;
  }
  return points[0];
}

function badgeSlots(svg, badges, metrics, diagramType) {
  const geometry = layoutReportFromSvg(svg,diagramType);
  const boxes = new Map(geometry.nodes.filter(node=>node.width>0&&node.height>0).map(node=>[node.id,node]));
  const routes = new Map(geometry.edges.map(edge=>[edge.id,edge.points]));
  const view = /\bviewBox="([^"]+)"/u.exec(svg)?.[1].split(/[ ,]+/u).map(Number) || [0,0,640,400];
  const [left,top,width,height] = view;
  // Native node cards and routed-edge labels publish their boxes as SVG rects.
  // Frames surround their contents and therefore do not occupy the entire interior.
  const obstacles = [...svg.matchAll(/<rect\b[^>]*>/gu)].map(match=>attrs(match[0]))
    .filter(rect=>!rect.transform&&!rect.fill?.startsWith('url(')&&!rect['data-composition-frame-kind']&&rect['data-graph-role']!=='structural-frame')
    .map(rect=>({x:Number(rect.x),y:Number(rect.y),width:Number(rect.width),height:Number(rect.height)}))
    .filter(rect=>rect.width>0&&rect.height>0&&Number.isFinite(rect.x)&&Number.isFinite(rect.y));
  // Standalone headings have no background rect. An em per text unit leaves
  // room for the native font, including bold labels and wide characters.
  const labels = [];
  for (const [,tag,content] of svg.matchAll(/(<text\b[^>]*>)([\s\S]*?)<\/text>/gu)) {
    const label = attrs(tag);
    const x = Number(label.x), y = Number(label.y), size = Number(label['font-size'] || 16);
    if (![x,y,size].every(Number.isFinite) || size<=0) continue;
    const text = decode(content.replace(/<[^>]*>/gu,'')).trim();
    if (!text) continue;
    const width = Math.max(Number(label.textLength) || 0, size*textUnits(text));
    const alignment = label['text-anchor']==='middle' ? .5 : label['text-anchor']==='end' ? 1 : 0;
    labels.push({x:x-width*alignment,y:y-size,width,height:size*1.3});
  }
  obstacles.push(...labels);
  const overlap = (a,b) => a.x < b.x+b.width+3 && b.x < a.x+a.width+3 && a.y < b.y+b.height+3 && b.y < a.y+a.height+3;
  const nativeBottom = ['architecture','workflow'].includes(diagramType) ?
    Math.max(top,...obstacles.map(rect=>rect.y+rect.height),...geometry.edges.flatMap(edge=>edge.points.map(point=>point[1]))) :
    top+height;
  const marginTop = nativeBottom + 16;
  let bottom = top+height;
  let right = left+width;
  const nativeCoordinates = ['architecture','workflow'].includes(diagramType);
  const slots = badges.map(badge=>{
    const metric = metrics.get(badge.metric).block;
    const box = nativeCoordinates && badge.kind==='node' ? boxes.get(badge.target.id) : undefined;
    const points = nativeCoordinates && badge.kind==='edge' ? routes.get(badge.target.id) : undefined;
    const anchor = box ? [box.x+box.width/2,box.y+box.height/2] : points?.length ? midpoint(points) : undefined;
    const label = badge.target.label || badge.target.id;
    const w = Math.max(112, Math.ceil(8*textUnits(formatNumber(-1e12,metric.digits,metric.unit)) + 18));
    const h = 25;
    const [x,y] = anchor || [0,0];
    const gap = 8, hw=(box?.width||0)/2, hh=(box?.height||0)/2;
    function leaderTo(end) {
      const dx=end[0]-x, dy=end[1]-y;
      const distance=box ? Math.min(hw/Math.abs(dx),hh/Math.abs(dy),1) : 0;
      return {start:[x+dx*distance,y+dy*distance],end};
    }
    const clear = segment => labels.every(label=>!segmentIntersectsRect(segment,label,2));
    const straight = item => leaderTo([
      Math.max(item.x,Math.min(item.x+item.width,x)),Math.max(item.y,Math.min(item.y+item.height,y)),
    ]);
    const candidates = [[x-w/2,y-hh-gap-h],[x-w/2,y+hh+gap],[x+hw+gap,y-h/2],[x-hw-gap-w,y-h/2]];
    let slot, leader = [];
    if (anchor) for (const [x,y] of candidates) {
      const item = {x,y,width:w,height:h};
      if (x<left || y<top || x+w>left+width || y+h>top+height || obstacles.some(other=>overlap(item,other))) continue;
      const segment = straight(item);
      if (!clear(segment)) continue;
      slot = item;
      leader = [segment];
      break;
    }
    if (!slot) {
      const fallbackWidth = anchor ? w : Math.max(w, Math.ceil(8*textUnits(label)+w));
      const preferred = anchor ? Math.max(left,Math.min(x-fallbackWidth/2,left+width-fallbackWidth)) : left;
      slot={x:preferred,y:marginTop,width:fallbackWidth,height:h};
      while (obstacles.some(other=>overlap(slot,other))) slot.y+=h+8;
      if (anchor) {
        const segment = straight(slot);
        if (clear(segment)) leader = [segment];
        else {
          // Go around the labels via a clear vertical corridor, then enter
          // the badge from the side in the reserved margin.
          const corridors = [left+4,left+width-4,...labels.flatMap(label=>[label.x-4,label.x+label.width+4])]
            .filter(column=>column>=left && column<=left+width)
            .sort((a,b)=>Math.abs(a-x)-Math.abs(b-x));
          const dockY = slot.y+h/2;
          for (const column of corridors) {
            const first = leaderTo([column,y]);
            const entryX = Math.max(slot.x,Math.min(slot.x+w,column));
            const segments = [first,{start:first.end,end:[column,entryX===column ? slot.y : dockY]}];
            if (entryX!==column) segments.push({start:segments[1].end,end:[entryX,dockY]});
            if (!segments.every(clear)) continue;
            leader = segments;
            break;
          }
        }
      }
      if (!leader.length) {
        slot.width = Math.max(slot.width,Math.ceil(8*textUnits(label)+w));
        while (obstacles.some(other=>overlap(slot,other))) slot.y+=h+8;
      }
      right=Math.max(right,slot.x+slot.width+4);
      bottom=Math.max(bottom,slot.y+h+8);
    }
    obstacles.push(slot);
    return {...slot, leader, label, metric:badge.metric};
  });
  return { slots, view:[left,top,right-left,bottom-top] };
}

export function scenarioDiagramSvg(svg, diagramType, targets, model, state) {
  // Target marks use the same semantic precedence as the frozen native graph.
  const byNode = new Map(), byEdge = new Map();
  for (const row of targets.active) {
    for (const [ids, table] of [[row.nodes,byNode],[row.edges,byEdge]]) for (const id of ids) {
      if (!table.has(id)) table.set(id,[]);
      table.get(id).push(row.key);
    }
  }
  const marked = svg.replace(/<[a-zA-Z][^>]*>/gu,tag=>{
    const a=attrs(tag);
    const node=a['data-node-id'], from=a['data-edge-from'], to=a['data-edge-to'];
    if (!node && !(from && to)) return tag;
    const cases = (node ? byNode.get(node) : byEdge.get(a['data-edge-id'] || a['data-edge-key'] || `${from}~${to}`)) || [];
    return tag.replace(/(\/?>)$/u,` data-whatif-cases="${cases.join(' ')}" data-whatif-active="${cases.includes(state.key)}"$1`);
  });
  if (!targets.badges.length) return marked;
  const {slots,view} = badgeSlots(svg,targets.badges,model.metrics,diagramType);
  const annotations = slots.map(slot=>{
    const {x,y,width,height,leader,label,metric} = slot;
    const cx=x+width/2, cy=y+height/2;
    const lines = leader.filter(({start,end})=>start[0]!==end[0] || start[1]!==end[1]).map(({start,end})=>
      `<line x1="${start[0]}" y1="${start[1]}" x2="${end[0]}" y2="${end[1]}"/>`).join('');
    const prefix = leader.length ? '' : label+' · ';
    return `<g class="whatif-badge"><title>${escapeHtml(label)}</title>${lines}<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="5"/><text x="${cx}" y="${cy+4}" text-anchor="middle" data-whatif-badge="${escapeHtml(metric)}" data-whatif-prefix="${escapeHtml(prefix)}">${escapeHtml(prefix+state.metrics.get(metric).text)}</text></g>`;
  }).join('');
  return marked.replace(/(<svg\b[^>]*\bviewBox=")[^"]+/u,(_,start)=>start+view.join(' '))
    .replace(/<\/svg>$/u,`<g data-whatif-annotations="">${annotations}</g></svg>`);
}
