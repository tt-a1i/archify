import {mkdir, writeFile} from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'pRetry: caller operation, retry controller, and stopping paths',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/p-retry.git',
      revision: '1472907affe8d6107aba5884abc36d6361b3042e'
    },
    views: [
      {id: 'happy-path', label: 'Successful attempt', focus: ['caller', 'controller', 'operation'], note: 'The controller numbers each invocation; a fulfilled operation value returns to the caller.'},
      {id: 'failure-order', label: 'Failure decisions', focus: ['failure', 'consume', 'failed-hook', 'eligibility', 'retry-hook'], note: 'Follow the source order: consume decision, failure hook, remaining-budget checks, then retry decision.'},
      {id: 'delay-abort', label: 'Delay and cancellation', focus: ['signal', 'timer', 'controller', 'terminal'], note: 'AbortSignal is checked around attempts and interrupts a pending retry timer; it does not cancel input itself.'}
    ]
  },
  components: [
    {
      id: 'caller', type: 'external', label: 'Caller', sublabel: 'supplies input/options; receives result', pos: [35, 230], size: [180, 76],
      sources: [{path: 'index.js', line: 200, end_line: 201, label: 'pRetry API accepts input and options'}]
    },
    {
      id: 'controller', type: 'backend', label: 'pRetry controller', sublabel: 'owns attemptNumber, retriesConsumed, startTime and loop', pos: [275, 220], size: [220, 94],
      sources: [{path: 'index.js', line: 233, end_line: 259, label: 'counters, loop and input invocation'}]
    },
    {
      id: 'operation', type: 'external', label: 'Caller-provided operation', sublabel: 'input(attemptNumber); its running work is caller-owned', pos: [565, 220], size: [230, 76],
      sources: [{path: 'index.js', line: 239, end_line: 249, label: 'input invocation and fulfilled result'}]
    },
    {
      id: 'signal', type: 'external', label: 'AbortSignal', sublabel: 'cancels controller checks and pending delay', pos: [280, 65], size: [210, 68],
      sources: [{path: 'index.js', line: 89, end_line: 105, label: 'delay abort clears timer and rejects'}, {path: 'index.js', line: 233, end_line: 247, label: 'signal checked around input'}]
    },
    {
      id: 'failure', type: 'backend', label: 'Failure normalizer', sublabel: 'unwrap AbortError; turn non-Error throw into TypeError', pos: [565, 410], size: [230, 76],
      sources: [{path: 'index.js', line: 109, end_line: 116, label: 'normalizes thrown values and unwraps AbortError'}]
    },
    {
      id: 'consume', type: 'backend', label: 'shouldConsumeRetry', sublabel: 'decides whether this retry consumes count and gets delay', pos: [855, 400], size: [230, 92],
      sources: [{path: 'index.js', line: 140, end_line: 155, label: 'builds context; false yields effective delay 0'}]
    },
    {
      id: 'failed-hook', type: 'backend', label: 'onFailedAttempt', sublabel: 'runs after consume decision on every failed attempt', pos: [1145, 400], size: [230, 92],
      sources: [{path: 'index.js', line: 148, end_line: 158, label: 'consume hook precedes onFailedAttempt'}, {path: 'index.js', line: 126, end_line: 137, label: 'hook runs when retry time is exhausted'}]
    },
    {
      id: 'eligibility', type: 'backend', label: 'Eligibility gates', sublabel: 'remaining time + retries left; non-network TypeError', pos: [1145, 590], size: [230, 92],
      sources: [{path: 'index.js', line: 160, end_line: 171, label: 'time, retries left and TypeError gates'}]
    },
    {
      id: 'retry-hook', type: 'backend', label: 'shouldRetry', sublabel: 'final caller hook: decline means final rejection', pos: [855, 590], size: [230, 76],
      sources: [{path: 'index.js', line: 174, end_line: 186, label: 'decline rejects; no-consume returns false'}]
    },
    {
      id: 'timer', type: 'backend', label: 'Backoff timer', sublabel: 'wait = min(effective delay, remaining maxRetryTime)', pos: [565, 590], size: [230, 76],
      sources: [{path: 'index.js', line: 66, end_line: 82, label: 'maxTimeout cap; remaining time can be infinite'}, {path: 'index.js', line: 178, end_line: 197, label: 'cap to remaining time; wait then retry'}]
    },
    {
      id: 'terminal', type: 'external', label: 'Final rejection', sublabel: 'normalized error, originalError, or signal reason', pos: [1435, 590], size: [220, 92],
      sources: [{path: 'index.js', line: 114, end_line: 116, label: 'AbortError throws originalError'}, {path: 'index.js', line: 160, end_line: 181, label: 'failure stopping branches throw normalized error'}, {path: 'index.js', line: 89, end_line: 105, label: 'abort during delay rejects with signal reason'}]
    }
  ],
  boundaries: [
    {kind: 'region', label: 'pRetry-controlled retry lifecycle', wraps: ['controller', 'failure', 'consume', 'failed-hook', 'eligibility', 'retry-hook', 'timer']}
  ],
  connections: [
    {id: 'call', from: 'caller', to: 'controller', label: 'pRetry(input, options)'},
    {id: 'invoke', from: 'controller', to: 'operation', label: 'invoke input(attemptNumber)'},
    {id: 'return-value', from: 'operation', to: 'controller', label: 'fulfilled value'},
    {id: 'resolve', from: 'controller', to: 'caller', label: 'return result'},
    {id: 'operation-fails', from: 'operation', to: 'failure', label: 'throw / reject'},
    {id: 'normalize', from: 'failure', to: 'consume', label: 'normalized failure context'},
    {id: 'consume-order', from: 'consume', to: 'failed-hook', label: 'then call onFailedAttempt'},
    {id: 'after-hook', from: 'failed-hook', to: 'eligibility', label: 'then check time, retries, TypeError'},
    {id: 'eligible', from: 'eligibility', to: 'retry-hook', label: 'eligible failure context'},
    {id: 'counted-delay', from: 'retry-hook', to: 'timer', label: 'yes + consume: delay'},
    {id: 'retry-after-delay', from: 'timer', to: 'controller', label: 'count retry; next attempt'},
    {id: 'uncounted-retry', from: 'retry-hook', to: 'controller', label: 'yes + no consume: immediate next attempt'},
    {id: 'signal-controller', from: 'signal', to: 'controller', label: 'throwIfAborted around attempts'},
    {id: 'signal-delay', from: 'signal', to: 'timer', label: 'abort clears pending timeout'},
    {id: 'stop-gates', from: 'eligibility', to: 'terminal', fromSide: 'right', toSide: 'left', label: 'time / retries exhausted; non-network TypeError'},
    {id: 'stop-declined', from: 'retry-hook', to: 'terminal', label: 'shouldRetry false'},
    {id: 'stop-aborted', from: 'signal', to: 'terminal', label: 'signal reason'},
    {id: 'stop-abort-error', from: 'failure', to: 'terminal', label: 'AbortError → originalError'}
  ],
  cards: [
    {dot: 'cyan', title: 'Ownership boundary', items: ['pRetry owns attempt numbering, consumed retries and maxRetryTime accounting.', 'The supplied input is invoked by pRetry, but its already-running work has no cancellation call in pRetry.']},
    {dot: 'amber', title: 'Failure ordering', items: ['After a failure: normalize / unwrap AbortError → shouldConsumeRetry → onFailedAttempt → time, retry-count and TypeError gates → shouldRetry.', 'A false consume decision keeps retriesConsumed unchanged and sets retryDelay to 0; a successful shouldRetry then loops immediately.']},
    {dot: 'violet', title: 'Time and cancellation limits', items: ['maxRetryTime bounds the controller’s retry lifecycle and caps a scheduled wait; it is not a deadline imposed on a running input.', 'AbortSignal can reject before or after an attempt and interrupt delayForRetry; during its timer, the listener clears the timeout.']}
  ]
};

await mkdir('output', {recursive: true});
await writeFile('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
