import {mkdir, writeFile} from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'pRetry: retry controller, caller operation, and stop paths',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/p-retry.git',
      provider: 'github',
      revision: '1472907affe8d6107aba5884abc36d6361b3042e'
    },
    views: [
      {
        id: 'successful-loop',
        label: 'Successful retry loop',
        focus: ['caller', 'controller', 'operation', 'retry-delay'],
        note: 'The controller increments attempts, invokes the caller operation, and returns its fulfilled value.'
      },
      {
        id: 'failure-decisions',
        label: 'Failure decisions',
        focus: ['controller', 'failure-hooks', 'retry-delay', 'final-rejection'],
        note: 'A failed attempt passes through consume → observe → retry decisions before a delayed or immediate next attempt.'
      },
      {
        id: 'abort-boundaries',
        label: 'Abort boundaries',
        focus: ['operation', 'abort-signal', 'retry-delay', 'final-rejection'],
        note: 'Signal checks stop retries and cancel a pending delay; they do not interrupt an already-running input function.'
      }
    ]
  },
  components: [
    {
      id: 'caller', type: 'external', label: 'Caller', sublabel: 'supplies input + options; receives Promise result', pos: [50, 330], size: [210, 74],
      sources: [{path: 'index.js', line: 200, end_line: 201, label: 'pRetry API inputs'}]
    },
    {
      id: 'controller', type: 'backend', label: 'pRetry controller', sublabel: 'owns attemptNumber, retriesConsumed, startTime', pos: [355, 330], size: [245, 80],
      sources: [{path: 'index.js', line: 233, end_line: 260, label: 'retry loop ownership'}, {path: 'index.js', line: 209, end_line: 217, label: 'option defaults'}]
    },
    {
      id: 'operation', type: 'external', label: 'Caller-provided operation', sublabel: 'input(attemptNumber); may fulfill or reject', pos: [715, 170], size: [240, 74],
      sources: [{path: 'index.js', line: 239, end_line: 250, label: 'operation invocation'}, {path: 'index.d.ts', line: 247, end_line: 250, label: 'input contract'}]
    },
    {
      id: 'failure-hooks', type: 'external', label: 'Caller failure hooks', sublabel: 'shouldConsumeRetry → onFailedAttempt → shouldRetry', pos: [720, 360], size: [280, 82],
      sources: [{path: 'index.js', line: 140, end_line: 175, label: 'hook order and gates'}, {path: 'index.d.ts', line: 110, end_line: 138, label: 'hook semantics'}]
    },
    {
      id: 'retry-delay', type: 'backend', label: 'Backoff timer', sublabel: 'wait ≤ min(maxTimeout backoff, remaining maxRetryTime)', pos: [1045, 360], size: [275, 82],
      sources: [{path: 'index.js', line: 66, end_line: 82, label: 'backoff cap and remaining time'}, {path: 'index.js', line: 178, end_line: 197, label: 'bounded retry delay'}]
    },
    {
      id: 'abort-signal', type: 'security', label: 'AbortSignal', sublabel: 'checked before/after input and around retry delay', pos: [1030, 600], size: [290, 74],
      sources: [{path: 'index.js', line: 84, end_line: 107, label: 'delay abort listener'}, {path: 'index.js', line: 233, end_line: 249, label: 'loop signal checks'}]
    },
    {
      id: 'abort-error', type: 'external', label: 'AbortError from operation', sublabel: 'unwrap originalError; skip failure callbacks', pos: [690, 590], size: [275, 74],
      sources: [{path: 'index.js', line: 49, end_line: 64, label: 'AbortError wrapper'}, {path: 'index.js', line: 109, end_line: 116, label: 'AbortError unwrapping'}]
    },
    {
      id: 'final-rejection', type: 'external', label: 'Final rejection', sublabel: 'last error or abort reason returned to caller', pos: [1050, 170], size: [270, 74],
      sources: [{path: 'index.js', line: 126, end_line: 137, label: 'time-exhausted rejection'}, {path: 'index.js', line: 160, end_line: 195, label: 'failure stop gates'}]
    }
  ],
  boundaries: [
    {kind: 'region', label: 'p-retry library runtime', wraps: ['controller', 'retry-delay'], pad: 28}
  ],
  connections: [
    {id: 'start', from: 'caller', to: 'controller', label: 'pRetry(input, options)'},
    {id: 'invoke', from: 'controller', to: 'operation', label: 'increment attempt; invoke input(attemptNumber)', variant: 'emphasis'},
    {id: 'success', from: 'operation', to: 'caller', label: 'fulfilled value → return', variant: 'emphasis'},
    {id: 'failure', from: 'operation', to: 'controller', label: 'rejected error → failure controller'},
    {id: 'hooks', from: 'controller', to: 'failure-hooks', label: 'context: consume → onFailed → shouldRetry'},
    {id: 'decision', from: 'failure-hooks', to: 'controller', label: 'retry decision + consumption'},
    {id: 'wait', from: 'controller', to: 'retry-delay', label: 'only if consumes retry; cap delay by time left'},
    {id: 'loop', from: 'retry-delay', to: 'controller', label: 'delay completes → next attempt'},
    {id: 'signal-loop', from: 'abort-signal', to: 'controller', label: 'throwIfAborted at loop boundaries', variant: 'security'},
    {id: 'signal-delay', from: 'abort-signal', to: 'retry-delay', label: 'abort clears timeout and rejects delay', variant: 'security'},
    {id: 'abort-error-path', from: 'operation', to: 'abort-error', label: 'throws AbortError'},
    {id: 'unwrap', from: 'abort-error', to: 'final-rejection', label: 'throw originalError; no callbacks', variant: 'dashed'},
    {id: 'stops', from: 'controller', to: 'final-rejection', label: 'budget exhausted, TypeError, or shouldRetry false'},
    {id: 'reject-to-caller', from: 'final-rejection', to: 'caller', label: 'rejected Promise / abort reason'}
  ],
  cards: [
    {
      dot: 'cyan', title: 'Controller ownership',
      items: [
        'pRetry, not input, owns attemptNumber, retriesConsumed, and the maxRetryTime clock.',
        'maxRetryTime can be Infinity and gates retry decisions and waiting; it does not impose a deadline that interrupts a running input call.'
      ]
    },
    {
      dot: 'amber', title: 'Failure decision order',
      items: [
        'After a normal failure: shouldConsumeRetry runs first, then onFailedAttempt, then shouldRetry if time and retries remain.',
        'A false consume decision can retry immediately without incrementing retriesConsumed or waiting, but it remains subject to time and remaining-retry gates.'
      ]
    },
    {
      dot: 'rose', title: 'Stopping and cancellation',
      items: [
        'The original error is rejected when retry time or retries are exhausted, shouldRetry declines, or a non-network TypeError occurs.',
        'AbortError is an operation-level stop marker that unwraps originalError. AbortSignal cancels a pending delay and is checked around input; input itself must cooperate to stop while running.'
      ]
    }
  ]
};

await mkdir('output', {recursive: true});
await writeFile('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
