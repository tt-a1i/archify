import {writeFile} from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'QuickLRU: Two-Generation Cache Lifecycle',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/quick-lru.git',
      revision: 'a2190ebdf8e455b95a7138803d274ff5ed57ebcd',
      link_mode: 'local-only'
    },
    views: [
      {
        id: 'write-rotation',
        label: 'Write and rotate',
        focus: ['caller', 'quicklru', 'current', 'old', 'eviction'],
        note: 'A new current-generation key increments the counter; reaching maxSize rotates whole generations.'
      },
      {
        id: 'read-promotion',
        label: 'Read and promote',
        focus: ['caller', 'quicklru', 'current', 'old', 'expiry'],
        note: 'get returns current values, promotes live old values, and removes expired values before returning.'
      },
      {
        id: 'inspect-manual',
        label: 'Inspect and remove',
        focus: ['caller', 'quicklru', 'current', 'old', 'expiry'],
        note: 'has and peek apply expiry checks without promotion; delete and clear do not invoke onEviction.'
      }
    ]
  },
  components: [
    {
      id: 'caller',
      type: 'external',
      label: 'Cache caller',
      sublabel: 'calls set, get, has, peek, delete, clear',
      pos: [40, 350],
      size: [215, 76],
      sources: [{path: 'index.js', line: 105, end_line: 178, label: 'public cache methods'}]
    },
    {
      id: 'quicklru',
      type: 'backend',
      label: 'QuickLRU controller',
      sublabel: 'in-memory Map subclass; owns lifecycle decisions',
      pos: [340, 350],
      size: [240, 84],
      sources: [{path: 'index.js', line: 1, end_line: 23, label: 'class and options'}, {path: 'index.js', line: 68, end_line: 83, label: 'rotation and promotion'}]
    },
    {
      id: 'current',
      type: 'database',
      label: 'Current Map',
      sublabel: 'recent { value, expiry }; #size counts new keys',
      pos: [690, 210],
      size: [255, 78],
      sources: [{path: 'index.js', line: 2, end_line: 7, label: 'in-memory state'}, {path: 'index.js', line: 68, end_line: 77, label: 'current generation'}]
    },
    {
      id: 'old',
      type: 'database',
      label: 'Old Map',
      sublabel: 'previous generation; live gets move entries out',
      pos: [690, 490],
      size: [255, 78],
      sources: [{path: 'index.js', line: 3, end_line: 4, label: 'old generation state'}, {path: 'index.js', line: 80, end_line: 83, label: 'move to recent'}]
    },
    {
      id: 'expiry',
      type: 'backend',
      label: 'Expiry check',
      sublabel: 'expired item: onEviction, delete both maps, return absent',
      pos: [1015, 350],
      size: [270, 84],
      sources: [{path: 'index.js', line: 40, end_line: 65, label: 'lazy expiry'}, {path: 'index.js', line: 137, end_line: 157, label: 'has and peek'}]
    },
    {
      id: 'eviction',
      type: 'external',
      label: 'Optional onEviction callback',
      sublabel: 'receives key and value for expiry or rotated-out old entries',
      pos: [1015, 630],
      size: [290, 76],
      sources: [{path: 'index.js', line: 30, end_line: 38, label: 'rotation callback'}, {path: 'index.js', line: 40, end_line: 47, label: 'expiry callback'}]
    }
  ],
  boundaries: [
    {
      kind: 'region',
      label: 'One QuickLRU instance: process-memory ownership',
      wraps: ['quicklru', 'current', 'old', 'expiry'],
      pad: 34
    }
  ],
  connections: [
    {id: 'write', from: 'caller', to: 'quicklru', label: 'set(key, value, { maxAge })'},
    {id: 'write-current', from: 'quicklru', to: 'current', label: 'current key: replace { value, expiry }; no #size increment'},
    {id: 'write-new', from: 'quicklru', to: 'current', label: 'not current (including old): store and increment #size', variant: 'emphasis'},
    {id: 'rotate', from: 'current', to: 'old', label: '#size >= maxSize: reset count; current becomes old; create new current', variant: 'emphasis'},
    {id: 'rotate-evict', from: 'old', to: 'eviction', label: 'before rotation, emit callbacks for prior old generation', variant: 'dashed'},
    {id: 'get-current', from: 'caller', to: 'current', label: 'get: current hit → expiry check → value or undefined'},
    {id: 'get-old', from: 'caller', to: 'old', label: 'get: old hit → expiry check'},
    {id: 'promote', from: 'old', to: 'current', label: 'live old hit: delete old, #set into current, return value', variant: 'emphasis'},
    {id: 'get-miss', from: 'quicklru', to: 'caller', label: 'missing key (or expired): undefined', variant: 'dashed'},
    {id: 'expiry-current', from: 'current', to: 'expiry', label: 'get, has, or peek checks expiry'},
    {id: 'expiry-old', from: 'old', to: 'expiry', label: 'get, has, or peek checks expiry'},
    {id: 'expired-delete', from: 'expiry', to: 'quicklru', label: 'expired: delete(key) removes current and old; decrements if current'},
    {id: 'expiry-callback', from: 'expiry', to: 'eviction', label: 'expired item invokes callback first', variant: 'dashed'},
    {id: 'inspect', from: 'caller', to: 'quicklru', label: 'has / peek: inspect either map; no get-style promotion'},
    {id: 'manual-remove', from: 'caller', to: 'quicklru', label: 'delete: remove both maps; clear: clear both and set #size = 0'},
    {id: 'manual-no-callback', from: 'quicklru', to: 'eviction', label: 'delete / clear do not call onEviction', variant: 'dashed'}
  ],
  cards: [
    {
      dot: 'cyan',
      title: 'Why two generations?',
      items: [
        'New writes collect in Current Map until its counter reaches maxSize.',
        'Rotation swaps whole Maps and starts a fresh Current Map; it is not a one-item least-recent eviction.',
        'A live old-generation get moves that entry into Current Map, marking it recent.'
      ]
    },
    {
      dot: 'amber',
      title: 'Expiry and callback boundary',
      items: [
        'get, has, and peek lazily remove an expired entry from both maps; get and peek then return undefined, has returns false.',
        'onEviction is called for expired items and for the old generation rotated out on a later threshold.',
        'Explicit delete and clear change maps and the current counter without calling onEviction.'
      ]
    },
    {
      dot: 'violet',
      title: 'Storage scope',
      items: [
        'The only stores shown are the instance private JavaScript Maps.',
        'No persistent or remote storage is involved in this lifecycle.'
      ]
    }
  ]
};

await writeFile(new URL('./output/diagram.architecture.json', import.meta.url), `${JSON.stringify(diagram, null, 2)}\n`);
