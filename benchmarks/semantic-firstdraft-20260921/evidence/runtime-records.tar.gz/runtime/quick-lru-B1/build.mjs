import {writeFile} from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'QuickLRU: Two-Generation Cache Lifecycle',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/quick-lru.git',
      revision: 'a2190ebdf8e455b95a7138803d274ff5ed57ebcd',
      link_mode: 'web'
    },
    views: [
      {
        id: 'write-and-rotation',
        label: 'Write and rotate',
        focus: ['caller', 'quicklru', 'policy', 'current', 'old', 'eviction'],
        note: 'A new current-generation key advances the count; reaching maxSize rotates a whole generation.'
      },
      {
        id: 'read-and-promotion',
        label: 'Read and promote',
        focus: ['caller', 'quicklru', 'current', 'old', 'expiry'],
        note: 'get promotes a live old entry, while has and peek inspect without that promotion.'
      },
      {
        id: 'expiry-and-cleanup',
        label: 'Expiry and cleanup',
        focus: ['quicklru', 'current', 'old', 'expiry', 'eviction'],
        note: 'Expiry goes through delete and may notify; explicit delete and clear do not invoke onEviction.'
      }
    ]
  },
  components: [
    {
      id: 'caller', type: 'external', label: 'Cache caller', sublabel: 'calls public map-like API', pos: [45, 385], size: [165, 72],
      sources: [{path: 'index.js', line: 105, end_line: 179, label: 'public methods'}]
    },
    {
      id: 'quicklru', type: 'backend', label: 'QuickLRU controller', sublabel: 'owns state and lifecycle decisions', pos: [300, 360], size: [205, 88],
      sources: [{path: 'index.js', line: 1, end_line: 7, label: 'class and private state'}, {path: 'index.js', line: 105, end_line: 179, label: 'public lifecycle'}]
    },
    {
      id: 'policy', type: 'backend', label: 'Capacity and expiry policy', sublabel: 'maxSize; optional maxAge → expiry', pos: [300, 150], size: [220, 76],
      sources: [{path: 'index.js', line: 9, end_line: 23, label: 'constructor policy'}, {path: 'index.js', line: 120, end_line: 123, label: 'per-item expiry'}]
    },
    {
      id: 'current', type: 'database', label: 'Current Map', sublabel: 'in-memory #cache; #size tracks new keys', pos: [625, 245], size: [230, 82],
      sources: [{path: 'index.js', line: 2, end_line: 4, label: 'in-memory maps'}, {path: 'index.js', line: 68, end_line: 77, label: 'write and rotate'}]
    },
    {
      id: 'old', type: 'database', label: 'Old Map', sublabel: 'in-memory #oldCache; prior generation', pos: [625, 500], size: [230, 82],
      sources: [{path: 'index.js', line: 3, end_line: 4, label: 'old map state'}, {path: 'index.js', line: 72, end_line: 77, label: 'generation handoff'}]
    },
    {
      id: 'expiry', type: 'backend', label: 'Expiry guard', sublabel: 'expired item: onEviction then delete()', pos: [940, 270], size: [230, 80],
      sources: [{path: 'index.js', line: 40, end_line: 60, label: 'expiry removal and return'}]
    },
    {
      id: 'eviction', type: 'external', label: 'onEviction callback', sublabel: 'optional caller-provided function', pos: [955, 520], size: [210, 76],
      sources: [{path: 'index.js', line: 30, end_line: 38, label: 'generation callback'}, {path: 'index.js', line: 40, end_line: 46, label: 'expired callback'}]
    }
  ],
  boundaries: [
    {kind: 'region', label: 'QuickLRU instance: process memory only', wraps: ['quicklru', 'policy', 'current', 'old', 'expiry'], pad: 34}
  ],
  connections: [
    {id: 'api', from: 'caller', to: 'quicklru', label: 'set, get, has, peek, delete, clear', variant: 'emphasis'},
    {id: 'options', from: 'caller', to: 'policy', label: 'construct with maxSize, maxAge, onEviction'},
    {id: 'set-current', from: 'quicklru', to: 'current', label: 'set: existing current key replaces item; no #size increment'},
    {id: 'set-absent', from: 'quicklru', to: 'current', label: 'set: absent from current (even if old) → #set and #size++', variant: 'emphasis'},
    {id: 'threshold', from: 'current', to: 'old', label: 'threshold: rotate whole current Map to old; new Map; #size = 0', variant: 'emphasis', labelAt: [760, 440]},
    {id: 'rotated-callback', from: 'old', to: 'eviction', label: 'before rotation: emit prior old entries', variant: 'dashed'},
    {id: 'current-get', from: 'current', to: 'expiry', label: 'get current item: return value unless expired'},
    {id: 'old-get', from: 'old', to: 'quicklru', label: 'get live old item: delete old then #set → promote current', variant: 'emphasis'},
    {id: 'miss', from: 'quicklru', to: 'caller', label: 'missing or expired get → undefined', variant: 'dashed'},
    {id: 'inspect-current', from: 'quicklru', to: 'current', label: 'has / peek inspect current; no get-style promotion'},
    {id: 'inspect-old', from: 'quicklru', to: 'old', label: 'has / peek inspect old; no get-style promotion'},
    {id: 'inspect-expiry', from: 'current', to: 'expiry', label: 'has / peek expired: delete; false / undefined', labelAt: [1030, 700]},
    {id: 'expiry-delete', from: 'expiry', to: 'quicklru', label: 'delete(key): remove both maps; decrement #size only if current', labelAt: [880, 665]},
    {id: 'expired-callback', from: 'expiry', to: 'eviction', label: 'expired item invokes onEviction before delete', variant: 'dashed'},
    {id: 'manual-current', from: 'quicklru', to: 'current', label: 'explicit delete / clear removes current; clear sets #size = 0'},
    {id: 'manual-old', from: 'quicklru', to: 'old', label: 'explicit delete / clear removes old; no onEviction'}
  ],
  cards: [
    {
      dot: 'cyan', title: 'Why two generations',
      items: ['QuickLRU keeps a current Map and a prior old Map entirely in memory.', 'At #size ≥ maxSize, it rotates the whole current generation; it does not evict one least-recent item on that set.']
    },
    {
      dot: 'emerald', title: 'Read semantics',
      items: ['get checks current first; a live old hit moves into current through #moveToRecent.', 'has and peek check either Map without the get-style old-to-current promotion; expired entries are deleted.']
    },
    {
      dot: 'amber', title: 'Callback boundary',
      items: ['Expired items invoke onEviction before delete; rotation emits entries from the prior old Map.', 'Explicit delete and clear only mutate the maps and current count; these methods do not call onEviction.']
    }
  ]
};

await writeFile('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
