import {node, edge, architecture, writeArchitecture} from './tools/author-kit.mjs';

const spec = architecture(
	{
		title: 'QuickLRU: two-generation cache lifecycle',
		locale: 'en',
		repository: {
			url: 'https://github.com/sindresorhus/quick-lru.git',
			revision: 'a2190ebdf8e455b95a7138803d274ff5ed57ebcd',
		},
		views: [
			{
				id: 'ownership',
				label: 'What the instance owns',
				focus: ['caller', 'quick-lru', 'current-map', 'old-map'],
				note: 'One QuickLRU object owns both in-memory generations and the current-generation counter.',
			},
			{
				id: 'set-rotation',
				label: 'Set and rotation',
				focus: ['caller', 'quick-lru', 'current-map', 'old-map', 'eviction-callback'],
				note: 'Updating a current key does not increment the counter; an absent-current key does, then may rotate generations.',
			},
			{
				id: 'read-expiry',
				label: 'Read, promotion and expiry',
				focus: ['quick-lru', 'current-map', 'old-map', 'eviction-callback'],
				note: 'get promotes a live old-generation entry; get, has and peek remove expired entries through delete().',
			},
			{
				id: 'manual-removal',
				label: 'Manual removal boundary',
				focus: ['caller', 'quick-lru', 'current-map', 'old-map', 'eviction-callback'],
				note: 'delete and clear mutate the maps directly; their source paths do not invoke onEviction.',
			},
		],
	},
	[
		node('caller', 'external', 'Library caller', 'Calls the public Map-like API',
			[40, 340, 240, 76], ['index.js:120-179']),
		node('quick-lru', 'backend', 'QuickLRU controller', 'Owns maxSize, expiry policy, current count and eviction callback',
			[560, 330, 310, 108], [
				'index.js:1-23',
				'index.js:68-83',
				'index.js:105-179',
			]),
		node('current-map', 'database', 'Current in-memory Map', 'Recent entries; #size counts inserts into this generation',
			[1050, 150, 300, 88], ['index.js:2-4', 'index.js:68-77', 'index.js:120-132']),
		node('old-map', 'database', 'Old in-memory Map', 'Prior generation; live get may remove and promote its entry',
			[1050, 560, 300, 88], ['index.js:3-4', 'index.js:80-83', 'index.js:105-117']),
		node('eviction-callback', 'external', 'Optional onEviction callback', 'Receives key and value for expiry or rotated-out entries',
			[1400, 560, 270, 88], ['index.js:30-49', 'index.js:72-76']),
	],
	[
		edge('public-api', 'caller', 'quick-lru', 'set / get / has / peek / delete / clear'),
		edge('set-current', 'quick-lru', 'current-map', 'set current key: replace value + expiry'),
		edge('set-absent', 'quick-lru', 'current-map', 'set absent-current key: insert + increment #size'),
		edge('rotate-old', 'quick-lru', 'old-map', 'at #size ≥ maxSize: current becomes old generation'),
		edge('fresh-current', 'quick-lru', 'current-map', 'rotation: fresh Map and #size = 0'),
		edge('get-current', 'current-map', 'quick-lru', 'get current hit: return value; expiry deletes'),
		edge('get-old', 'old-map', 'quick-lru', 'get old hit: delete if expired, else promote + return'),
		edge('peek-has', 'quick-lru', 'old-map', 'has / peek inspect without promotion; expiry deletes'),
		edge('manual-remove', 'quick-lru', 'current-map', 'delete removes current and decrements #size; clear clears'),
		edge('manual-old', 'quick-lru', 'old-map', 'delete removes old; clear clears old too'),
		edge('evict', 'quick-lru', 'eviction-callback', 'onEviction for expired or rotated-out entries'),
	],
	{
		boundaries: [{
			kind: 'region',
			label: 'One in-memory QuickLRU instance',
			wraps: ['quick-lru', 'current-map', 'old-map'],
			pad: 34,
		}],
		cards: [
			{
				dot: 'cyan',
				title: 'Two generations, not per-item rotation',
				items: [
					'An absent-current set inserts into #cache and increments #size.',
					'When #size reaches maxSize, #cache becomes #oldCache and a fresh #cache starts at count 0.',
					'The rotation emits evictions for the previous old generation; it does not evict one least-recent item.',
				],
			},
			{
				dot: 'amber',
				title: 'Read and inspection behavior',
				items: [
					'get returns a current value after its expiry check; a live old value is moved to current before return.',
					'Missing get returns undefined. has and peek inspect either map without get-style promotion.',
					'Expired entries invoke onEviction when configured, then delete() removes the key from both maps.',
				],
			},
			{
				dot: 'violet',
				title: 'Callback boundary',
				items: [
					'onEviction receives (key, value) for expired entries and for entries in the displaced old generation.',
					'Explicit delete removes from current and old (and adjusts current count only when needed); clear empties both and resets it.',
					'Neither delete nor clear calls onEviction in their implementation.',
				],
			},
		],
	},
);

await writeArchitecture('output/diagram.architecture.json', spec);
