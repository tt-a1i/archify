import { mkdir, writeFile } from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'Async lilconfig Explorer',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/antonk52/lilconfig.git',
      revision: '6ae4bcdd4594b3909626dcd95b841a60ca165fd3',
      link_mode: 'local-only'
    },
    views: [
      {
        id: 'search-walk',
        label: 'Search walk',
        focus: ['caller', 'explorer', 'options', 'search', 'filesystem', 'search-cache', 'transform', 'result'],
        note: 'Follow search(searchFrom) through cached directories, candidate decisions, upward termination, and the transformed answer.'
      },
      {
        id: 'explicit-load',
        label: 'Explicit load',
        focus: ['caller', 'explorer', 'load', 'filesystem', 'loader', 'load-cache', 'transform', 'result'],
        note: 'load(filepath) resolves one explicit path; it does not perform the search walk.'
      },
      {
        id: 'outcomes',
        label: 'Outcomes and errors',
        focus: ['search', 'load', 'transform', 'search-cache', 'load-cache', 'result', 'error'],
        note: 'Compare normal transformed values and cache hits with failures that propagate as rejected async calls.'
      }
    ]
  },
  components: [
    {
      id: 'caller', type: 'external', label: 'Caller', sublabel: 'awaits search() or load()', pos: [40, 420], size: [180, 72],
      sources: [{ path: 'src/index.d.ts', line: 39, end_line: 46, label: 'async explorer API' }]
    },
    {
      id: 'explorer', type: 'backend', label: 'Explorer controller', sublabel: 'lilconfig(name, options)', pos: [290, 420], size: [190, 76],
      sources: [{ path: 'src/index.js', line: 156, end_line: 171, label: 'async explorer creation' }]
    },
    {
      id: 'options', type: 'backend', label: 'Merged options', sublabel: 'defaults + caller loaders', pos: [285, 145], size: [200, 72],
      sources: [{ path: 'src/index.js', line: 96, end_line: 125, label: 'defaults and loader checks' }]
    },
    {
      id: 'search', type: 'backend', label: 'Search execution', sublabel: 'walk searchPlaces upward', pos: [565, 205], size: [205, 78],
      sources: [{ path: 'src/index.js', line: 172, end_line: 245, label: 'async search path' }]
    },
    {
      id: 'load', type: 'backend', label: 'Explicit load execution', sublabel: 'resolve one filepath', pos: [565, 555], size: [205, 78],
      sources: [{ path: 'src/index.js', line: 246, end_line: 294, label: 'async load path' }]
    },
    {
      id: 'search-cache', type: 'database', label: 'Search cache', sublabel: 'visited directory → transformed result', pos: [825, 105], size: [225, 68],
      sources: [{ path: 'src/index.js', line: 167, end_line: 169, label: 'separate maps' }, { path: 'src/index.js', line: 183, end_line: 190, label: 'search cache lookup' }, { path: 'src/index.js', line: 240, end_line: 242, label: 'cache visited directories' }]
    },
    {
      id: 'filesystem', type: 'external', label: 'Filesystem', sublabel: 'candidate files and explicit files', pos: [840, 350], size: [200, 76],
      sources: [{ path: 'src/index.js', line: 192, end_line: 200, label: 'candidate access and read' }, { path: 'src/index.js', line: 247, end_line: 256, label: 'explicit path and read' }]
    },
    {
      id: 'load-cache', type: 'database', label: 'Load cache', sublabel: 'absolute path → transformed result', pos: [825, 665], size: [225, 68],
      sources: [{ path: 'src/index.js', line: 167, end_line: 169, label: 'separate maps' }, { path: 'src/index.js', line: 248, end_line: 251, label: 'load cache lookup' }, { path: 'src/index.js', line: 290, end_line: 294, label: 'cache transformed load result' }]
    },
    {
      id: 'loader', type: 'backend', label: 'Configured loader', sublabel: 'extension / package.json parser', pos: [1110, 205], size: [220, 78],
      sources: [{ path: 'src/index.js', line: 80, end_line: 88, label: 'default async loaders' }, { path: 'src/index.js', line: 144, end_line: 148, label: 'loader validation' }, { path: 'src/index.js', line: 200, end_line: 225, label: 'search loader selection' }]
    },
    {
      id: 'transform', type: 'backend', label: 'Configured transform', sublabel: 'normalizes each terminal result', pos: [1450, 455], size: [225, 76],
      sources: [{ path: 'src/index.js', line: 98, end_line: 109, label: 'default identity transform' }, { path: 'src/index.js', line: 234, end_line: 244, label: 'search transform and cache' }, { path: 'src/index.js', line: 258, end_line: 294, label: 'load transform and cache' }]
    },
    {
      id: 'result', type: 'external', label: 'Resolved value', sublabel: 'transformed result or null miss', pos: [1140, 600], size: [200, 76],
      sources: [{ path: 'src/index.d.ts', line: 1, end_line: 5, label: 'result shape' }, { path: 'src/index.js', line: 234, end_line: 245, label: 'search return' }]
    },
    {
      id: 'error', type: 'external', label: 'Rejected async call', sublabel: 'read, loader, parse, or transform error', pos: [1390, 695], size: [250, 76],
      sources: [{ path: 'src/index.js', line: 199, end_line: 225, label: 'search errors propagate after access' }, { path: 'src/index.js', line: 246, end_line: 294, label: 'load errors propagate' }, { path: 'src/spec/index.spec.js', line: 1636, end_line: 1723, label: 'async error expectations' }]
    }
  ],
  boundaries: [
    { kind: 'region', label: 'Async lilconfig explorer instance', wraps: ['explorer', 'options', 'search', 'load', 'search-cache', 'load-cache', 'loader', 'transform'] }
  ],
  connections: [
    { id: 'create', from: 'caller', to: 'explorer', label: 'lilconfig(name, options)' },
    { id: 'merge-options', from: 'explorer', to: 'options', label: 'merge defaults and options' },
    { id: 'configured-options', from: 'options', to: 'explorer', label: 'searchPlaces, stopDir, cache, callbacks' },
    { id: 'search-call', from: 'caller', to: 'explorer', label: 'await search(searchFrom)' },
    { id: 'search-cache-lookup', from: 'explorer', to: 'search-cache', label: 'lookup by current directory' },
    { id: 'search-cache-hit', from: 'search-cache', to: 'explorer', label: 'return cached transformed value' },
    { id: 'begin-search', from: 'explorer', to: 'search', label: 'start at searchFrom or cwd' },
    { id: 'search-access', from: 'search', to: 'filesystem', label: 'access each configured candidate' },
    { id: 'search-access-miss', from: 'filesystem', to: 'search', label: 'access failure: skip candidate' },
    { id: 'search-read', from: 'filesystem', to: 'search', label: 'accessible file bytes' },
    { id: 'search-loader', from: 'search', to: 'loader', label: 'extension loader; package extraction' },
    { id: 'search-loaded', from: 'loader', to: 'search', label: 'parsed config or package object' },
    { id: 'search-transform', from: 'search', to: 'transform', label: 'found, empty, or null miss' },
    { id: 'search-transformed', from: 'transform', to: 'search', label: 'transformed value', fromSide: 'top', toSide: 'top', via: [[1562.5, 40], [667.5, 40]] },
    { id: 'search-cache-store', from: 'search', to: 'search-cache', label: 'store for visited directories' },
    { id: 'load-call', from: 'caller', to: 'explorer', label: 'await load(filepath)' },
    { id: 'load-cache-lookup', from: 'explorer', to: 'load-cache', label: 'lookup resolved absolute path' },
    { id: 'load-cache-hit', from: 'load-cache', to: 'explorer', label: 'return cached transformed value' },
    { id: 'begin-load', from: 'explorer', to: 'load', label: 'validate and resolve filepath' },
    { id: 'load-read', from: 'load', to: 'filesystem', label: 'read explicit file' },
    { id: 'load-bytes', from: 'filesystem', to: 'load', label: 'file bytes or read failure' },
    { id: 'load-loader', from: 'load', to: 'loader', label: 'select extension loader' },
    { id: 'load-loaded', from: 'loader', to: 'load', label: 'parsed config or package property' },
    { id: 'load-transform', from: 'load', to: 'transform', label: 'result; empty file is isEmpty' },
    { id: 'load-transformed', from: 'transform', to: 'load', label: 'transformed value' },
    { id: 'load-cache-store', from: 'load', to: 'load-cache', label: 'store by absolute path' },
    { id: 'resolved-result', from: 'explorer', to: 'result', label: 'fulfill caller promise' },
    { id: 'search-error', from: 'search', to: 'error', label: 'read, loader, parse, transform failure propagates', variant: 'dashed' },
    { id: 'load-error', from: 'load', to: 'error', label: 'read, loader, parse, transform failure propagates', variant: 'dashed' }
  ],
  cards: [
    {
      dot: 'cyan', title: 'Explorer ownership', items: [
        'Creation merges defaults with caller options; caller loaders override default async loaders.',
        'The instance owns separate searchCache and loadCache Maps, plus clearSearchCache(), clearLoadCache(), and clearCaches().'
      ]
    },
    {
      dot: 'amber', title: 'Search decision', items: [
        'For every directory, search checks each configured searchPlace; failed access is a skipped candidate, not an error result.',
        'It moves to parentDir until stopDir or the filesystem root. package.json only matches when packageProp extracts a non-null value.',
        'An empty non-package file is skipped when ignoreEmptySearchPlaces is true; otherwise it is a found isEmpty result.'
      ]
    },
    {
      dot: 'emerald', title: 'Load and return behavior', items: [
        'load(filepath) resolves one absolute path, validates its extension loader, reads it, then transforms the result; empty explicit files return an isEmpty result.',
        'A normal search miss calls transform(null). Found and empty results call transform(result); cache entries retain those transformed values.'
      ]
    },
    {
      dot: 'rose', title: 'Errors are not search misses', items: [
        'Only candidate access failures are caught for search continuation.',
        'File reads, loader or parse work, and transform calls are awaited without recovery in both paths, so their failures reject the async call.'
      ]
    }
  ]
};

await mkdir('output', { recursive: true });
await writeFile('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
