You are an independent timed Archify author. Work only in /private/tmp/archify-semantic-firstdraft-20260921/runs/quick-lru-B1.
You are not alone in the filesystem: do not modify another worker's files. You own only this workspace's build.mjs and output/ artifacts.
Read your local archify/SKILL.md and applicable references. Use only the local repo/ source and the packaged archify/ Skill; do not inspect other trials, research reports, prior diagrams, installed Skills, hidden rubrics or parent context. Do not delegate or use network. Do not modify source, Skill, renderer, validator or tools. Ordinary local shell/text inspection is available.

TASK: Create a source-backed architecture diagram of QuickLRU's core cache lifecycle: set, get, has/peek, expiry, generation rotation, delete and clear. Explain the owning cache object, its in-memory state, and the caller/callback boundaries. A reader should understand why this implementation keeps two generations and which operations promote entries or invoke onEviction.

Required visible acceptance criteria (these exact clauses will be used in independent review):
1. Show QuickLRU as the controller owning the current and old in-memory maps, the current-generation count, maxSize and optional expiry policy; do not imply persistent or remote storage.
2. Show set for a current-generation key versus a key absent from the current generation (possibly still in the old generation), and generation rotation at the configured threshold; distinguish rotation from evicting just the one least-recent item.
3. Show get from the current generation, get/promotion from the old generation and a missing key. Preserve the actual expiry checks and their effect on removal/return.
4. Explain that has and peek inspect without get-style promotion, including their expiry behavior.
5. Distinguish onEviction for expired/rotated-out entries from explicit delete and clear. Show their effects on both maps/current count without inventing callbacks on manual deletion.
6. Iteration, resize and exact public size arithmetic are outside scope. Support all authored claims with inspected source ranges; include useful views/cards without content-count targets.

Deliver an English source-backed Architecture showcase in output/diagram.architecture.json and output/diagram.html. Keep exact repository metadata and source evidence. Use the complete normal finalize command with --repo-root ./repo --quality showcase --json. All authoring, helper execution, repairs and final response count toward time. Allow at most three focused repairs after the first finalize; if still blocked, report the failure without changing meaning or quality. Stop within 600 seconds. Do not claim machine success is semantic/visual human acceptance.
Do not create a separate report or screenshots during authoring. Final response should identify the artifact and actual gate status concisely. Every visible role and material explanation must be grounded in source; no node/edge/evidence/card/view quotas.

Controlled condition: follow the ordinary packaged Skill authoring path. No additional helper is provided.
