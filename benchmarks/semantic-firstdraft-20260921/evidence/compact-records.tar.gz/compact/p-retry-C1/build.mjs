import {architecture, edge, node, writeArchitecture} from './tools/author-kit.mjs';

const spec = architecture(
  {
    title: 'pRetry: attempts, failure decisions, and cancellation boundaries',
    locale: 'en',
    repository: {
      url: 'https://github.com/sindresorhus/p-retry.git',
      revision: '1472907affe8d6107aba5884abc36d6361b3042e',
    },
    views: [
      {
        id: 'normal-loop',
        label: 'Who controls an ordinary retry?',
        focus: ['caller', 'controller', 'operation', 'failure', 'timer'],
        note: 'pRetry owns counters and the retry loop; the supplied input only performs one attempt.',
      },
      {
        id: 'failure-decisions',
        label: 'What happens after an attempt fails?',
        focus: ['failure', 'consume-hook', 'failed-hook', 'retry-hook'],
        note: 'Hooks run consume → failed-attempt → retry, after time and retry-count guards.',
      },
      {
        id: 'stop-and-abort',
        label: 'Where can retries stop?',
        focus: ['abort-error', 'signal', 'failure', 'timer', 'outcome'],
        note: 'AbortError and rejected decisions stop retrying; AbortSignal can reject a pending delay.',
      },
    ],
  },
  [
    node('caller', 'external', 'Caller', 'Supplies input and retry options.', [50, 270, 185, 74], ['index.js:200-201']),
    node('controller', 'backend', 'pRetry controller', 'Owns attemptNumber, retriesConsumed, startTime, and the loop.', [300, 270, 245, 86], ['index.js:233-259']),
    node('operation', 'external', 'Caller-provided input', 'Runs one attempt; receives attemptNumber.', [625, 120, 225, 76], ['index.js:240-249']),
    node('abort-error', 'external', 'AbortError', 'Operation can use it to stop retries and preserve originalError.', [935, 105, 255, 78], ['index.js:49-62']),
    node('failure', 'backend', 'Failure controller', 'Normalizes errors; computes retries left, remaining retry time, and delay.', [620, 330, 290, 90], ['index.js:109-168']),
    node('consume-hook', 'external', 'shouldConsumeRetry', 'First hook: decides whether this failure consumes retry budget.', [965, 275, 245, 82], ['index.js:140-155']),
    node('failed-hook', 'external', 'onFailedAttempt', 'Second hook: observes the frozen failure context.', [965, 420, 245, 78], ['index.js:150-158']),
    node('retry-hook', 'external', 'shouldRetry', 'Third hook: false rejects; true permits the next attempt.', [1260, 420, 250, 78], ['index.js:170-186']),
    node('timer', 'backend', 'Backoff timer', 'Waits only when a retry is consumed; delay is capped by maxTimeout and remaining maxRetryTime.', [650, 600, 360, 90], ['index.js:66-106', 'index.js:184-197']),
    node('signal', 'external', 'AbortSignal', 'Controller checks it around attempts; delay listens once and clears its timer.', [50, 520, 300, 82], ['index.js:89-105', 'index.js:233-247']),
    node('outcome', 'external', 'Caller promise outcome', 'Successful value returns, or the last/original error rejects.', [300, 730, 270, 78], ['index.js:114-116', 'index.js:245-249']),
  ],
  [
    edge('start', 'caller', 'controller', 'call pRetry(input, options)', {variant: 'emphasis'}),
    edge('invoke', 'controller', 'operation', 'input(attemptNumber)'),
    edge('success', 'operation', 'controller', 'fulfilled value → return', {variant: 'emphasis'}),
    edge('failure-path', 'operation', 'failure', 'rejected / thrown error'),
    edge('abort-request', 'operation', 'abort-error', 'may throw to stop retries', {variant: 'dashed'}),
    edge('unwrap', 'abort-error', 'failure', 'unwrap originalError; skip hooks', {variant: 'dashed'}),
    edge('consume', 'failure', 'consume-hook', '1. shouldConsumeRetry(context)'),
    edge('failed', 'consume-hook', 'failed-hook', '2. then onFailedAttempt(context)'),
    edge('retry', 'failed-hook', 'retry-hook', '3. then shouldRetry(context)'),
    edge('no-consume-loop', 'retry-hook', 'controller', 'approved + no consume → loop; no wait', {variant: 'dashed', fromSide: 'bottom', toSide: 'right', via: [[1385, 530], [580, 530], [580, 313]]}),
    edge('wait', 'retry-hook', 'timer', 'approved + consume → bounded delay'),
    edge('resume', 'timer', 'controller', 'timer resolves → increment consumed; loop', {variant: 'emphasis', fromSide: 'left', toSide: 'right', via: [[610, 645], [610, 395], [610, 313]]}),
    edge('signal-check', 'signal', 'controller', 'throwIfAborted before / after await input', {variant: 'security'}),
    edge('cancel-delay', 'signal', 'timer', 'abort clears timeout and rejects delay', {variant: 'security', fromSide: 'bottom', toSide: 'bottom', via: [[200, 710], [830, 710]]}),
    edge('return-value', 'controller', 'outcome', 'return successful value', {variant: 'emphasis'}),
    edge('reject-error', 'failure', 'outcome', 'reject: time/count exhausted, non-network TypeError, or shouldRetry false', {variant: 'dashed', fromSide: 'bottom', toSide: 'top', via: [[765, 450], [570, 450], [570, 690], [435, 690]]}),
  ],
  {
    boundaries: [
      {kind: 'region', label: 'p-retry retry controller', wraps: ['controller', 'failure', 'timer'], pad: 34},
    ],
    cards: [
      {
        dot: 'cyan',
        title: 'Controller ownership',
        items: [
          'pRetry increments attemptNumber, tracks retriesConsumed, and starts maxRetryTime with performance.now().',
          'maxRetryTime bounds retry decisions and waiting; it is not a deadline that interrupts a running input promise.',
        ],
      },
      {
        dot: 'amber',
        title: 'Failure ordering and stopping',
        items: [
          'After a failed attempt with time remaining: shouldConsumeRetry → onFailedAttempt → guards → shouldRetry.',
          'No retry follows exhausted retry time or count, a non-network TypeError, or shouldRetry returning false.',
          'When consumption is false but retry is approved, pRetry loops without incrementing retriesConsumed or waiting.',
        ],
      },
      {
        dot: 'rose',
        title: 'Two cancellation mechanisms',
        items: [
          'AbortError is unwrapped to originalError and skips all hooks; it is an operation-directed stop.',
          'AbortSignal cancels a pending retry delay and is checked around input, but input receives only attemptNumber; cancelling its in-flight work is the caller operation’s job.',
        ],
      },
    ],
  },
);

await writeArchitecture('output/diagram.architecture.json', spec);
