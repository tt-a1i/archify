import {node, edge, architecture, writeArchitecture} from './tools/author-kit.mjs';

const src = (line, end_line, label) => ({path: 'src/index.js', line, end_line, label});

const spec = architecture(
  {
    title: 'Async lilconfig Explorer: search() and load()',
    locale: 'en',
    repository: {
      url: 'https://github.com/antonk52/lilconfig.git',
      revision: '6ae4bcdd4594b3909626dcd95b841a60ca165fd3',
    },
    views: [
      {id: 'creation', label: 'Who configures the explorer?', focus: ['caller', 'explorer', 'options', 'loaders', 'transform'], note: 'lilconfig merges defaults and caller options, then creates one async explorer.'},
      {id: 'search', label: 'How does upward search decide?', focus: ['search', 'searchCache', 'filesystem', 'candidate', 'package'], note: 'Search tests each configured place per directory, skips inaccessible candidates, and stops at stopDir or root.'},
      {id: 'load', label: 'How is explicit load different?', focus: ['load', 'loadCache', 'filesystem', 'loaders', 'transform'], note: 'load resolves one filepath and has a cache independent of search results.'},
      {id: 'outcomes', label: 'What is returned or rejected?', focus: ['transform', 'result', 'errors', 'searchCache', 'loadCache'], note: 'Transform receives found, empty, or null results; read, loader, parse, and transform failures reject.'},
    ],
  },
  [
    node('caller', 'external', 'Caller', 'creates lilconfig, then calls search() or load(filepath)', [40, 340, 270, 86], [src(156, 172, 'async explorer entry'), src(246, 255, 'explicit load entry')]),
    node('explorer', 'backend', 'Explorer controller', 'owns async search/load methods and two cache maps', [370, 340, 220, 78], [src(156, 172, 'creation and controller'), src(167, 169, 'cache ownership')]),
    node('options', 'backend', 'Merged options', 'defaults + overrides: places, stopDir, cache, packageProp', [370, 70, 230, 76], [src(96, 110, 'option merge'), src(111, 125, 'loader validation')]),
    node('loaders', 'backend', 'Configured loader behavior', 'extension/noExt parses; missing or invalid loader throws', [670, 45, 250, 76], [src(111, 122, 'configured loader checks'), src(144, 148, 'load-time validation'), src(199, 225, 'search loader use')]),
    node('transform', 'backend', 'Configured transform callback', 'takes found, empty, or null; return value is cached', [1000, 70, 250, 78], [src(234, 244, 'search transformation'), src(260, 294, 'load transformation')]),
    node('searchCache', 'database', 'Search cache', 'directory → transformed result; shares result with visited dirs', [670, 245, 240, 76], [src(167, 169, 'search cache map'), src(183, 190, 'lookup and visited'), src(240, 242, 'cache transformed search')]),
    node('loadCache', 'database', 'Load cache', 'absolute filepath → transformed load result', [670, 610, 240, 72], [src(167, 169, 'load cache map'), src(248, 251, 'load cache lookup'), src(150, 154, 'conditional emplace')]),
    node('search', 'backend', 'search() upward walk', 'from searchFrom; parents to stopDir or filesystem root', [980, 245, 235, 80], [src(172, 193, 'search loop'), src(230, 231, 'search termination')]),
    node('candidate', 'backend', 'Search candidate decision', 'access failure skips; empty file skips when configured', [1285, 235, 275, 92], [src(192, 201, 'access then read'), src(216, 228, 'empty/file decision')]),
    node('package', 'backend', 'package.json extraction', 'parse with its loader; use packageProp only when a non-null config exists', [1285, 445, 275, 78], [src(203, 214, 'package search branch'), src(128, 136, 'packageProp extraction')]),
    node('load', 'backend', 'load(filepath)', 'resolves one path; selects extension/noExt loader, then reads', [980, 600, 235, 82], [src(246, 256, 'load path and loader')]),
    node('filesystem', 'external', 'Filesystem boundary', 'access checks search candidates; readFile supplies bytes to both paths', [1630, 330, 270, 80], [src(194, 200, 'search access/read'), src(252, 256, 'load parse/read')]),
    node('result', 'external', 'Transformed result', 'found or empty result, or transform(null) for a normal search miss', [1330, 70, 255, 82], [src(234, 244, 'search return forms'), src(275, 294, 'load empty/found forms')]),
    node('errors', 'external', 'Rejected error', 'file read, loader/parse, or transform failures propagate to the caller', [1300, 640, 275, 74], [src(199, 225, 'search awaits failures'), src(234, 244, 'search transform failure'), src(252, 294, 'load awaits failures')]),
    node('cacheOps', 'backend', 'Cache clearing controls', 'separate search/load clearing; clearCaches clears both when enabled', [650, 790, 280, 76], [src(296, 306, 'independent cache clearing')]),
  ],
  [
    edge('create', 'caller', 'explorer', 'create explorer', {variant: 'emphasis'}),
    edge('merge', 'caller', 'options', 'name + options'),
    edge('configure', 'options', 'explorer', 'resolved options'),
    edge('loaderConfig', 'options', 'loaders', 'default loaders + overrides'),
    edge('transformConfig', 'options', 'transform', 'configured callback'),
    edge('searchInvoke', 'explorer', 'search', 'search(searchFrom)'),
    edge('searchHit', 'search', 'searchCache', 'directory cache lookup'),
    edge('walk', 'search', 'candidate', 'each searchPlace in current directory'),
    edge('probe', 'candidate', 'filesystem', 'access candidate; failure skips'),
    edge('readSearch', 'filesystem', 'candidate', 'read candidate bytes'),
    edge('packageBranch', 'candidate', 'package', 'when searchPlace is package.json'),
    edge('packageFound', 'package', 'transform', 'matching packageProp result'),
    edge('parsedCandidate', 'candidate', 'loaders', 'select extension/noExt loader', {via: [[1100, 185]]}),
    edge('loadedSearch', 'loaders', 'transform', 'found or accepted empty result'),
    edge('miss', 'search', 'transform', 'normal miss → null'),
    edge('cacheSearch', 'transform', 'searchCache', 'cache transformed result for visited dirs'),
    edge('loadInvoke', 'explorer', 'load', 'load(filepath)'),
    edge('loadHit', 'load', 'loadCache', 'absolute-path cache lookup'),
    edge('readLoad', 'load', 'filesystem', 'resolve path then readFile'),
    edge('loadBytes', 'filesystem', 'load', 'file bytes'),
    edge('loadTransform', 'load', 'loaders', 'run selected loader'),
    edge('cacheLoad', 'transform', 'loadCache', 'cache transformed explicit-load result'),
    edge('return', 'transform', 'result', 'return transformed value', {variant: 'emphasis'}),
    edge('searchFailures', 'candidate', 'errors', 'read/loader/parse failure rejects', {variant: 'dashed'}),
    edge('loadFailures', 'load', 'errors', 'read/loader failure rejects', {variant: 'dashed'}),
    edge('transformFailures', 'transform', 'errors', 'transform rejects', {variant: 'dashed'}),
    edge('clearSearch', 'cacheOps', 'searchCache', 'clearSearchCache()'),
    edge('clearLoad', 'cacheOps', 'loadCache', 'clearLoadCache() / clearCaches()'),
  ],
  {
    boundaries: [
      {kind: 'region', label: 'Async explorer instance (closure-owned state)', wraps: ['explorer', 'searchCache', 'loadCache', 'search', 'load', 'cacheOps'], pad: 22},
      {kind: 'region', label: 'Caller-configured behavior', wraps: ['options', 'loaders', 'transform'], pad: 20},
    ],
    cards: [
      {dot: 'cyan', title: 'Search is a directory walk', items: ['An inaccessible candidate is skipped, then search continues through places and parent directories.', 'A package.json only ends search when packageProp produces a non-null config.']},
      {dot: 'violet', title: 'Explicit load is separate', items: ['load() resolves one path and keys its own cache by absolute path.', 'Both APIs cache transformed values, but their clearing methods target different maps.']},
      {dot: 'amber', title: 'Empty, miss, and error differ', items: ['An ignored empty search candidate is skipped; a normal search miss calls transform(null).', 'Read, loader/parse, and transform exceptions are not converted into misses.']},
    ],
  },
);

await writeArchitecture('output/diagram.architecture.json', spec);
