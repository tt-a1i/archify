import fs from 'node:fs';
import {writeDraft} from './tools/firstpass.mjs';

const task = JSON.parse(fs.readFileSync('./task.json', 'utf8'));

const source = (line, end_line, label) => [{path: 'src/index.js', line, end_line, label}];
const draft = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'Asynchronous lilconfig Explorer',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/antonk52/lilconfig.git',
      revision: '6ae4bcdd4594b3909626dcd95b841a60ca165fd3',
      provider: 'github'
    },
    views: [
      {id: 'creation', label: 'Creation and ownership', focus: ['caller', 'factory', 'explorer', 'loader', 'transform'], note: 'Caller-supplied options override defaults; loaders merge by extension before one async explorer is returned.'},
      {id: 'search', label: 'Search: climb and decide', focus: ['search-api', 'search-cache', 'walker', 'filesystem', 'candidate'], note: 'A miss from access() skips only that candidate; traversal continues until stopDir or filesystem root.'},
      {id: 'load', label: 'Explicit-file load', focus: ['load-api', 'load-cache', 'load-select', 'filesystem', 'loader'], note: 'load(filepath) resolves one path and uses its own cache; it does not perform upward search.'},
      {id: 'results', label: 'Results, caches, and failures', focus: ['candidate', 'transform', 'search-cache', 'load-cache', 'caller'], note: 'Transform receives a result or null; read, loader, parse, and transform failures reject instead of becoming misses.'}
    ]
  },
  components: [
    {id: 'caller', type: 'external', label: 'Caller', sublabel: 'calls lilconfig(name, options), search(), or load(filepath)', tag: 'configuration owner', row: 0, col: 0, sources: source(156, 172, 'async factory and API')},
    {id: 'factory', type: 'backend', label: 'Option merger', sublabel: 'defaults + caller options; default loaders merged with options.loaders', tag: 'creation', row: 0, col: 1, sources: source(96, 125, 'getOptions merges and validates')},
    {id: 'explorer', type: 'backend', label: 'Async explorer controller', sublabel: 'owns searchCache, loadCache, cache policy, and the two public paths', tag: 'lilconfig()', row: 0, col: 2, sources: source(156, 171, 'explorer state')},
    {id: 'transform', type: 'external', label: 'Configured transform callback', sublabel: 'receives result or null and may reject; its output is returned and cached', tag: 'caller behavior', row: 0, col: 3, sources: source(98, 109, 'default and supplied transform')},
    {id: 'returned', type: 'external', label: 'Awaited result or error', sublabel: 'found/empty result or transformed null; operational failures reject', tag: 'caller receives', row: 0, col: 4, sources: source(234, 244, 'search transform and return')},

    {id: 'loader', type: 'external', label: 'Configured loader behavior', sublabel: 'selected by extension or noExt; parses JSON or loads configuration', tag: 'caller/default behavior', row: 1, col: 4, sources: source(80, 87, 'async default loaders')},
    {id: 'search-api', type: 'backend', label: 'search(searchFrom)', sublabel: 'starts at searchFrom or process.cwd(); initializes a not-found result', tag: 'upward discovery', row: 2, col: 0, sources: source(172, 181, 'search entry')},
    {id: 'search-cache', type: 'database', label: 'Search cache', sublabel: 'Map keyed by visited directory; hits are returned and backfilled to visited paths', tag: 'cleared only by clearSearchCache()', row: 2, col: 1, sources: source(167, 169, 'separate cache maps')},
    {id: 'walker', type: 'backend', label: 'Upward search walker', sublabel: 'for each directory, tries configured searchPlaces; then parentDir until stopDir or root', tag: 'search control', row: 2, col: 2, sources: source(179, 193, 'visited directories and candidates')},
    {id: 'filesystem', type: 'external', label: 'Local filesystem boundary', sublabel: 'access() tests candidates; readFile() supplies bytes; read errors propagate', tag: 'outside explorer', row: 2, col: 3, sources: source(193, 201, 'search access and read')},
    {id: 'candidate', type: 'backend', label: 'Search candidate decisions', sublabel: 'package.json requires packageProp; empty files can be skipped or returned as isEmpty', tag: 'found, skip, or continue', row: 2, col: 4, sources: source(203, 231, 'package and empty branches')},
    {id: 'stop', type: 'backend', label: 'Search stopping boundary', sublabel: 'stop at configured stopDir or when parentDir(dir) equals dir; then transform null on normal miss', tag: 'normal termination', row: 3, col: 2, sources: source(230, 238, 'termination and no match')},

    {id: 'load-api', type: 'backend', label: 'load(filepath)', sublabel: 'requires a non-empty path and resolves it from process.cwd()', tag: 'explicit-file path', row: 4, col: 0, sources: source(246, 255, 'load entry and selection')},
    {id: 'load-cache', type: 'database', label: 'Load cache', sublabel: 'Map keyed by resolved absolute filepath; cleared only by clearLoadCache()', tag: 'separate from search cache', row: 4, col: 1, sources: source(246, 251, 'load cache lookup')},
    {id: 'load-select', type: 'backend', label: 'Load selector and empty handling', sublabel: 'selects extension/noExt loader, reads one file; empty becomes isEmpty with config undefined', tag: 'no upward walk', row: 4, col: 2, sources: source(252, 294, 'load selection and empty result')}
  ],
  boundaries: [
    {kind: 'region', label: 'lilconfig async explorer process', wraps: ['factory', 'explorer', 'search-api', 'search-cache', 'walker', 'candidate', 'stop', 'load-api', 'load-cache', 'load-select'], pad: 32}
  ],
  connections: [
    {id: 'create', from: 'caller', to: 'factory', label: 'name + options'},
    {id: 'merged-options', from: 'factory', to: 'explorer', label: 'validated merged options and loaders'},
    {id: 'configured-loader', from: 'factory', to: 'loader', label: 'default + supplied loader mapping'},
    {id: 'configured-transform', from: 'factory', to: 'transform', label: 'configured transform'},
    {id: 'invoke-search', from: 'caller', to: 'search-api', label: 'await search(searchFrom?)'},
    {id: 'search-cache-lookup', from: 'search-api', to: 'search-cache', label: 'lookup by current directory'},
    {id: 'walk-places', from: 'search-cache', to: 'walker', label: 'cache miss: inspect searchPlaces'},
    {id: 'probe-candidate', from: 'walker', to: 'filesystem', label: 'access(candidate)'},
    {id: 'candidate-bytes', from: 'filesystem', to: 'candidate', label: 'accessible: readFile text'},
    {id: 'skip-inaccessible', from: 'filesystem', to: 'walker', label: 'access failure: skip candidate and continue', variant: 'dashed'},
    {id: 'package-or-empty', from: 'candidate', to: 'loader', label: 'packageProp extraction or non-empty loader'},
    {id: 'continue-upward', from: 'candidate', to: 'walker', label: 'missing packageProp or ignored empty: continue', variant: 'dashed'},
    {id: 'terminate-search', from: 'walker', to: 'stop', label: 'next parent or stopDir/root'},
    {id: 'searched-result', from: 'candidate', to: 'transform', label: 'found config or isEmpty result'},
    {id: 'not-found', from: 'stop', to: 'transform', label: 'normal miss: transform(null)'},
    {id: 'search-cache-store', from: 'transform', to: 'search-cache', label: 'store transformed result for visited paths'},
    {id: 'search-return', from: 'transform', to: 'returned', label: 'return transformed search result'},
    {id: 'invoke-load', from: 'caller', to: 'load-api', label: 'await load(filepath)'},
    {id: 'load-cache-lookup', from: 'load-api', to: 'load-cache', label: 'lookup resolved absolute path'},
    {id: 'load-cache-miss', from: 'load-cache', to: 'load-select', label: 'miss: select extension/noExt loader'},
    {id: 'load-read', from: 'load-select', to: 'filesystem', label: 'readFile(explicit path)'},
    {id: 'load-parse', from: 'load-select', to: 'loader', label: 'packageProp or non-empty loader'},
    {id: 'load-transform', from: 'load-select', to: 'transform', label: 'empty or loaded result'},
    {id: 'load-cache-store', from: 'transform', to: 'load-cache', label: 'store transformed result by absolute path'},
    {id: 'load-return', from: 'transform', to: 'returned', label: 'return transformed load result'}
  ],
  cards: [
    {dot: 'cyan', title: 'What makes a search candidate meaningful', items: ['Each directory tries configured searchPlaces in order. An access() failure is a skipped candidate, not an error result.', 'A package.json is accepted only when getPackageProp(packageProp, parsedPackage) is non-null; otherwise search continues.', 'For other files, trim-empty content continues when ignoreEmptySearchPlaces is true; otherwise it returns { config: undefined, isEmpty: true }.']},
    {dot: 'violet', title: 'Two independent result memories', items: ['searchCache stores transformed outcomes by directory and backfills each visited directory; clearSearchCache() clears only it.', 'loadCache stores transformed outcomes by resolved absolute filepath; clearLoadCache() clears only it. clearCaches() clears both when cache is enabled.']},
    {dot: 'rose', title: 'Errors remain errors', items: ['search() propagates readFile, loader/parse, and transform failures. Only access() failure skips a search candidate; reaching stopDir/root is a normal miss.', 'load() validates filepath and loader, then propagates file-read, loader/parse, and transform failures. It has no search-miss path.']},
    {dot: 'amber', title: 'Scope of this map', items: ['This map follows lilconfig(), the asynchronous explorer. lilconfigSync() is outside scope.', 'The async default loader’s import/require fallback details are outside scope; this map shows its configured loader role and failure propagation.']}
  ]
};

const coverage = [
  {clause: 1, anchors: ['/components/1/sublabel', '/components/2/sublabel', '/components/5/sublabel', '/components/3/sublabel']},
  {clause: 2, anchors: ['/components/6/sublabel', '/components/8/sublabel', '/components/7/sublabel', '/components/11/sublabel', '/connections/14/label']},
  {clause: 3, anchors: ['/connections/9/label', '/components/10/sublabel', '/connections/11/label', '/cards/0/items/1', '/cards/0/items/2']},
  {clause: 4, anchors: ['/components/12/sublabel', '/components/13/sublabel', '/components/14/sublabel', '/connections/20/label']},
  {clause: 5, anchors: ['/components/3/sublabel', '/connections/15/label', '/cards/1/items/0', '/cards/1/items/1']},
  {clause: 6, anchors: ['/components/4/sublabel', '/connections/9/label', '/cards/2/items/0', '/cards/2/items/1']},
  {clause: 7, anchors: ['/cards/3/items/0', '/cards/3/items/1', '/meta/views/0/note', '/meta/views/2/note']}
];

fs.mkdirSync('output', {recursive: true});
fs.writeFileSync('output/initial-plan.json', JSON.stringify({draft, coverage}, null, 2));
const receipt = writeDraft('output/diagram.architecture.json', draft, {coverage, requirements: task.required, gapX: 132, gapY: 116});
fs.writeFileSync('output/preparation.json', JSON.stringify(receipt, null, 2));
