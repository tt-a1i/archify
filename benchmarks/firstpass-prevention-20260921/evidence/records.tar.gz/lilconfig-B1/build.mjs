import { mkdirSync, writeFileSync } from 'node:fs';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'Async lilconfig Explorer',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/antonk52/lilconfig.git',
      revision: '6ae4bcdd4594b3909626dcd95b841a60ca165fd3',
      link_mode: 'web'
    },
    views: [
      {
        id: 'search-walk',
        label: 'Search walk',
        focus: ['caller', 'explorerFactory', 'search', 'searchCache', 'filesystem', 'searchDecision', 'transform', 'result'],
        note: 'Walk configured places upward; an inaccessible candidate is skipped, while read, loader, and transform failures reject.'
      },
      {
        id: 'explicit-load',
        label: 'Explicit load',
        focus: ['caller', 'explorerFactory', 'load', 'loadCache', 'filesystem', 'loader', 'transform', 'result'],
        note: 'load(filepath) resolves one path and has a cache independent of the search walk.'
      },
      {
        id: 'outcomes',
        label: 'Outcomes & caches',
        focus: ['search', 'load', 'searchCache', 'loadCache', 'transform', 'result', 'error'],
        note: 'Both paths return transformed values; only search turns a normal miss into transform(null).'
      }
    ]
  },
  components: [
    {
      id: 'caller', type: 'external', label: 'Caller', sublabel: 'names explorer; calls search() or load()', pos: [30, 380], size: [190, 76],
      sources: [{ path: 'src/index.d.ts', line: 39, end_line: 46, label: 'async API' }]
    },
    {
      id: 'explorerFactory', type: 'backend', label: 'lilconfig(name, options)', sublabel: 'merges defaults and supplied loader map', pos: [280, 380], size: [205, 76],
      sources: [{ path: 'src/index.js', line: 96, end_line: 125, label: 'option merge' }, { path: 'src/index.js', line: 156, end_line: 169, label: 'async explorer' }]
    },
    {
      id: 'options', type: 'external', label: 'Caller options', sublabel: 'searchPlaces, stopDir, packageProp, cache', pos: [280, 580], size: [205, 70],
      sources: [{ path: 'src/index.d.ts', line: 6, end_line: 26, label: 'option types' }]
    },
    {
      id: 'explorer', type: 'backend', label: 'Explorer controller', sublabel: 'owns separate search and load caches', pos: [545, 380], size: [190, 76],
      sources: [{ path: 'src/index.js', line: 167, end_line: 171, label: 'cache ownership' }, { path: 'src/index.js', line: 296, end_line: 306, label: 'cache clearing' }]
    },
    {
      id: 'searchCache', type: 'database', label: 'Search cache', sublabel: 'directory → transformed result; clearSearchCache()', pos: [545, 95], size: [205, 70],
      sources: [{ path: 'src/index.js', line: 167, end_line: 169, label: 'cache creation' }, { path: 'src/index.js', line: 183, end_line: 190, label: 'cache lookup' }, { path: 'src/index.js', line: 240, end_line: 242, label: 'visited entries' }]
    },
    {
      id: 'loadCache', type: 'database', label: 'Load cache', sublabel: 'absolute path → transformed result; clearLoadCache()', pos: [545, 700], size: [205, 70],
      sources: [{ path: 'src/index.js', line: 246, end_line: 255, label: 'load cache lookup' }, { path: 'src/index.js', line: 296, end_line: 305, label: 'independent clearing' }]
    },
    {
      id: 'search', type: 'backend', label: 'search(searchFrom)', sublabel: 'walks upward across configured searchPlaces', pos: [810, 235], size: [210, 76],
      sources: [{ path: 'src/index.js', line: 172, end_line: 193, label: 'search loop' }, { path: 'src/index.js', line: 230, end_line: 244, label: 'stop and return' }]
    },
    {
      id: 'load', type: 'backend', label: 'load(filepath)', sublabel: 'resolves exactly one explicit file path', pos: [810, 545], size: [210, 76],
      sources: [{ path: 'src/index.js', line: 246, end_line: 256, label: 'explicit load' }, { path: 'src/index.js', line: 269, end_line: 294, label: 'load result handling' }]
    },
    {
      id: 'filesystem', type: 'external', label: 'Filesystem', sublabel: 'access() then readFile() for search; readFile() for load', pos: [1090, 390], size: [235, 76],
      sources: [{ path: 'src/index.js', line: 192, end_line: 201, label: 'search filesystem boundary' }, { path: 'src/index.js', line: 252, end_line: 256, label: 'load filesystem boundary' }]
    },
    {
      id: 'searchDecision', type: 'backend', label: 'Search candidate decision', sublabel: 'skip access miss; packageProp match; empty policy', pos: [1090, 120], size: [235, 76],
      sources: [{ path: 'src/index.js', line: 194, end_line: 228, label: 'candidate branches' }, { path: 'src/index.js', line: 128, end_line: 136, label: 'packageProp extraction' }]
    },
    {
      id: 'loader', type: 'external', label: 'Configured loader', sublabel: 'selected by extension/noExt; parse or execute content', pos: [1385, 435], size: [220, 76],
      sources: [{ path: 'src/index.js', line: 80, end_line: 88, label: 'default loaders' }, { path: 'src/index.js', line: 200, end_line: 225, label: 'search loader use' }, { path: 'src/index.js', line: 252, end_line: 259, label: 'load loader use' }]
    },
    {
      id: 'transform', type: 'external', label: 'Configured transform', sublabel: 'receives found/empty result or null miss', pos: [1680, 380], size: [225, 76],
      sources: [{ path: 'src/index.js', line: 234, end_line: 244, label: 'search transform' }, { path: 'src/index.js', line: 258, end_line: 294, label: 'load transform' }]
    },
    {
      id: 'result', type: 'external', label: 'Resolved transformed result', sublabel: 'found config, empty result, or transform(null) on search miss', pos: [1980, 265], size: [250, 76],
      sources: [{ path: 'src/index.js', line: 234, end_line: 244, label: 'search return' }, { path: 'src/index.js', line: 276, end_line: 294, label: 'load return' }]
    },
    {
      id: 'error', type: 'external', label: 'Rejected promise / error', sublabel: 'read, missing loader, parse, loader, or transform failure propagates', pos: [1980, 575], size: [290, 76],
      sources: [{ path: 'src/index.js', line: 139, end_line: 148, label: 'validation errors' }, { path: 'src/index.js', line: 194, end_line: 225, label: 'search propagation' }, { path: 'src/index.js', line: 246, end_line: 294, label: 'load propagation' }]
    }
  ],
  boundaries: [
    { kind: 'region', label: 'Async explorer runtime', wraps: ['explorerFactory', 'explorer', 'searchCache', 'loadCache', 'search', 'load', 'searchDecision'], pad: 36 },
    { kind: 'region', label: 'Caller-owned configuration behavior', wraps: ['options', 'loader', 'transform'], pad: 28 }
  ],
  connections: [
    { id: 'create', from: 'caller', to: 'explorerFactory', label: 'create async explorer' },
    { id: 'supplyOptions', from: 'caller', to: 'options', label: 'options' },
    { id: 'mergeOptions', from: 'options', to: 'explorerFactory', label: 'merge overrides + default loaders' },
    { id: 'returnsExplorer', from: 'explorerFactory', to: 'explorer', label: 'returns controller' },
    { id: 'searchCall', from: 'caller', to: 'search', label: 'search(starting directory)', fromSide: 'top', toSide: 'top', via: [[125, 180], [915, 180]] },
    { id: 'loadCall', from: 'caller', to: 'load', label: 'load(filepath)', fromSide: 'bottom', toSide: 'bottom', via: [[125, 700], [915, 700]] },
    { id: 'searchLookup', from: 'search', to: 'searchCache', label: 'lookup by current directory' },
    { id: 'searchHit', from: 'searchCache', to: 'search', label: 'cached transformed result' },
    { id: 'searchAccess', from: 'search', to: 'filesystem', label: 'access each candidate while walking up' },
    { id: 'candidateBytes', from: 'filesystem', to: 'searchDecision', label: 'accessible candidate bytes' },
    { id: 'skipCandidate', from: 'searchDecision', to: 'search', label: 'access miss / packageProp absent / ignored empty → continue' },
    { id: 'searchLoader', from: 'searchDecision', to: 'loader', label: 'select extension loader' },
    { id: 'loadedSearchConfig', from: 'loader', to: 'search', label: 'parsed candidate config', fromSide: 'top', toSide: 'top', via: [[1495, 45], [915, 45]] },
    { id: 'searchStop', from: 'search', to: 'transform', label: 'found result, or null at stopDir/root' },
    { id: 'cacheSearchResult', from: 'transform', to: 'searchCache', label: 'cache transformed result for visited directories' },
    { id: 'loadLookup', from: 'load', to: 'loadCache', label: 'lookup resolved absolute path' },
    { id: 'loadHit', from: 'loadCache', to: 'load', label: 'cached transformed result' },
    { id: 'loadRead', from: 'load', to: 'filesystem', label: 'read explicit file' },
    { id: 'loadBytes', from: 'filesystem', to: 'load', label: 'file bytes or read rejection' },
    { id: 'loadLoader', from: 'load', to: 'loader', label: 'extension/noExt loader; packageProp for package.json', route: 'straight' },
    { id: 'loadedFileConfig', from: 'loader', to: 'load', label: 'parsed explicit config' },
    { id: 'loadTransform', from: 'load', to: 'transform', label: 'found or empty result' },
    { id: 'cacheLoadResult', from: 'transform', to: 'loadCache', label: 'cache transformed result by absolute path' },
    { id: 'returnResult', from: 'transform', to: 'result', label: 'resolve transformed value' },
    { id: 'fsError', from: 'filesystem', to: 'error', label: 'read failure propagates', variant: 'dashed' },
    { id: 'loaderError', from: 'loader', to: 'error', label: 'parse/loader failure propagates', variant: 'dashed' },
    { id: 'transformError', from: 'transform', to: 'error', label: 'transform failure propagates', variant: 'dashed' }
  ],
  cards: [
    {
      dot: 'cyan', title: 'Search is a directory walk',
      items: ['At each directory it checks cached results, then configured searchPlaces.', 'An access failure is a candidate skip, not an error; walking ends at stopDir or the filesystem root.', 'package.json counts only when packageProp extracts a non-null configuration.']
    },
    {
      dot: 'emerald', title: 'Empty and missing have different outcomes',
      items: ['An empty non-package candidate is skipped when ignoreEmptySearchPlaces is true; otherwise it is a found empty result.', 'A normal search miss calls transform(null). Explicit load always addresses its given file and transforms its found or empty result.']
    },
    {
      dot: 'violet', title: 'Caches retain transformed values',
      items: ['search caches the transformed result for every visited directory; load caches by resolved absolute filepath.', 'clearSearchCache() and clearLoadCache() clear only their respective map; clearCaches() clears both.']
    },
    {
      dot: 'rose', title: 'Errors are not normal misses',
      items: ['File reads, loader selection/parse/loader execution, and transform are awaited without recovery, so their failures reject the call.', 'Only a failed access check during search is deliberately caught and skipped.']
    }
  ]
};

mkdirSync('output', { recursive: true });
writeFileSync('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
