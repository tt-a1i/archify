import {mkdir, writeFile} from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'QuickLRU: Two-Generation In-Memory Cache Lifecycle',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/quick-lru.git',
      revision: 'a2190ebdf8e455b95a7138803d274ff5ed57ebcd',
      provider: 'github'
    },
    views: [
      {
        id: 'write-rotation',
        label: 'Write and rotation',
        focus: ['caller', 'set', 'controller', 'current', 'old', 'eviction'],
        note: 'A threshold rotates whole generations; it is not a one-item LRU removal.'
      },
      {
        id: 'read-promotion',
        label: 'Read and promotion',
        focus: ['caller', 'get', 'inspect', 'current', 'old', 'expiry'],
        note: 'Only get promotes a live old-generation item into the current generation.'
      },
      {
        id: 'removal-semantics',
        label: 'Expiry and removal',
        focus: ['expiry', 'manual', 'current', 'old', 'eviction'],
        note: 'Expiry is lazy and can notify; delete and clear remove state without that callback.'
      }
    ]
  },
  components: [
    {
      id: 'caller', type: 'external', label: 'Caller', sublabel: 'uses the public Map-like API',
      pos: [34, 336], size: [180, 76],
      sources: [{path: 'index.js', line: 105, end_line: 179, label: 'public cache methods'}]
    },
    {
      id: 'controller', type: 'backend', label: 'QuickLRU instance', sublabel: 'owns maps, #size, #maxSize, #maxAge',
      pos: [294, 224], size: [230, 82],
      sources: [{path: 'index.js', line: 1, end_line: 23, label: 'private state and options'}]
    },
    {
      id: 'current', type: 'database', label: 'Current-generation Map', sublabel: '#cache: in-memory entries',
      pos: [610, 100], size: [220, 76],
      sources: [{path: 'index.js', line: 2, end_line: 4, label: 'in-memory maps'}]
    },
    {
      id: 'old', type: 'database', label: 'Old-generation Map', sublabel: '#oldCache: in-memory entries',
      pos: [610, 402], size: [220, 76],
      sources: [{path: 'index.js', line: 2, end_line: 4, label: 'in-memory maps'}]
    },
    {
      id: 'set', type: 'backend', label: 'set(key, value)', sublabel: 'current update or #set insertion',
      pos: [276, 78], size: [200, 70],
      sources: [{path: 'index.js', line: 68, end_line: 83, label: 'insert and rotate'}, {path: 'index.js', line: 120, end_line: 135, label: 'public set branches'}]
    },
    {
      id: 'get', type: 'backend', label: 'get(key)', sublabel: 'current return; old hit promotes',
      pos: [276, 424], size: [200, 70],
      sources: [{path: 'index.js', line: 105, end_line: 118, label: 'get branches'}]
    },
    {
      id: 'inspect', type: 'backend', label: 'has / peek', sublabel: 'inspect either map; no promotion',
      pos: [276, 596], size: [200, 70],
      sources: [{path: 'index.js', line: 137, end_line: 157, label: 'non-promoting reads'}]
    },
    {
      id: 'expiry', type: 'backend', label: 'Lazy expiry check', sublabel: 'expiry <= Date.now() removes and returns undefined/false',
      pos: [884, 248], size: [248, 82],
      sources: [{path: 'index.js', line: 40, end_line: 66, label: 'expiry removal and value'}, {path: 'index.js', line: 105, end_line: 116, label: 'get expiry handling'}]
    },
    {
      id: 'manual', type: 'backend', label: 'delete / clear', sublabel: 'manual removal across one or both maps',
      pos: [900, 560], size: [220, 70],
      sources: [{path: 'index.js', line: 166, end_line: 179, label: 'manual removal'}]
    },
    {
      id: 'eviction', type: 'external', label: 'onEviction callback', sublabel: 'optional caller-supplied function',
      pos: [1194, 118], size: [206, 76],
      sources: [{path: 'index.js', line: 20, end_line: 22, label: 'callback option'}, {path: 'index.js', line: 30, end_line: 37, label: 'emit old generation'}]
    }
  ],
  boundaries: [{kind: 'region', label: 'One QuickLRU object: volatile process memory only', wraps: ['controller', 'current', 'old', 'set', 'get', 'inspect', 'expiry', 'manual'], pad: 26}],
  connections: [
    {id: 'api', from: 'caller', to: 'controller', label: 'set · get · has · peek · delete · clear', variant: 'emphasis'},
    {id: 'write', from: 'controller', to: 'set', label: 'dispatch set'},
    {id: 'read', from: 'controller', to: 'get', label: 'dispatch get'},
    {id: 'probe', from: 'controller', to: 'inspect', label: 'dispatch has / peek'},
    {id: 'remove', from: 'controller', to: 'manual', label: 'dispatch delete / clear'},
    {id: 'current-update', from: 'set', to: 'current', label: 'current key: replace value + expiry; #size unchanged'},
    {id: 'new-current', from: 'set', to: 'current', label: 'absent from current: insert; #size++ (old may still hold key)'},
    {id: 'rotation', from: 'current', to: 'old', label: '#size >= #maxSize: reset #size; emit old; rotate whole current Map', variant: 'emphasis'},
    {id: 'get-current', from: 'get', to: 'current', label: 'current hit: return live value', labelAt: [960, 430]},
    {id: 'get-old', from: 'get', to: 'old', label: 'old hit: check before promotion', labelAt: [980, 550]},
    {id: 'promote', from: 'old', to: 'current', label: 'live old hit: delete old; #set into current', variant: 'emphasis'},
    {id: 'miss', from: 'get', to: 'caller', label: 'missing or expired: undefined', variant: 'dashed'},
    {id: 'inspect-current', from: 'inspect', to: 'current', label: 'has/peek: inspect without moving'},
    {id: 'inspect-old', from: 'inspect', to: 'old', label: 'has/peek: inspect without moving'},
    {id: 'check-current', from: 'current', to: 'expiry', label: 'live/expired item check'},
    {id: 'check-old', from: 'old', to: 'expiry', label: 'live/expired item check'},
    {id: 'expired-remove', from: 'expiry', to: 'controller', label: 'expired: onEviction then delete(key)', variant: 'emphasis'},
    {id: 'expired-callback', from: 'expiry', to: 'eviction', label: 'expired item value'},
    {id: 'rotation-callback', from: 'controller', to: 'eviction', label: 'rotated-out old Map entries'},
    {id: 'manual-current', from: 'manual', to: 'current', label: 'delete: remove current and decrement #size; clear: empty'},
    {id: 'manual-old', from: 'manual', to: 'old', label: 'delete: remove old; clear: empty'},
    {id: 'no-manual-callback', from: 'manual', to: 'eviction', label: 'no callback for delete / clear', variant: 'dashed'}
  ],
  cards: [
    {dot: 'cyan', title: 'Why two generations', items: ['#set resets #size and makes the completed current Map the old generation at #maxSize.', 'Before replacement, #emitEvictions visits the prior old generation. Rotation is a whole-Map generation change, not an eviction of one least-recent item.']},
    {dot: 'emerald', title: 'Read semantics', items: ['get checks current first. A live old entry is deleted from old and reinserted through #set, so it becomes recent.', 'has and peek check current then old but do not call #moveToRecent. Their expiry check can remove an expired entry.']},
    {dot: 'amber', title: 'Expiry and manual removal', items: ['When an item has an elapsed numeric expiry, #deleteIfExpired calls onEviction when configured, then delete(key) removes it.', 'delete removes a key from both maps and adjusts #size only when current deleted; clear empties both maps and sets #size to zero. Neither method calls onEviction itself.']}
  ]
};

await mkdir(new URL('./output/', import.meta.url), {recursive: true});
await writeFile(new URL('./output/diagram.architecture.json', import.meta.url), `${JSON.stringify(diagram, null, 2)}\n`);
