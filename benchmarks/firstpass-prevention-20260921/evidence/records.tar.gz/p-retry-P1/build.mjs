import fs from 'node:fs';
import {writeDraft} from './tools/firstpass.mjs';

const task = JSON.parse(fs.readFileSync('./task.json', 'utf8'));

const source = (line, end_line, label) => ({path: 'index.js', line, end_line, label});
const draft = {
	"schema_version": 1,
	"diagram_type": "architecture",
	"meta": {
		"title": "pRetry: operation, retry controller, and stopping paths",
		"locale": "en",
		"quality_profile": "showcase",
		"repository": {
			"url": "https://github.com/sindresorhus/p-retry",
			"provider": "github",
			"link_mode": "web",
			"revision": "1472907affe8d6107aba5884abc36d6361b3042e"
		},
		"views": [
			{
				"id": "attempt-loop",
				"label": "Attempt ownership",
				"focus": ["caller", "controller", "operation", "failure", "timer"],
				"note": "pRetry owns attemptNumber, retriesConsumed, and startTime; input only receives an attempt number."
			},
			{
				"id": "failure-decisions",
				"label": "Failure decisions",
				"focus": ["failure", "hooks", "stop"],
				"note": "After a failure, consume is decided first, onFailedAttempt observes next, then shouldRetry may permit another attempt."
			},
			{
				"id": "abort-timer",
				"label": "Timer and cancellation",
				"focus": ["signal", "timer", "controller", "stop"],
				"note": "The signal is checked around attempts and delay; delay itself clears its timeout and rejects on abort."
			}
		]
	},
	"components": [
		{
			"id": "caller", "type": "external", "label": "Caller", "sublabel": "supplies input(operation) and options", "tag": "application code", "row": 1, "col": 0,
			"sources": [source(200, 201, 'pRetry parameters')]
		},
		{
			"id": "controller", "type": "backend", "label": "pRetry controller", "sublabel": "owns attemptNumber, retriesConsumed, startTime", "tag": "retry loop", "row": 0, "col": 1,
			"sources": [source(233, 260, 'signal checks, counters, loop')]
		},
		{
			"id": "operation", "type": "external", "label": "Caller-provided input", "sublabel": "await input(attemptNumber); owns operation work", "tag": "async operation", "row": 1, "col": 2,
			"sources": [source(242, 250, 'operation invocation')]
		},
		{
			"id": "success", "type": "external", "label": "Successful return", "sublabel": "resolved operation value returns to caller", "tag": "terminal success", "row": 2, "col": 2,
			"sources": [source(245, 249, 'return result')]
		},
		{
			"id": "failure", "type": "backend", "label": "onAttemptFailure", "sublabel": "normalizes failure; computes retries left and retry-time", "tag": "failure controller", "row": 1, "col": 1,
			"sources": [source(109, 124, 'failure setup'), source(158, 197, 'failure decisions and delay')]
		},
		{
			"id": "hooks", "type": "external", "label": "Caller failure hooks", "sublabel": "shouldConsumeRetry → onFailedAttempt → shouldRetry", "tag": "options callbacks", "row": 2, "col": 0,
			"sources": [source(140, 158, 'consume then failure callback'), source(170, 175, 'shouldRetry last')]
		},
		{
			"id": "timer", "type": "backend", "label": "Backoff timer", "sublabel": "delay ≤ maxTimeout and remaining maxRetryTime", "tag": "retry delay", "row": 2, "col": 1,
			"sources": [source(66, 82, 'delay and remaining time'), source(189, 195, 'bounded delay and signal checks')]
		},
		{
			"id": "signal", "type": "external", "label": "AbortSignal", "sublabel": "throws at checks; abort during delay clears timeout", "tag": "cancellation boundary", "row": 3, "col": 0,
			"sources": [source(84, 106, 'abortable delay'), source(233, 247, 'attempt signal checks')]
		},
		{
			"id": "stop", "type": "external", "label": "Final rejection", "sublabel": "original error, AbortError originalError, or signal reason", "tag": "terminal failure", "row": 3, "col": 2,
			"sources": [source(114, 116, 'AbortError unwrap'), source(160, 182, 'stopping throws'), source(89, 105, 'delay abort rejection')]
		}
	],
	"boundaries": [
		{
			"kind": "region", "label": "p-retry library runtime", "wraps": ["controller", "failure", "timer"], "pad": 32
		},
		{
			"kind": "region", "label": "caller-owned code and callbacks", "wraps": ["caller", "operation", "hooks", "signal"], "pad": 28
		}
	],
	"connections": [
		{"id": "request", "from": "caller", "to": "controller", "label": "call pRetry(input, options)"},
		{"id": "invoke", "from": "controller", "to": "operation", "label": "invoke input(attemptNumber)"},
		{"id": "value", "from": "operation", "to": "success", "label": "resolved value → return result"},
		{"id": "failure-back", "from": "operation", "to": "failure", "label": "throw/rejection enters failure controller", "variant": "emphasis"},
		{"id": "hook-order", "from": "failure", "to": "hooks", "label": "call: consume → failedAttempt → shouldRetry"},
		{"id": "consume", "from": "hooks", "to": "failure", "label": "consume? sets effective delay; retry policy"},
		{"id": "wait", "from": "failure", "to": "timer", "label": "only if consumed; cap delay by remaining time"},
		{"id": "retry-after-wait", "from": "timer", "to": "controller", "label": "delay completes → increment consumed retries → next attempt", "variant": "emphasis"},
		{"id": "retry-without-consume", "from": "failure", "to": "controller", "label": "not consumed → no delay, same retry count, next loop", "variant": "dashed"},
		{"id": "signal-to-controller", "from": "signal", "to": "controller", "label": "throwIfAborted before/after input"},
		{"id": "signal-to-timer", "from": "signal", "to": "timer", "label": "abort clears timeout and rejects delay"},
		{"id": "stop-on-rules", "from": "failure", "to": "stop", "label": "reject: exhausted time/retries, TypeError, or shouldRetry false", "variant": "emphasis"},
		{"id": "abort-error", "from": "failure", "to": "stop", "label": "AbortError → throw originalError", "variant": "dashed"},
		{"id": "signal-stop", "from": "signal", "to": "stop", "label": "signal reason rejects at a check", "variant": "dashed"}
	],
	"cards": [
		{
			"dot": "cyan", "title": "Counter and budget ownership", "items": [
				"pRetry initializes and increments attemptNumber, increments retriesConsumed only after a consuming retry, and records startTime.",
				"maxRetryTime is a retry-controller budget: remaining time is checked after failed attempts and callbacks; Infinity remains unlimited."
			]
		},
		{
			"dot": "amber", "title": "Exact failure ordering", "items": [
				"With time remaining, shouldConsumeRetry runs first; its result makes retryDelay either the calculated delay or zero. onFailedAttempt then always runs.",
				"Only while time and retries remain, and after non-network TypeError is excluded, shouldRetry can allow continuation. A false consume result loops without waiting or incrementing retriesConsumed."
			]
		},
		{
			"dot": "rose", "title": "Terminal paths", "items": [
				"pRetry rejects the normalized error when retry time or retries are exhausted, shouldRetry declines, or a TypeError is not a network error.",
				"An AbortError is unwrapped to originalError. AbortSignal cancellation is separate: an abort during delay clears that timer and rejects with signal.reason."
			]
		},
		{
			"dot": "violet", "title": "Timer boundary is not an input deadline", "items": [
				"Backoff is calculated, capped by maxTimeout, then bounded again by remaining maxRetryTime before delayForRetry waits.",
				"pRetry calls input with only attemptNumber and awaits it; its signal checks occur before and after that await, so pRetry does not itself interrupt an already-running caller operation."
			]
		}
	]
};

const coverage = [
	{clause: 1, anchors: ['/components/1/sublabel', '/meta/views/0/note', '/cards/0/items/0']},
	{clause: 2, anchors: ['/connections/1/label', '/connections/2/label', '/connections/3/label']},
	{clause: 3, anchors: ['/components/5/sublabel', '/cards/1/items/0', '/cards/1/items/1', '/connections/7/label', '/connections/8/label']},
	{clause: 4, anchors: ['/connections/11/label', '/cards/2/items/0']},
	{clause: 5, anchors: ['/components/7/sublabel', '/connections/10/label', '/cards/2/items/1', '/cards/3/items/1']},
	{clause: 6, anchors: ['/components/6/sublabel', '/cards/0/items/1', '/cards/3/items/0', '/cards/3/items/1', '/connections/7/label']},
	{clause: 7, anchors: ['/meta/views/0/note', '/meta/views/1/note', '/meta/views/2/note', '/cards/0/title', '/cards/2/title']}
];

fs.mkdirSync('output', {recursive: true});
fs.writeFileSync('output/initial-plan.json', JSON.stringify({draft, coverage}, null, 2));
const receipt = writeDraft('output/diagram.architecture.json', draft, {coverage, requirements: task.required, gapX: 156, gapY: 138});
fs.writeFileSync('output/preparation.json', JSON.stringify(receipt, null, 2));
