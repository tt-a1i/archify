import fs from 'node:fs';
import {writeDraft} from './tools/firstpass.mjs';

const task = JSON.parse(fs.readFileSync('./task.json', 'utf8'));
const source = (line, end_line, label) => [{path: 'index.js', line, end_line, label}];

const draft = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'QuickLRU: two-generation in-memory cache lifecycle',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/quick-lru.git',
      revision: 'a2190ebdf8e455b95a7138803d274ff5ed57ebcd',
      link_mode: 'local-only'
    },
    views: [
      {id: 'write-rotate', label: 'Set and rotate', focus: ['caller', 'quicklru', 'current', 'old', 'eviction'], note: 'A new current-generation key increments #size; reaching maxSize swaps generations and evicts every rotated-out old entry.'},
      {id: 'read-age', label: 'Get and inspect', focus: ['caller', 'quicklru', 'current', 'old', 'expiry'], note: 'get promotes a live old entry; has and peek only inspect. Any inspected expired entry is deleted and does not return a live result.'},
      {id: 'removal-boundary', label: 'Removal boundary', focus: ['quicklru', 'current', 'old', 'expiry', 'eviction'], note: 'Expiry and rotation can call onEviction. Explicit delete and clear change maps and #size without a manual-deletion callback.'}
    ]
  },
  components: [
    {id: 'caller', type: 'external', label: 'Library caller', sublabel: 'calls set, get, has, peek, delete, or clear', row: 1, col: 0, sources: source(105, 179, 'public cache methods')},
    {id: 'quicklru', type: 'backend', label: 'QuickLRU controller', sublabel: 'owns two Maps, #size, maxSize, maxAge, and optional onEviction', tag: 'in-memory only', row: 1, col: 1, sources: source(1, 23, 'private state and options')},
    {id: 'current', type: 'database', label: 'Current generation: #cache', sublabel: 'Map of {value, expiry}; #size counts inserts into this generation', row: 0, col: 2, sources: source(2, 6, 'current and old Maps')},
    {id: 'old', type: 'database', label: 'Old generation: #oldCache', sublabel: 'previous Map; a live get moves its entry into #cache', row: 2, col: 2, sources: source(80, 83, 'promotion removes old entry')},
    {id: 'write', type: 'backend', label: 'set + generation rotation', sublabel: 'current key overwrites; absent-current key uses #set and may rotate at #size >= maxSize', row: 0, col: 3, sources: source(68, 77, 'insert and rotation')},
    {id: 'read', type: 'backend', label: 'get, has, and peek', sublabel: 'get reads current or promotes a live old entry; has/peek inspect without promotion', row: 2, col: 3, sources: source(105, 157, 'read and inspect methods')},
    {id: 'expiry', type: 'security', label: 'Expiry check', sublabel: 'expired item calls onEviction when configured, then delete removes it; reads return undefined / false', row: 3, col: 2, sources: source(40, 60, 'expired-item removal')},
    {id: 'manual', type: 'backend', label: 'Explicit delete + clear', sublabel: 'delete removes key from both Maps and decrements #size only for current; clear empties both and resets #size', row: 3, col: 3, sources: source(166, 179, 'manual mutation methods')},
    {id: 'eviction', type: 'external', label: 'onEviction callback', sublabel: 'optional caller-supplied function; receives key and value for expired or rotated-out entries', row: 1, col: 4, sources: source(30, 46, 'callback invocation')}
  ],
  boundaries: [
    {kind: 'region', label: 'One QuickLRU instance: volatile process memory', wraps: ['quicklru', 'current', 'old', 'write', 'read', 'expiry', 'manual'], pad: 32}
  ],
  connections: [
    {id: 'api', from: 'caller', to: 'quicklru', label: 'public cache operation'},
    {id: 'dispatch-write', from: 'quicklru', to: 'write', label: 'set(key, value, maxAge)'},
    {id: 'dispatch-read', from: 'quicklru', to: 'read', label: 'get / has / peek'},
    {id: 'dispatch-manual', from: 'quicklru', to: 'manual', label: 'delete / clear'},
    {id: 'overwrite-current', from: 'write', to: 'current', label: 'current key: replace {value, expiry}; no #size increment'},
    {id: 'insert-current', from: 'write', to: 'current', label: 'absent from current: insert, increment #size'},
    {id: 'rotate', from: 'write', to: 'old', label: '#size >= maxSize: oldCache = cache; cache = new Map; #size = 0'},
    {id: 'current-get', from: 'current', to: 'read', label: 'get current item, then expiry check'},
    {id: 'old-get', from: 'old', to: 'read', label: 'get old item; live get deletes old then inserts current'},
    {id: 'missing', from: 'read', to: 'caller', label: 'missing key: undefined; has: false'},
    {id: 'inspect-current', from: 'read', to: 'current', label: 'has / peek inspect only; no promotion'},
    {id: 'inspect-old', from: 'read', to: 'old', label: 'has / peek inspect only; no promotion'},
    {id: 'check-expiry', from: 'read', to: 'expiry', label: 'inspect expiry before returning'},
    {id: 'expire-delete', from: 'expiry', to: 'manual', label: 'expired: delete from both Maps'},
    {id: 'rotated-out', from: 'old', to: 'eviction', label: 'rotation emits every prior old entry'},
    {id: 'expired-callback', from: 'expiry', to: 'eviction', label: 'expired item invokes callback first'},
    {id: 'manual-current', from: 'manual', to: 'current', label: 'delete / clear removes current; updates #size'},
    {id: 'manual-old', from: 'manual', to: 'old', label: 'delete / clear removes old; no callback'},
    {id: 'return', from: 'quicklru', to: 'caller', label: 'return cache result / this'}
  ],
  cards: [
    {dot: 'cyan', title: 'Why two generations?', items: ['Rotation is a whole-generation handoff, not “evict one least-recent item.”', 'The current Map receives new or promoted entries; the old Map keeps the prior generation until rotation or removal.']},
    {dot: 'amber', title: 'Expiry and callback semantics', items: ['Expiry is checked by get, has, and peek. A live value is returned only when deletion did not occur.', 'Expired entries and rotated-out old entries may call onEviction. delete and clear do not call it.']},
    {dot: 'slate', title: 'Scope boundary', items: ['Both Maps are private in-memory state owned by the QuickLRU instance; this slice shows no persistent or remote store.', 'Iteration, resize, and exact public size arithmetic are intentionally outside this lifecycle view.']}
  ]
};

const coverage = [
  {clause: 1, anchors: ['/components/1/sublabel', '/components/2/sublabel', '/components/3/sublabel', '/cards/2/items/0']},
  {clause: 2, anchors: ['/components/4/sublabel', '/connections/4/label', '/connections/5/label', '/connections/6/label', '/cards/0/items/0']},
  {clause: 3, anchors: ['/components/5/sublabel', '/connections/7/label', '/connections/8/label', '/connections/9/label', '/components/6/sublabel']},
  {clause: 4, anchors: ['/components/5/sublabel', '/connections/10/label', '/connections/11/label', '/cards/1/items/0']},
  {clause: 5, anchors: ['/components/6/sublabel', '/components/7/sublabel', '/components/8/sublabel', '/connections/14/label', '/connections/15/label', '/connections/16/label', '/connections/17/label', '/cards/1/items/1']},
  {clause: 6, anchors: ['/cards/2/items/1', '/meta/views/0/note', '/meta/views/1/note', '/meta/views/2/note']}
];

fs.mkdirSync('output', {recursive: true});
fs.writeFileSync('output/initial-plan.json', JSON.stringify({draft, coverage}, null, 2));
const receipt = writeDraft('output/diagram.architecture.json', draft, {coverage, requirements: task.required, gapX: 128, gapY: 118});
fs.writeFileSync('output/preparation.json', JSON.stringify(receipt, null, 2));
