import {mkdir, writeFile} from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'pRetry: retry controller, policy hooks, and cancellation boundaries',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/p-retry.git',
      revision: '1472907affe8d6107aba5884abc36d6361b3042e',
      provider: 'github',
      link_mode: 'web'
    },
    views: [
      {
        id: 'happy-loop',
        label: 'Successful retry loop',
        focus: ['caller', 'retry-loop', 'operation', 'delay'],
        note: 'The controller increments attemptNumber, invokes the caller operation, and returns its fulfilled value.'
      },
      {
        id: 'failure-policy',
        label: 'Failure policy order',
        focus: ['failure-controller', 'consume-hook', 'failed-hook', 'retry-hook', 'retry-loop'],
        note: 'On ordinary failure: shouldConsumeRetry → onFailedAttempt → guards → shouldRetry.'
      },
      {
        id: 'stops-and-abort',
        label: 'Stops and AbortSignal',
        focus: ['failure-controller', 'abort-error', 'signal', 'delay', 'rejection'],
        note: 'AbortError unwraps; an AbortSignal can interrupt delay, while input must honor cancellation itself.'
      }
    ]
  },
  components: [
    {
      id: 'caller', type: 'external', label: 'Caller', sublabel: 'supplies input + options; awaits Promise',
      pos: [40, 355], size: [190, 74],
      sources: [{path: 'index.js', line: 200, end_line: 201, label: 'pRetry arguments'}]
    },
    {
      id: 'retry-loop', type: 'backend', label: 'pRetry retry loop', sublabel: 'owns attemptNumber, retriesConsumed, startTime',
      pos: [295, 355], size: [238, 80],
      sources: [{path: 'index.js', line: 233, end_line: 260, label: 'loop and counters'}]
    },
    {
      id: 'operation', type: 'external', label: 'Caller-provided operation', sublabel: 'input(attemptNumber): value or rejection',
      pos: [600, 165], size: [225, 72],
      sources: [{path: 'index.js', line: 240, end_line: 250, label: 'input invocation'}]
    },
    {
      id: 'success', type: 'external', label: 'Fulfilled value', sublabel: 'returned by pRetry to caller',
      pos: [895, 165], size: [190, 64],
      sources: [{path: 'index.js', line: 245, end_line: 249, label: 'successful return'}]
    },
    {
      id: 'failure-controller', type: 'backend', label: 'onAttemptFailure', sublabel: 'normalizes error; computes retriesLeft and remaining time',
      pos: [600, 385], size: [250, 82],
      sources: [{path: 'index.js', line: 109, end_line: 180, label: 'failure controller'}]
    },
    {
      id: 'consume-hook', type: 'external', label: 'shouldConsumeRetry', sublabel: 'true consumes retry; false skips delay and counter',
      pos: [940, 285], size: [235, 70],
      sources: [{path: 'index.js', line: 140, end_line: 155, label: 'consume decision'}]
    },
    {
      id: 'failed-hook', type: 'external', label: 'onFailedAttempt', sublabel: 'observes context after consume decision',
      pos: [940, 425], size: [235, 70],
      sources: [{path: 'index.js', line: 148, end_line: 161, label: 'failure callback'}]
    },
    {
      id: 'retry-hook', type: 'external', label: 'shouldRetry', sublabel: 'false rejects; true permits another attempt',
      pos: [940, 575], size: [235, 70],
      sources: [{path: 'index.js', line: 170, end_line: 180, label: 'retry decision'}]
    },
    {
      id: 'delay', type: 'backend', label: 'Backoff timer', sublabel: 'min(delay, remaining maxRetryTime); delay caps at maxTimeout',
      pos: [600, 625], size: [270, 78],
      sources: [{path: 'index.js', line: 66, end_line: 106, label: 'delay and abort listener'}, {path: 'index.js', line: 184, end_line: 197, label: 'final delay'}]
    },
    {
      id: 'signal', type: 'security', label: 'AbortSignal', sublabel: 'checked before/after input and around retry wait',
      pos: [315, 650], size: [220, 70],
      sources: [{path: 'index.js', line: 89, end_line: 106, label: 'delay cancellation'}, {path: 'index.js', line: 233, end_line: 247, label: 'loop checks'}]
    },
    {
      id: 'abort-error', type: 'backend', label: 'AbortError', sublabel: 'unwraps originalError; skips failure callbacks',
      pos: [900, 700], size: [250, 66],
      sources: [{path: 'index.js', line: 49, end_line: 64, label: 'AbortError wrapper'}, {path: 'index.js', line: 109, end_line: 116, label: 'unwrap path'}]
    },
    {
      id: 'rejection', type: 'external', label: 'Final rejection', sublabel: 'last error, unwrapped AbortError, or signal reason',
      pos: [1215, 730], size: [215, 76],
      sources: [{path: 'index.js', line: 114, end_line: 116, label: 'AbortError rejection'}, {path: 'index.js', line: 160, end_line: 180, label: 'stopping rejection'}]
    }
  ],
  boundaries: [
    {kind: 'region', label: 'pRetry controller (library-owned control plane)', wraps: ['retry-loop', 'failure-controller', 'delay', 'abort-error'], pad: 28},
    {kind: 'region', label: 'caller-owned callbacks and operation', wraps: ['caller', 'operation', 'consume-hook', 'failed-hook', 'retry-hook', 'signal'], pad: 24}
  ],
  connections: [
    {id: 'call', from: 'caller', to: 'retry-loop', label: 'pRetry(input, options)'},
    {id: 'invoke', from: 'retry-loop', to: 'operation', label: 'increment attemptNumber; await input(attemptNumber)', variant: 'emphasis'},
    {id: 'value', from: 'operation', to: 'success', label: 'fulfilled value'},
    {id: 'return', from: 'success', to: 'caller', label: 'return result', variant: 'emphasis'},
    {id: 'failure', from: 'operation', to: 'failure-controller', label: 'rejection → failure handling', variant: 'emphasis'},
    {id: 'abort-error-path', from: 'failure-controller', to: 'abort-error', label: 'AbortError → unwrap originalError', labelDy: 24},
    {id: 'abort-reject', from: 'abort-error', to: 'rejection', label: 'reject; no callbacks'},
    {id: 'consume', from: 'failure-controller', to: 'consume-hook', label: '1. decide consumption'},
    {id: 'failed', from: 'failure-controller', to: 'failed-hook', label: '2. await callback(context)'},
    {id: 'retry', from: 'failure-controller', to: 'retry-hook', label: '3. after time/retry/TypeError guards'},
    {id: 'no-consume-loop', from: 'failure-controller', to: 'retry-loop', label: 'permitted + !consumeRetry: loop; no wait/count', variant: 'dashed'},
    {id: 'wait', from: 'failure-controller', to: 'delay', label: 'permitted + consume: finalDelay', route: 'straight', labelDy: 24},
    {id: 'resume', from: 'delay', to: 'retry-loop', label: 'timer resolves → increment retriesConsumed', variant: 'emphasis'},
    {id: 'signal-loop', from: 'signal', to: 'retry-loop', label: 'throwIfAborted at loop boundaries', variant: 'security'},
    {id: 'signal-delay', from: 'signal', to: 'delay', label: 'abort clears timeout and rejects wait', variant: 'security'},
    {id: 'stop', from: 'failure-controller', to: 'rejection', label: 'time/retries exhausted, TypeError, or shouldRetry=false', variant: 'emphasis'}
  ],
  cards: [
    {dot: 'cyan', title: 'Who owns the budgets?', items: [
      'pRetry owns attemptNumber, retriesConsumed, and the performance.now() start time.',
      'The caller owns input and all policy callbacks; input receives the attempt number.'
    ]},
    {dot: 'violet', title: 'Failure decision order', items: [
      'For ordinary failures, shouldConsumeRetry runs first, then onFailedAttempt, then remaining-time/retries/TypeError guards, then shouldRetry.',
      'A permitted false consumption decision returns to the loop without incrementing retriesConsumed or waiting; maxRetryTime still applies.'
    ]},
    {dot: 'amber', title: 'Timer budget is not an input deadline', items: [
      'Backoff is capped by maxTimeout and then bounded by remaining maxRetryTime, which may be Infinity.',
      'The source checks the signal around await input and can cancel a retry wait; it does not pass the signal to input, so an already-running operation must implement its own cancellation.'
    ]},
    {dot: 'rose', title: 'Stopping paths', items: [
      'AbortError is unwrapped to originalError before callbacks. A non-network TypeError, exhausted retry/time budget, or shouldRetry=false rejects.',
      'AbortSignal cancellation rejects with its reason and clears a pending retry timeout.'
    ]}
  ]
};

await mkdir('output', {recursive: true});
await writeFile('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
