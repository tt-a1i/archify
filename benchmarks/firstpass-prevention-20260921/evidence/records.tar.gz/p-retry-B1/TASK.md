You are an independent timed Archify author. Work only in /private/tmp/archify-firstpass-prevention-20260921/runs/p-retry-B1.
You are not alone in the filesystem: do not modify another worker's files. You own only this workspace's build.mjs and output/ artifacts.
Read your local archify/SKILL.md and applicable references. Use only the local repo/ source and the packaged archify/ Skill; do not inspect other trials, research reports, prior diagrams, installed Skills, hidden rubrics or parent context. Do not delegate or use network. Do not modify source, Skill, renderer, validator or tools. Ordinary local shell/text inspection is available.

TASK: Create a source-backed architecture diagram explaining pRetry(input, options) from the caller's request through successful return or final rejection. Explain the actual retry controller, the caller-provided operation, failure-decision hooks and the timer/AbortSignal boundaries. Make both normal retry and stopping paths understandable to a developer new to this code.

Required visible acceptance criteria (these exact clauses will be used in independent review):
1. Show which controller owns attempt numbers, consumed retries and the overall retry-time budget; distinguish it from the caller-provided operation.
2. Show operation invocation and successful value return, plus the failed-attempt path back into the controller.
3. Explain the roles and actual ordering/conditions of shouldConsumeRetry, onFailedAttempt and shouldRetry; distinguish consuming retry count and waiting from retrying without that consumption/delay, while retaining retry-time and remaining-retry conditions.
4. Explain stopping when retry count or retry time is exhausted, when shouldRetry declines, and when a non-network TypeError is rejected.
5. Show AbortError unwrapping and distinguish it from AbortSignal cancellation. Explain cancellation during a retry delay and the limits of cancelling an already-running caller operation.
6. Show backoff/timer waiting bounded by configured maxTimeout and remaining maxRetryTime (which may be infinite), and the retry loop. Distinguish a retry-time budget from an enforced deadline on an already-running input. Random-jitter formula details, option-validation error wording and the makeRetriable wrapper are outside scope.
7. Support the diagram's roles, meaningful branches and material conclusion-card claims with exact inspected source ranges. Use reader-focused views/cards when they explain distinct aspects; there are no content-count targets.

Deliver an English source-backed Architecture showcase in output/diagram.architecture.json and output/diagram.html. Keep exact repository metadata and source evidence. Use the complete normal finalize command with --repo-root ./repo --quality showcase --json. All authoring, helper execution, repairs and final response count toward time. Allow at most three focused repairs after the first finalize; if still blocked, report the failure without changing meaning or quality. Stop within 600 seconds. Do not claim machine success is semantic/visual human acceptance.
Do not create a separate report or screenshots during authoring. Final response should identify the artifact and actual gate status concisely. Every visible role and material explanation must be grounded in source; no node/edge/evidence/card/view quotas.

Controlled condition: follow the ordinary packaged Skill authoring path. No additional helper is provided.
