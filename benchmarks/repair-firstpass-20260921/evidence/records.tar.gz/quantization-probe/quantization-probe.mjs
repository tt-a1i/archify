import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const outputRoot = '/private/tmp/archify-repair-firstpass-20260921';
const prior = path.join(outputRoot, 'prior/compact');
const cli = '/Users/tushaokun/.codex/worktrees/archify-repair-firstpass-20260921/archify/archify/bin/archify.mjs';
const cases = [
  {id: 'p-retry-C1', repoRoot: '/private/tmp/archify-semantic-firstdraft-20260921/runs/p-retry-C1/repo'},
  {id: 'quick-lru-B1', repoRoot: '/private/tmp/archify-semantic-firstdraft-20260921/runs/quick-lru-B1/repo'},
  {id: 'lilconfig-C1', repoRoot: '/private/tmp/archify-semantic-firstdraft-20260921/runs/lilconfig-C1/repo'},
];
const seeds = [
  {id: 'g16-p0', grid: 16, padding: 0}, {id: 'g16-p16', grid: 16, padding: 16},
  {id: 'g32-p0', grid: 32, padding: 0}, {id: 'g32-p32', grid: 32, padding: 32},
  {id: 'g48-p0', grid: 48, padding: 0}, {id: 'g48-p48', grid: 48, padding: 48},
];
const candidateDir = path.join(outputRoot, 'quantization-probe.candidates');
const logDir = path.join(outputRoot, 'quantization-probe.logs');
fs.mkdirSync(candidateDir, {recursive: true});
fs.mkdirSync(logDir, {recursive: true});
const clone = value => JSON.parse(JSON.stringify(value));
const ceilGrid = (value, grid) => Math.ceil(value / grid) * grid;
const roundGrid = (value, grid) => Math.round(value / grid) * grid;
const estimateTextWidth = component => Math.max(
  String(component.label || '').length * 6 + 20,
  String(component.sublabel || '').length * 3.5 + 14,
);
function rectanglesOverlap(a, b) {
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}
function transform(original, seed) {
  const document = clone(original);
  document.components = document.components.map(component => {
    const [x, y] = component.pos;
    const [width, height] = component.size;
    const measuredWidth = Math.max(width, estimateTextWidth(component)) + seed.padding;
    const next = clone(component);
    next.pos = [roundGrid(x, seed.grid), roundGrid(y, seed.grid)];
    next.size = [ceilGrid(measuredWidth, seed.grid), ceilGrid(height, seed.grid)];
    return next;
  });
  return document;
}
function overlapPairs(document) {
  const items = document.components.map(component => ({id: component.id, x: component.pos[0], y: component.pos[1], width: component.size[0], height: component.size[1]}));
  const pairs = [];
  for (let i = 0; i < items.length; i++) for (let j = i + 1; j < items.length; j++) if (rectanglesOverlap(items[i], items[j])) pairs.push([items[i].id, items[j].id]);
  return pairs;
}
function invariantReceipt(original, candidate) {
  const stripGeometry = document => ({
    ...document,
    components: document.components.map(({pos, size, ...component}) => component),
  });
  return {
    semantic_document_unchanged_except_component_pos_size: JSON.stringify(stripGeometry(original)) === JSON.stringify(stripGeometry(candidate)),
    connection_array_unchanged: JSON.stringify(original.connections) === JSON.stringify(candidate.connections),
    meta_unchanged: JSON.stringify(original.meta) === JSON.stringify(candidate.meta),
  };
}
function run(candidatePath, repoRoot) {
  const started = performance.now();
  const result = spawnSync(process.execPath, [cli, 'validate', 'architecture', candidatePath, '--quality', 'showcase', '--repo-root', repoRoot, '--layout-json'], {encoding: 'utf8', timeout: 15000});
  const elapsedMs = performance.now() - started;
  let payload;
  try { payload = JSON.parse(result.stdout); } catch { payload = null; }
  return {elapsed_ms: Number(elapsedMs.toFixed(3)), exit_code: result.status, timed_out: result.error?.code === 'ETIMEDOUT', parseable_output: Boolean(payload), payload, stderr: result.stderr};
}
function summary(runResult) {
  const diagnostics = runResult.payload?.diagnostics || [];
  const counts = {};
  for (const diagnostic of diagnostics) counts[diagnostic.code] = (counts[diagnostic.code] || 0) + 1;
  return {exit_code: runResult.exit_code, elapsed_ms: runResult.elapsed_ms, timed_out: runResult.timed_out, parseable_output: runResult.parseable_output, validator_ok: runResult.payload?.ok ?? null, diagnostic_counts: counts, diagnostic_total: diagnostics.length};
}
const report = {schema_version: 1, purpose: 'One-off fixed geometry quantization probe; not acceptance or a revision selection.', fixed_seed_family: seeds, cases: []};
for (const testCase of cases) {
  const originalPath = path.join(prior, testCase.id, 'snapshot-001.json');
  const original = JSON.parse(fs.readFileSync(originalPath, 'utf8'));
  const baselinePath = path.join(candidateDir, `${testCase.id}.baseline.json`);
  fs.writeFileSync(baselinePath, JSON.stringify(original, null, 2) + '\n');
  const baselineRun = run(baselinePath, testCase.repoRoot);
  fs.writeFileSync(path.join(logDir, `${testCase.id}.baseline.layout.json`), baselineRun.payload ? JSON.stringify(baselineRun.payload, null, 2) + '\n' : baselineRun.stderr);
  const entry = {id: testCase.id, original_geometry: original.components.map(c => ({id: c.id, pos: c.pos, size: c.size})), baseline: summary(baselineRun), proposals: []};
  for (const seed of seeds) {
    const candidate = transform(original, seed);
    const candidatePath = path.join(candidateDir, `${testCase.id}.${seed.id}.json`);
    fs.writeFileSync(candidatePath, JSON.stringify(candidate, null, 2) + '\n');
    const overlaps = overlapPairs(candidate);
    const item = {seed, geometry: candidate.components.map(c => ({id: c.id, pos: c.pos, size: c.size})), invariants: invariantReceipt(original, candidate), overlap_guard: {passed: overlaps.length === 0, overlapping_pairs: overlaps}};
    if (overlaps.length) {
      item.result = {skipped_before_cli: true, reason: 'overlap guard', diagnostic_total: null, diagnostic_counts: {}};
    } else {
      const candidateRun = run(candidatePath, testCase.repoRoot);
      fs.writeFileSync(path.join(logDir, `${testCase.id}.${seed.id}.layout.json`), candidateRun.payload ? JSON.stringify(candidateRun.payload, null, 2) + '\n' : candidateRun.stderr);
      item.result = summary(candidateRun);
    }
    entry.proposals.push(item);
  }
  report.cases.push(entry);
}
report.interpretation = 'Each seed rounds every component position to its grid, ceilings every height and an estimated text-supporting width to that grid, and adds the stated uniform width padding. Invariant receipts verify that each candidate leaves all non-geometry component fields, metadata, and the complete connection array unchanged. The overlap guard skips a seed before CLI validation; skipped seeds are not evidence of improvement.';
fs.writeFileSync(path.join(outputRoot, 'quantization-probe.json'), JSON.stringify(report, null, 2) + '\n');
