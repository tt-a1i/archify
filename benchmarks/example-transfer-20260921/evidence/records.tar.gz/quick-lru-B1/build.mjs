import {mkdir, writeFile} from 'node:fs/promises';

const diagram = {
  schema_version: 1,
  diagram_type: 'architecture',
  meta: {
    title: 'QuickLRU: two-generation cache lifecycle',
    locale: 'en',
    quality_profile: 'showcase',
    repository: {
      url: 'https://github.com/sindresorhus/quick-lru.git',
      provider: 'github',
      revision: 'a2190ebdf8e455b95a7138803d274ff5ed57ebcd'
    },
    views: [
      {id: 'write-rotate', label: 'Write and rotate', focus: ['caller', 'quicklru', 'set', 'current', 'old', 'callback'], note: 'A new current-generation key increments the counter; reaching maxSize rotates whole generations.'},
      {id: 'read-promote', label: 'Read and promote', focus: ['caller', 'get', 'current', 'old', 'expiry'], note: 'Only an unexpired old-generation get moves the item into the current generation.'},
      {id: 'inspect-remove', label: 'Inspect and remove', focus: ['inspect', 'expiry', 'current', 'old', 'manual'], note: 'has and peek check expiry without promotion; delete and clear do not invoke onEviction.'}
    ]
  },
  components: [
    {id: 'caller', type: 'external', label: 'Caller', sublabel: 'uses the public Map-like API', pos: [40, 290], size: [180, 72], sources: [{path: 'index.d.ts', line: 53, end_line: 95, label: 'public cache API'}]},
    {id: 'quicklru', type: 'backend', label: 'QuickLRU controller', sublabel: 'owns #size, #maxSize, #maxAge, and both Maps', pos: [270, 270], size: [220, 80], sources: [{path: 'index.js', line: 1, end_line: 23, label: 'private state and options'}]},
    {id: 'set', type: 'backend', label: 'set()', sublabel: 'writes current generation or adds a new entry', pos: [540, 70], size: [220, 76], sources: [{path: 'index.js', line: 68, end_line: 83, label: 'generation write and move'}, {path: 'index.js', line: 120, end_line: 135, label: 'public set branches'}]},
    {id: 'get', type: 'backend', label: 'get()', sublabel: 'current hit, old hit + promotion, or undefined', pos: [540, 205], size: [220, 76], sources: [{path: 'index.js', line: 105, end_line: 118, label: 'get hit branches'}]},
    {id: 'inspect', type: 'backend', label: 'has() and peek()', sublabel: 'inspect either map; never promote an old hit', pos: [540, 340], size: [220, 76], sources: [{path: 'index.js', line: 137, end_line: 157, label: 'non-promoting inspection'}]},
    {id: 'manual', type: 'backend', label: 'delete() and clear()', sublabel: 'manual removal across both Maps', pos: [540, 475], size: [220, 76], sources: [{path: 'index.js', line: 166, end_line: 179, label: 'manual removal'}]},
    {id: 'current', type: 'database', label: '#cache: current Map', sublabel: 'in-memory entries; #size counts new-generation adds', pos: [960, 70], size: [230, 80], sources: [{path: 'index.js', line: 1, end_line: 7, label: 'current in-memory map'}, {path: 'index.js', line: 68, end_line: 78, label: 'count and rotation'}]},
    {id: 'old', type: 'database', label: '#oldCache: old Map', sublabel: 'in-memory previous generation; replaced on rotation', pos: [960, 350], size: [230, 80], sources: [{path: 'index.js', line: 3, end_line: 4, label: 'old in-memory map'}, {path: 'index.js', line: 72, end_line: 77, label: 'whole-generation rotation'}]},
    {id: 'expiry', type: 'backend', label: 'Expiry guard', sublabel: 'expired item: onEviction then delete(key)', pos: [960, 580], size: [230, 76], sources: [{path: 'index.js', line: 40, end_line: 66, label: 'lazy expiry helper'}]},
    {id: 'callback', type: 'external', label: 'onEviction callback', sublabel: 'optional caller-owned cleanup hook', pos: [1320, 250], size: [200, 76], sources: [{path: 'index.js', line: 30, end_line: 46, label: 'callback invocation'}, {path: 'index.d.ts', line: 21, end_line: 28, label: 'callback contract'}]}
  ],
  boundaries: [
    {kind: 'region', label: 'One QuickLRU instance — in-memory only (no persistent or remote store)', wraps: ['quicklru', 'set', 'get', 'inspect', 'manual', 'current', 'old', 'expiry'], pad: 28}
  ],
  connections: [
    {id: 'api-call', from: 'caller', to: 'quicklru', label: 'set / get / has / peek / delete / clear', variant: 'emphasis'},
    {id: 'route-set', from: 'quicklru', to: 'set', label: 'write request'},
    {id: 'route-get', from: 'quicklru', to: 'get', label: 'read request'},
    {id: 'route-inspect', from: 'quicklru', to: 'inspect', label: 'non-promoting inspection'},
    {id: 'route-manual', from: 'quicklru', to: 'manual', label: 'manual removal'},
    {id: 'set-current-overwrite', from: 'set', to: 'current', label: 'current key: overwrite item; do not increment #size'},
    {id: 'set-rotate', from: 'set', to: 'old', label: 'new key: increment #size; at #maxSize rotate current into old', variant: 'emphasis', fromSide: 'right', toSide: 'left', via: [[850, 108], [850, 390]], labelAt: [850, 180]},
    {id: 'rotation-fresh-current', from: 'set', to: 'current', label: 'after rotation: reset #size and create fresh current Map'},
    {id: 'rotation-callback', from: 'old', to: 'callback', label: 'before rotation: emitEvictions for all rotated-out old entries', variant: 'emphasis', labelAt: [1320, 160]},
    {id: 'get-current', from: 'get', to: 'current', label: 'current hit: expiry check then value', fromSide: 'right', toSide: 'top', via: [[800, 243], [800, 30], [1075, 30]], labelAt: [950, 45]},
    {id: 'get-old', from: 'get', to: 'old', label: 'old hit: expiry check; missing key returns undefined', fromSide: 'right', toSide: 'left', via: [[870, 243], [870, 390]], labelAt: [870, 300]},
    {id: 'old-promotion', from: 'old', to: 'current', label: 'unexpired get: delete old then set current (promote)', variant: 'emphasis'},
    {id: 'inspect-current', from: 'inspect', to: 'current', label: 'has / peek inspect current; expiry can remove', fromSide: 'right', toSide: 'right', via: [[800, 378], [800, 700], [1260, 700], [1260, 110]], labelAt: [1030, 715]},
    {id: 'inspect-old', from: 'inspect', to: 'old', label: 'has / peek inspect old; no get-style promotion', route: 'straight', labelAt: [850, 445]},
    {id: 'read-expiry', from: 'get', to: 'expiry', label: 'expired hit triggers lazy removal'},
    {id: 'inspect-expiry', from: 'inspect', to: 'expiry', label: 'expired hit triggers lazy removal'},
    {id: 'expiry-delete', from: 'expiry', to: 'quicklru', label: 'delete(key): remove both maps; decrement #size only if current'},
    {id: 'expiry-callback', from: 'expiry', to: 'callback', label: 'expired entry invokes callback before deletion', variant: 'emphasis'},
    {id: 'manual-current', from: 'manual', to: 'current', label: 'delete current decrements #size; clear empties current', labelAt: [1040, 500]},
    {id: 'manual-old', from: 'manual', to: 'old', label: 'delete old; clear empties old and resets #size', labelAt: [1070, 640]},
    {id: 'manual-no-callback', from: 'manual', to: 'callback', label: 'no callback for delete() or clear()', variant: 'dashed'}
  ],
  cards: [
    {dot: 'cyan', title: 'Why two generations', items: ['#cache receives current writes while #oldCache retains the previous generation.', 'At the threshold, the implementation rotates whole Maps; it does not evict one least-recent item on each write.']},
    {dot: 'amber', title: 'Expiry and promotion', items: ['get checks expiry on both generations; an unexpired old hit moves to #cache.', 'has and peek also apply expiry checks, but neither performs that move.']},
    {dot: 'rose', title: 'Callback boundary', items: ['onEviction runs for expired entries and for every old entry rotated out.', 'Explicit delete and clear change maps and #size without invoking onEviction.']}
  ]
};

await mkdir('output', {recursive: true});
await writeFile('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
