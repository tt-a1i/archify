import {mkdirSync, writeFileSync} from 'node:fs';

const source = (line, end_line, label) => ({path: 'index.js', line, end_line, label});
const diagram = {
	"schema_version": 1,
	"diagram_type": "architecture",
	"meta": {
		"title": "pRetry: retry controller and caller operation",
		"locale": "en",
		"quality_profile": "showcase",
		"repository": {
			"url": "https://github.com/sindresorhus/p-retry.git",
			"revision": "1472907affe8d6107aba5884abc36d6361b3042e",
			"link_mode": "local-only"
		},
		"views": [
			{"id": "normal-loop", "label": "Normal retry loop", "focus": ["caller", "controller", "operation", "failure", "hooks", "timer"], "note": "Follow a rejected attempt through policy decisions, bounded waiting, and the next invocation."},
			{"id": "stop-paths", "label": "When it stops", "focus": ["failure", "hooks", "abort-error", "signal", "rejected"], "note": "AbortError, exhausted budgets, declined policy, and signal cancellation leave the loop with a rejection."},
			{"id": "ownership", "label": "Who owns what", "focus": ["caller", "controller", "operation", "timer"], "note": "The controller owns counters and retry-time accounting; the supplied input owns the work for one attempt."}
		]
	},
	"components": [
		{"id": "caller", "type": "external", "label": "Caller", "sublabel": "passes input + options; awaits Promise", "pos": [40, 300], "size": [170, 70], "sources": [source(200, 201, "pRetry entry")]},
		{"id": "controller", "type": "backend", "label": "pRetry controller", "sublabel": "attemptNumber, retriesConsumed, startTime", "pos": [300, 300], "size": [210, 76], "sources": [source(233, 240, "counters and loop")]},
		{"id": "operation", "type": "external", "label": "Caller-provided input", "sublabel": "runs one attempt; receives attempt number", "pos": [590, 300], "size": [210, 70], "sources": [source(245, 249, "input invocation and success")]},
		{"id": "fulfilled", "type": "external", "label": "Fulfilled return", "sublabel": "result returned to caller", "pos": [900, 180], "size": [180, 64], "sources": [source(245, 249, "successful result")]},
		{"id": "failure", "type": "backend", "label": "Failure controller", "sublabel": "normalize error; retries-left and time checks", "pos": [590, 500], "size": [230, 76], "sources": [source(109, 180, "failure decision path")]},
		{"id": "hooks", "type": "external", "label": "Failure decision hooks", "sublabel": "consume → failed-attempt → retry", "pos": [900, 500], "size": [230, 76], "sources": [source(140, 176, "hook ordering and conditions")]},
		{"id": "timer", "type": "backend", "label": "Backoff timer", "sublabel": "min(delay, remaining maxRetryTime)", "pos": [900, 710], "size": [220, 70], "sources": [source(66, 73, "delay capped by maxTimeout"), source(184, 195, "final delay and cancellation")]},
		{"id": "abort-error", "type": "security", "label": "AbortError", "sublabel": "unwrap originalError; skip hooks", "pos": [300, 650], "size": [200, 70], "sources": [source(109, 116, "AbortError unwrapping")]},
		{"id": "signal", "type": "security", "label": "AbortSignal", "sublabel": "cancels checks and retry delay", "pos": [630, 770], "size": [210, 70], "sources": [source(84, 106, "abortable delay"), source(233, 247, "checks around input")]},
		{"id": "rejected", "type": "external", "label": "Final rejection", "sublabel": "last error, hook error, or signal reason", "pos": [1180, 490], "size": [210, 70], "sources": [source(114, 116, "AbortError result"), source(160, 181, "terminal failure checks")]}
	],
	"boundaries": [
		{"kind": "region", "label": "p-retry library runtime", "wraps": ["controller", "failure", "timer", "abort-error", "signal"], "pad": 34}
	],
	"connections": [
		{"id": "start", "from": "caller", "to": "controller", "label": "pRetry(input, options)"},
		{"id": "invoke", "from": "controller", "to": "operation", "label": "await input(attemptNumber)"},
		{"id": "success", "from": "operation", "to": "fulfilled", "label": "fulfilled value"},
		{"id": "return", "from": "fulfilled", "to": "caller", "label": "return result", "variant": "emphasis"},
		{"id": "failed-attempt", "from": "operation", "to": "failure", "label": "rejection / thrown error"},
		{"id": "abort-error", "from": "failure", "to": "abort-error", "label": "AbortError: unwrap + reject", "variant": "security"},
		{"id": "abort-reject", "from": "abort-error", "to": "rejected", "label": "originalError", "variant": "security"},
		{"id": "decide", "from": "failure", "to": "hooks", "label": "if time remains: consume → onFailed → retry"},
		{"id": "stop", "from": "failure", "to": "rejected", "label": "time/retries exhausted or non-network TypeError", "variant": "dashed"},
		{"id": "decline", "from": "hooks", "to": "rejected", "label": "shouldRetry false → reject", "variant": "dashed"},
		{"id": "wait", "from": "hooks", "to": "timer", "label": "consume=true: delay; false: no delay"},
		{"id": "repeat", "from": "timer", "to": "controller", "label": "increment consumed retry; next loop", "variant": "emphasis"},
		{"id": "signal-delay", "from": "signal", "to": "timer", "label": "abort clears timeout + rejects", "variant": "security"},
		{"id": "signal-controller", "from": "signal", "to": "controller", "label": "throwIfAborted at loop boundaries", "variant": "security"},
		{"id": "signal-operation", "from": "signal", "to": "operation", "label": "does not cancel already-running input", "variant": "dashed"},
		{"id": "signal-reject", "from": "signal", "to": "rejected", "label": "signal reason", "variant": "security"}
	],
	"cards": [
		{"dot": "cyan", "title": "Controller ownership", "items": ["pRetry creates attemptNumber, retriesConsumed, and startTime; input only performs an attempt.", "maxRetryTime uses remaining monotonic time. It limits retry progression, not an enforced deadline inside a running input."]},
		{"dot": "amber", "title": "Failure order and retry accounting", "items": ["For ordinary errors: shouldConsumeRetry runs first, then onFailedAttempt, then shouldRetry after retry/time and TypeError gates.", "A false consume decision leaves retriesConsumed and backoff unchanged, skips delay, but still must have remaining retry time and retries."]},
		{"dot": "violet", "title": "Waiting and cancellation", "items": ["Backoff is capped by maxTimeout, then by remaining maxRetryTime; Infinity remains unbounded by that time budget.", "AbortSignal rejects an abortable retry delay and is checked around attempts. pRetry does not pass it into or forcibly stop an already-running input."]},
		{"dot": "rose", "title": "Terminal paths", "items": ["AbortError immediately rejects with originalError and bypasses hooks.", "Exhausted retries/time, non-network TypeError, or shouldRetry false rejects the failed attempt's error."]}
	]
};

mkdirSync('output', {recursive: true});
writeFileSync('output/diagram.architecture.json', `${JSON.stringify(diagram, null, 2)}\n`);
